var require = meteorInstall({"collections":{"epss.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/epss.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Epss: () => Epss
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let HTTP;
module.watch(require("meteor/http"), {
    HTTP(v) {
        HTTP = v;
    }

}, 1);
const Epss = new Mongo.Collection('epss');

/*
Please review the AHRQ Copyright and Disclaimer notice before using the API: https://www.uspreventiveservicestaskforce.org/Page/Name/copyright-notice.
Instructions for use and access information can be found at:
•	Instruction for Use:  http://epss.ahrq.gov/PDA/docs/ePSS_Data_API_WI_wLink.pdf
•	URL:  http://epssdata.ahrq.gov/
 */if (Meteor.isServer) {
    Meteor.methods({
        'getEpss': function (params) {
            //Very first, clean out the ePSS data
            Epss.remove({}); // First, we need to know the epss api url

            const url = 'http://epssdata.ahrq.gov/'; // Next, get the ePSS key from the text file in the Private folder.
            // this folder will not sync with git as it is in the .gitignore

            try {
                var ePSS_Key = JSON.parse(Assets.getText('ePSS_Key.json'));
            } catch (e) {
                console.log('Fetching ePSS key failed. Please make sure ePSS_Key.json exists in the private folder.');
                console.log(e.message);
            } // If the key is blank or not updated, we cannot continue..
            //let blankKeys = ['','PUT_KEY_HERE']


            if (ePSS_Key.key === 'PUT_KEY_HERE') {
                console.log('ePSS Key not found or invalid- please input your ePSS key into ePSS_Key.json file in private folder');
                return false;
            } else {
                // If no params are passed, populate some defaults for testing
                // todo: remove defaults and instead return an error - this should be fetched from patient data
                if (!params) {
                    params = {
                        age: '18',
                        sex: 'Male',
                        tobacco: 'N',
                        sexuallyActive: 'N',
                        grade: 'A'
                    };
                } // lastly, insert key into params


                params.key = ePSS_Key.key; // Try to fetch the ePSS recommendations based on the params.

                try {
                    var res = HTTP.call('get', url, {
                        headers: 'accept: json',
                        params
                    });
                } catch (e) {
                    console.log(e);
                } //console.dir(res.data)


                Epss.insert(res.data);
                console.log('ePSS Data inserted');
                return true;
            }
        },
        'clearEpss': function () {
            Epss.remove({});
        }
    });
    Meteor.publish('epss', function () {
        return Epss.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('epss');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metrics.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/metrics.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Metrics: () => Metrics
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Metrics = new Mongo.Collection('metrics');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Metrics.remove({});
    });
    Meteor.publish('metrics', function () {
        return Metrics.find();
    });
    Meteor.methods({
        'getMetrics': function (patId) {
            Metrics.remove({});

            try {
                const metricsString = Assets.getText('metrics.csv');
                const metrics = Papa.parse(metricsString, {
                    header: true
                });
                let count = 0;

                for (let x in metrics.data) {
                    if (metrics.data[x].patId === patId) {
                        Metrics.insert(metrics.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' metrics entered');
            } catch (e) {
                console.log("something went wrong with parsing the metrics data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('metrics');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Obs: () => Obs
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Obs = new Mongo.Collection('obs');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear any data at startup as there should not be any patient in context.
        Obs.remove({});
    });
    Meteor.publish('obs', function () {
        return Obs.find();
    });
    Meteor.methods({
        'getObs': function (patId) {
            Obs.remove({});

            try {
                const String = Assets.getText('observations.csv');
                const parse = Papa.parse(String, {
                    header: true
                });
                let count = 0;

                for (let x in parse.data) {
                    if (parse.data[x].patId === patId) {
                        Obs.insert(parse.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' observations entered');
            } catch (e) {
                console.log("something went wrong with parsing the observations data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('obs');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pat.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/pat.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
            Pat: () => Pat
});
let Mongo;
module.watch(require("meteor/mongo"), {
            Mongo(v) {
                        Mongo = v;
            }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
            Meteor(v) {
                        Meteor = v;
            }

}, 1);
let Patients;
module.watch(require("./patients"), {
            Patients(v) {
                        Patients = v;
            }

}, 2);
const Pat = new Mongo.Collection('pat');

// Once our patient is selected we need to populate our collections. The main functions for this are handled here
// With references to the other collections when needed.
if (Meteor.isServer) {
            Meteor.startup(() => {
                        // clear ant Pat data at startup as there should not be any patient in context.
                        Pat.remove({});
            });
            Meteor.methods({
                        'updatePat': function (patId) {
                                    console.log("updatePat was run"); // Ok, First, let's fetch the other data about the patient
                                    // We'll store this single patient's data in a new Collection, pat
                                    // If any old data is in Pat, need to clear it

                                    Pat.remove({}); // Now, let's start fresh with our currently selected patient

                                    Pat.insert({
                                                _id: patId
                                    }); // these helper functions will make inserting and reading data easier
                                    // This one adds a new object to the database collection under this patId

                                    function updatePat(object) {
                                                //console.log(object)
                                                Pat.update({
                                                            _id: patId
                                                }, {
                                                            $set: object
                                                });
                                    } //e.g. - first let's use our "Patients" list and get the full name and also the age


                                    updatePat({
                                                name: Patients.findOne({
                                                            patId: patId
                                                }).fname + ' ' + Patients.findOne({
                                                            patId: patId
                                                }).lname,
                                                age: getAge(Patients.findOne({
                                                            patId: patId
                                                }).dob)
                                    }); // Let's throw everything else that is in the "Patients" collection about our patient in a gen (for "general") object

                                    updatePat({
                                                gen: Patients.findOne({
                                                            patId: patId
                                                })
                                    }); // Simulate a call to a table that holds patient Observations
                                    // The meteor.call actually just reads from the CSV, but it does then filter by the patId
                                    // sort of like how a real SQL call would work.
                                    // We will store this in our Pat collection under the group 'obs'

                                    Meteor.call('getObs', patId); // Now simulate a call for patient Metrics
                                    // this will go in a separate collection for searching, so just is a meteor.call

                                    Meteor.call('getMetrics', patId); // We want to update our ePSS recommendations with our patient information.
                                    // We need to build our param object for the ePSS call
                                    // Here is the template with the possible values:
                                    /*
                                    params = {
                                    age: '18',  --any integer
                                    sex: 'Male', -- (Male, Female)
                                    pregnant: 'N' -- (Y,N) - requires Female sex to be present
                                    tobacco: 'N', -- (Y,N)
                                    sexuallyActive: 'N' -- (Y,N)
                                    grade: 'A' (A,B,C,D, I) -- can be repeated to include multiple values
                                    }
                                     */
                                    let P = Pat.findOne({});
                                    let params = {
                                                age: getAge(P.gen.dob),
                                                sex: P.gen.sex,
                                                //pregnant: 'N' -- (Y,N) - requires Female sex to be present
                                                //tobacco: 'N', -- (Y,N)
                                                //sexuallyActive: 'N' -- (Y,N)
                                                grade: 'A'
                                    };
                                    Meteor.call('getEpss', params);
                        },
                        'clearPat': function () {
                                    Pat.remove({});
                        }
            });
            Meteor.publish('pat', function () {
                        return Pat.find();
            });
}

if (Meteor.isClient) {
            Meteor.subscribe('pat');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patients.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/patients.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Patients: () => Patients
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Patients = new Mongo.Collection('patients');

// Populate our local patient database with some pre-built patient data.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // code to run on server at startup
        // Only do this on startup if the db is empty
        if (Patients.find().count() === 0) {
            console.log("found no patients- getting data...");
            Meteor.call('resetPatients');
        } else {
            console.log('found patients already in database');
        }
    });
    Meteor.methods({
        'clearPatients': function () {
            Patients.remove({});
        },
        'resetPatients': function () {
            console.log('resetting patient DB');
            Patients.remove({}); // The patient data is stored as a CSV file in our "private" folder
            // This allows us to quick and dirty replicate what might be a view on Acuere
            // It would probably be easier if this would just pull from Acuere...
            //First, import the csv as a string: https://stackoverflow.com/questions/17453848/is-there-a-way-to-import-strings-from-a-text-file-in-javascript-meteor

            try {
                const patientString = Assets.getText('patients.csv'); // patientString will contain the data as one long CSV string
                // We need to parse it to a JSON object.
                // will use the Papa parse package to do this...

                const patientData = Papa.parse(patientString, {
                    header: true
                }); // We will store the data in our own Mongo collection that we defined above- Patients
                // Prefer to store each patient as their own "document" to make searches and stuff easier, so loop through the CSV data and insert one at a time

                let count = 0;

                for (let x in patientData.data) {
                    Patients.insert(patientData.data[x]);
                    count += 1;
                }

                console.log(count + ' patients entered');
            } catch (e) {
                console.log("something went wrong with getting the patient list");
                console.log(e.message);
            }
        }
    });
    Meteor.publish('patients', function () {
        return Patients.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('patients');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/global.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// global functions go here
getAge = function (dobString) {
    let dob = new Date(dobString);
    let ageDifMs = Date.now() - dob.getTime();
    let ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
module.watch(require("../imports/global"));
Meteor.startup(() => {// code to run on server at startup
});
Meteor.methods({
    'mainMenu': function (option) {
        switch (option) {
            case 'resetDb':
                {
                    console.log('resetDbCalled');
                }
                Meteor.call('resetPatients');
                break;

            case 'clearDb':
                {
                    console.log('clearDB Called');
                }
                break;

            default:
                console.log('nothing called?');
        }
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/epss.js");
require("./collections/metrics.js");
require("./collections/observations.js");
require("./collections/pat.js");
require("./collections/patients.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvZXBzcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvbWV0cmljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvb2JzZXJ2YXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9wYXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3BhdGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2dsb2JhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRXBzcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkhUVFAiLCJDb2xsZWN0aW9uIiwiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJtZXRob2RzIiwicGFyYW1zIiwicmVtb3ZlIiwidXJsIiwiZVBTU19LZXkiLCJKU09OIiwicGFyc2UiLCJBc3NldHMiLCJnZXRUZXh0IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXNzYWdlIiwia2V5IiwiYWdlIiwic2V4IiwidG9iYWNjbyIsInNleHVhbGx5QWN0aXZlIiwiZ3JhZGUiLCJyZXMiLCJjYWxsIiwiaGVhZGVycyIsImluc2VydCIsImRhdGEiLCJwdWJsaXNoIiwiZmluZCIsImlzQ2xpZW50Iiwic3Vic2NyaWJlIiwiTWV0cmljcyIsInN0YXJ0dXAiLCJwYXRJZCIsIm1ldHJpY3NTdHJpbmciLCJtZXRyaWNzIiwiUGFwYSIsImhlYWRlciIsImNvdW50IiwieCIsIk9icyIsIlN0cmluZyIsIlBhdCIsIlBhdGllbnRzIiwiX2lkIiwidXBkYXRlUGF0Iiwib2JqZWN0IiwidXBkYXRlIiwiJHNldCIsIm5hbWUiLCJmaW5kT25lIiwiZm5hbWUiLCJsbmFtZSIsImdldEFnZSIsImRvYiIsImdlbiIsIlAiLCJwYXRpZW50U3RyaW5nIiwicGF0aWVudERhdGEiLCJkb2JTdHJpbmciLCJEYXRlIiwiYWdlRGlmTXMiLCJub3ciLCJnZXRUaW1lIiwiYWdlRGF0ZSIsIk1hdGgiLCJhYnMiLCJnZXRVVENGdWxsWWVhciIsIm9wdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFVBQUssTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUlDLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixVQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0JBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsSUFBSjtBQUFTUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNFLFNBQUtELENBQUwsRUFBTztBQUFDQyxlQUFLRCxDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQ3ZHLE1BQU1KLE9BQU8sSUFBSUMsTUFBTUssVUFBVixDQUFxQixNQUFyQixDQUFiOztBQUlQOzs7OztHQU9BLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU9FLE9BQVAsQ0FBZTtBQUVYLG1CQUFXLFVBQVVDLE1BQVYsRUFBa0I7QUFDekI7QUFDQVYsaUJBQUtXLE1BQUwsQ0FBWSxFQUFaLEVBRnlCLENBSXpCOztBQUNBLGtCQUFNQyxNQUFNLDJCQUFaLENBTHlCLENBT3pCO0FBQ0E7O0FBQ0EsZ0JBQUk7QUFDQSxvQkFBSUMsV0FBV0MsS0FBS0MsS0FBTCxDQUFXQyxPQUFPQyxPQUFQLENBQWUsZUFBZixDQUFYLENBQWY7QUFDSCxhQUZELENBRUUsT0FBTUMsQ0FBTixFQUFRO0FBQ05DLHdCQUFRQyxHQUFSLENBQVksd0ZBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUYsRUFBRUcsT0FBZDtBQUNILGFBZHdCLENBZ0J6QjtBQUNBOzs7QUFDQSxnQkFBSVIsU0FBU1MsR0FBVCxLQUFpQixjQUFyQixFQUFvQztBQUNoQ0gsd0JBQVFDLEdBQVIsQ0FBWSxxR0FBWjtBQUNBLHVCQUFPLEtBQVA7QUFDSCxhQUhELE1BR087QUFDSDtBQUNBO0FBQ0Esb0JBQUksQ0FBQ1YsTUFBTCxFQUFZO0FBQ1JBLDZCQUFTO0FBQ0xhLDZCQUFLLElBREE7QUFFTEMsNkJBQUssTUFGQTtBQUdMQyxpQ0FBUyxHQUhKO0FBSUxDLHdDQUFnQixHQUpYO0FBS0xDLCtCQUFPO0FBTEYscUJBQVQ7QUFPSCxpQkFYRSxDQVlIOzs7QUFDQWpCLHVCQUFPWSxHQUFQLEdBQWFULFNBQVNTLEdBQXRCLENBYkcsQ0FlSDs7QUFDQSxvQkFBSTtBQUNBLHdCQUFJTSxNQUFNdkIsS0FBS3dCLElBQUwsQ0FBVSxLQUFWLEVBQ05qQixHQURNLEVBRU47QUFDSWtCLGlDQUFTLGNBRGI7QUFFSXBCO0FBRkoscUJBRk0sQ0FBVjtBQVFILGlCQVRELENBU0UsT0FBT1EsQ0FBUCxFQUFVO0FBQ1JDLDRCQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDSCxpQkEzQkUsQ0E2QlA7OztBQUNBbEIscUJBQUsrQixNQUFMLENBQVlILElBQUlJLElBQWhCO0FBQ0FiLHdCQUFRQyxHQUFSLENBQVksb0JBQVo7QUFDQSx1QkFBTyxJQUFQO0FBQ0g7QUFDSixTQXpEYztBQTJEWCxxQkFBYSxZQUFXO0FBQ3BCcEIsaUJBQUtXLE1BQUwsQ0FBWSxFQUFaO0FBQ0g7QUE3RFUsS0FBZjtBQWlFSUosV0FBTzBCLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFlBQVU7QUFDN0IsZUFBT2pDLEtBQUtrQyxJQUFMLEVBQVA7QUFDSCxLQUZEO0FBR1A7O0FBRUQsSUFBSTNCLE9BQU80QixRQUFYLEVBQW9CO0FBQ2hCNUIsV0FBTzZCLFNBQVAsQ0FBaUIsTUFBakI7QUFDSCxDOzs7Ozs7Ozs7OztBQ3RGRHRDLE9BQU9DLE1BQVAsQ0FBYztBQUFDc0MsYUFBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSXBDLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixVQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0JBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsTUFBSjtBQUFXVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNJLFdBQU9ILENBQVAsRUFBUztBQUFDRyxpQkFBT0gsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUcvRyxNQUFNaUMsVUFBVSxJQUFJcEMsTUFBTUssVUFBVixDQUFxQixTQUFyQixDQUFoQjs7QUFFUDtBQUdBLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU8rQixPQUFQLENBQWUsTUFBTTtBQUNqQjtBQUNBRCxnQkFBUTFCLE1BQVIsQ0FBZSxFQUFmO0FBRUgsS0FKRDtBQU9BSixXQUFPMEIsT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVTtBQUNoQyxlQUFPSSxRQUFRSCxJQUFSLEVBQVA7QUFDSCxLQUZEO0FBSUEzQixXQUFPRSxPQUFQLENBQWU7QUFDWCxzQkFBYyxVQUFTOEIsS0FBVCxFQUFlO0FBQ3pCRixvQkFBUTFCLE1BQVIsQ0FBZSxFQUFmOztBQUNBLGdCQUFJO0FBQ0Esc0JBQU02QixnQkFBZ0J4QixPQUFPQyxPQUFQLENBQWUsYUFBZixDQUF0QjtBQUVBLHNCQUFNd0IsVUFBVUMsS0FBSzNCLEtBQUwsQ0FBV3lCLGFBQVgsRUFBMEI7QUFBQ0csNEJBQVE7QUFBVCxpQkFBMUIsQ0FBaEI7QUFDQSxvQkFBSUMsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUlDLENBQVQsSUFBY0osUUFBUVQsSUFBdEIsRUFBNEI7QUFDeEIsd0JBQUlTLFFBQVFULElBQVIsQ0FBYWEsQ0FBYixFQUFnQk4sS0FBaEIsS0FBMEJBLEtBQTlCLEVBQXFDO0FBQ2pDRixnQ0FBUU4sTUFBUixDQUFlVSxRQUFRVCxJQUFSLENBQWFhLENBQWIsQ0FBZjtBQUNBRCxpQ0FBUyxDQUFUO0FBQ0g7QUFDSjs7QUFDRHpCLHdCQUFRQyxHQUFSLENBQVl3QixRQUFRLGtCQUFwQjtBQUNILGFBWkQsQ0FZRSxPQUFPMUIsQ0FBUCxFQUFVO0FBQ1JDLHdCQUFRQyxHQUFSLENBQVksb0RBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUYsRUFBRUcsT0FBZDtBQUNBLHVCQUFPLEtBQVA7QUFDSDs7QUFDRCxtQkFBTyxJQUFQO0FBQ0g7QUFyQlUsS0FBZjtBQXVCSDs7QUFFRCxJQUFJZCxPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLFNBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNoRER0QyxPQUFPQyxNQUFQLENBQWM7QUFBQytDLFNBQUksTUFBSUE7QUFBVCxDQUFkO0FBQTZCLElBQUk3QyxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLE1BQUo7QUFBV1QsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSSxXQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUJBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHdkcsTUFBTTBDLE1BQU0sSUFBSTdDLE1BQU1LLFVBQVYsQ0FBcUIsS0FBckIsQ0FBWjs7QUFFUDtBQUdBLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU8rQixPQUFQLENBQWUsTUFBTTtBQUNqQjtBQUNBUSxZQUFJbkMsTUFBSixDQUFXLEVBQVg7QUFFSCxLQUpEO0FBT0FKLFdBQU8wQixPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLGVBQU9hLElBQUlaLElBQUosRUFBUDtBQUNILEtBRkQ7QUFJQTNCLFdBQU9FLE9BQVAsQ0FBZTtBQUNYLGtCQUFVLFVBQVM4QixLQUFULEVBQWU7QUFDckJPLGdCQUFJbkMsTUFBSixDQUFXLEVBQVg7O0FBRUEsZ0JBQUk7QUFDQSxzQkFBTW9DLFNBQVMvQixPQUFPQyxPQUFQLENBQWUsa0JBQWYsQ0FBZjtBQUVBLHNCQUFNRixRQUFRMkIsS0FBSzNCLEtBQUwsQ0FBV2dDLE1BQVgsRUFBbUI7QUFBQ0osNEJBQVE7QUFBVCxpQkFBbkIsQ0FBZDtBQUNBLG9CQUFJQyxRQUFRLENBQVo7O0FBQ0EscUJBQUssSUFBSUMsQ0FBVCxJQUFjOUIsTUFBTWlCLElBQXBCLEVBQTBCO0FBQ3RCLHdCQUFJakIsTUFBTWlCLElBQU4sQ0FBV2EsQ0FBWCxFQUFjTixLQUFkLEtBQXdCQSxLQUE1QixFQUFtQztBQUMvQk8sNEJBQUlmLE1BQUosQ0FBV2hCLE1BQU1pQixJQUFOLENBQVdhLENBQVgsQ0FBWDtBQUNBRCxpQ0FBUyxDQUFUO0FBQ0g7QUFDSjs7QUFDRHpCLHdCQUFRQyxHQUFSLENBQVl3QixRQUFRLHVCQUFwQjtBQUNILGFBWkQsQ0FZRSxPQUFPMUIsQ0FBUCxFQUFVO0FBQ1JDLHdCQUFRQyxHQUFSLENBQVkseURBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUYsRUFBRUcsT0FBZDtBQUNBLHVCQUFPLEtBQVA7QUFDSDs7QUFDRCxtQkFBTyxJQUFQO0FBQ0g7QUF0QlUsS0FBZjtBQXdCSDs7QUFFRCxJQUFJZCxPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLEtBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNqRER0QyxPQUFPQyxNQUFQLENBQWM7QUFBQ2lELGlCQUFJLE1BQUlBO0FBQVQsQ0FBZDtBQUE2QixJQUFJL0MsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLGtCQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0NBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsTUFBSjtBQUFXVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNJLG1CQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUNBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTZDLFFBQUo7QUFBYW5ELE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQzhDLHFCQUFTN0MsQ0FBVCxFQUFXO0FBQUM2QyxtQ0FBUzdDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFJbkwsTUFBTTRDLE1BQU0sSUFBSS9DLE1BQU1LLFVBQVYsQ0FBcUIsS0FBckIsQ0FBWjs7QUFFUDtBQUNBO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsbUJBQU8rQixPQUFQLENBQWUsTUFBTTtBQUNqQjtBQUNBVSw0QkFBSXJDLE1BQUosQ0FBVyxFQUFYO0FBRUgsYUFKRDtBQU1BSixtQkFBT0UsT0FBUCxDQUFlO0FBQ1gscUNBQWEsVUFBUzhCLEtBQVQsRUFBZ0I7QUFDekJwQiw0Q0FBUUMsR0FBUixDQUFZLG1CQUFaLEVBRHlCLENBRXpCO0FBQ0E7QUFFQTs7QUFDQTRCLHdDQUFJckMsTUFBSixDQUFXLEVBQVgsRUFOeUIsQ0FRekI7O0FBQ0FxQyx3Q0FBSWpCLE1BQUosQ0FBVztBQUFDbUIscURBQUtYO0FBQU4scUNBQVgsRUFUeUIsQ0FZekI7QUFFQTs7QUFDQSw2Q0FBU1ksU0FBVCxDQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkI7QUFDQUosb0RBQUlLLE1BQUosQ0FBVztBQUFDSCxpRUFBS1g7QUFBTixpREFBWCxFQUF5QjtBQUFDZSxrRUFBT0Y7QUFBUixpREFBekI7QUFDSCxxQ0FsQndCLENBb0J6Qjs7O0FBQ0FELDhDQUFVO0FBQ05JLHNEQUFNTixTQUFTTyxPQUFULENBQWlCO0FBQUNqQixtRUFBT0E7QUFBUixpREFBakIsRUFBaUNrQixLQUFqQyxHQUF5QyxHQUF6QyxHQUErQ1IsU0FBU08sT0FBVCxDQUFpQjtBQUFDakIsbUVBQU9BO0FBQVIsaURBQWpCLEVBQWlDbUIsS0FEaEY7QUFFTm5DLHFEQUFLb0MsT0FBT1YsU0FBU08sT0FBVCxDQUFpQjtBQUFDakIsbUVBQU9BO0FBQVIsaURBQWpCLEVBQWlDcUIsR0FBeEM7QUFGQyxxQ0FBVixFQXJCeUIsQ0EwQnpCOztBQUNBVCw4Q0FBVTtBQUNOVSxxREFBS1osU0FBU08sT0FBVCxDQUFpQjtBQUFDakIsbUVBQU9BO0FBQVIsaURBQWpCO0FBREMscUNBQVYsRUEzQnlCLENBZ0NyQztBQUNZO0FBQ0E7QUFDQTs7QUFFQWhDLDJDQUFPc0IsSUFBUCxDQUFZLFFBQVosRUFBc0JVLEtBQXRCLEVBckN5QixDQXVDckM7QUFDWTs7QUFFQWhDLDJDQUFPc0IsSUFBUCxDQUFZLFlBQVosRUFBMEJVLEtBQTFCLEVBMUN5QixDQThDckM7QUFFWTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7QUFXQSx3Q0FBSXVCLElBQUlkLElBQUlRLE9BQUosQ0FBWSxFQUFaLENBQVI7QUFFQSx3Q0FBSTlDLFNBQVM7QUFDVGEscURBQUtvQyxPQUFPRyxFQUFFRCxHQUFGLENBQU1ELEdBQWIsQ0FESTtBQUVUcEMscURBQUtzQyxFQUFFRCxHQUFGLENBQU1yQyxHQUZGO0FBR1Q7QUFDQTtBQUNBO0FBQ0FHLHVEQUFPO0FBTkUscUNBQWI7QUFTQXBCLDJDQUFPc0IsSUFBUCxDQUFZLFNBQVosRUFBdUJuQixNQUF2QjtBQUNILHlCQTNFVTtBQTZFWCxvQ0FBWSxZQUFXO0FBQ25Cc0Msd0NBQUlyQyxNQUFKLENBQVcsRUFBWDtBQUNIO0FBL0VVLGFBQWY7QUFtRklKLG1CQUFPMEIsT0FBUCxDQUFlLEtBQWYsRUFBc0IsWUFBVTtBQUM1QiwrQkFBT2UsSUFBSWQsSUFBSixFQUFQO0FBQ0gsYUFGRDtBQUdQOztBQUVELElBQUkzQixPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLG1CQUFPNkIsU0FBUCxDQUFpQixLQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDNUdEdEMsT0FBT0MsTUFBUCxDQUFjO0FBQUNrRCxjQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJaEQsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxNQUFKO0FBQVdULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ksV0FBT0gsQ0FBUCxFQUFTO0FBQUNHLGlCQUFPSCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRWpILE1BQU02QyxXQUFXLElBQUloRCxNQUFNSyxVQUFWLENBQXFCLFVBQXJCLENBQWpCOztBQUdQO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVyQkQsV0FBTytCLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBRUE7QUFDQSxZQUFJVyxTQUFTZixJQUFULEdBQWdCVSxLQUFoQixPQUE0QixDQUFoQyxFQUFrQztBQUM5QnpCLG9CQUFRQyxHQUFSLENBQVksb0NBQVo7QUFDQWIsbUJBQU9zQixJQUFQLENBQVksZUFBWjtBQUVILFNBSkQsTUFJTTtBQUNGVixvQkFBUUMsR0FBUixDQUFZLG9DQUFaO0FBQ0g7QUFFSixLQVpEO0FBY0liLFdBQU9FLE9BQVAsQ0FBZTtBQUNYLHlCQUFpQixZQUFXO0FBQ3hCd0MscUJBQVN0QyxNQUFULENBQWdCLEVBQWhCO0FBQ0gsU0FIVTtBQUtYLHlCQUFpQixZQUFXO0FBQ3hCUSxvQkFBUUMsR0FBUixDQUFZLHNCQUFaO0FBQ0E2QixxQkFBU3RDLE1BQVQsQ0FBZ0IsRUFBaEIsRUFGd0IsQ0FJeEI7QUFDQTtBQUNBO0FBRUE7O0FBRUEsZ0JBQUk7QUFDQSxzQkFBTW9ELGdCQUFnQi9DLE9BQU9DLE9BQVAsQ0FBZSxjQUFmLENBQXRCLENBREEsQ0FFQTtBQUNBO0FBQ0E7O0FBRUEsc0JBQU0rQyxjQUFjdEIsS0FBSzNCLEtBQUwsQ0FBV2dELGFBQVgsRUFBMEI7QUFBQ3BCLDRCQUFRO0FBQVQsaUJBQTFCLENBQXBCLENBTkEsQ0FRQTtBQUNBOztBQUNBLG9CQUFJQyxRQUFRLENBQVo7O0FBQ0EscUJBQUssSUFBSUMsQ0FBVCxJQUFjbUIsWUFBWWhDLElBQTFCLEVBQWdDO0FBQzVCaUIsNkJBQVNsQixNQUFULENBQWdCaUMsWUFBWWhDLElBQVosQ0FBaUJhLENBQWpCLENBQWhCO0FBQ0FELDZCQUFTLENBQVQ7QUFDSDs7QUFDRHpCLHdCQUFRQyxHQUFSLENBQVl3QixRQUFRLG1CQUFwQjtBQUVILGFBakJELENBaUJFLE9BQU8xQixDQUFQLEVBQVU7QUFDUkMsd0JBQVFDLEdBQVIsQ0FBWSxvREFBWjtBQUNBRCx3QkFBUUMsR0FBUixDQUFZRixFQUFFRyxPQUFkO0FBQ0g7QUFDSjtBQXBDVSxLQUFmO0FBd0NJZCxXQUFPMEIsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBVTtBQUNqQyxlQUFPZ0IsU0FBU2YsSUFBVCxFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUkzQixPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLFVBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUN2RUQ7QUFFQXVCLFNBQVMsVUFBU00sU0FBVCxFQUFtQjtBQUN4QixRQUFJTCxNQUFNLElBQUlNLElBQUosQ0FBVUQsU0FBVixDQUFWO0FBQ0EsUUFBSUUsV0FBV0QsS0FBS0UsR0FBTCxLQUFhUixJQUFJUyxPQUFKLEVBQTVCO0FBQ0EsUUFBSUMsVUFBVSxJQUFJSixJQUFKLENBQVNDLFFBQVQsQ0FBZDtBQUNBLFdBQU9JLEtBQUtDLEdBQUwsQ0FBU0YsUUFBUUcsY0FBUixLQUEwQixJQUFuQyxDQUFQO0FBQ0gsQ0FMRCxDOzs7Ozs7Ozs7OztBQ0ZBLElBQUlsRSxNQUFKO0FBQVdULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ksV0FBT0gsQ0FBUCxFQUFTO0FBQUNHLGlCQUFPSCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStETixPQUFPSSxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUcxRUksT0FBTytCLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRDtBQUlBL0IsT0FBT0UsT0FBUCxDQUFlO0FBQ1gsZ0JBQVksVUFBU2lFLE1BQVQsRUFBZ0I7QUFDeEIsZ0JBQU9BLE1BQVA7QUFDSSxpQkFBSyxTQUFMO0FBQ0k7QUFBQ3ZELDRCQUFRQyxHQUFSLENBQVksZUFBWjtBQUE2QjtBQUM5QmIsdUJBQU9zQixJQUFQLENBQVksZUFBWjtBQUNBOztBQUNKLGlCQUFLLFNBQUw7QUFDSTtBQUFDViw0QkFBUUMsR0FBUixDQUFZLGdCQUFaO0FBQThCO0FBQy9COztBQUNKO0FBQ0lELHdCQUFRQyxHQUFSLENBQVksaUJBQVo7QUFUUjtBQVdIO0FBYlUsQ0FBZixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmV4cG9ydCBjb25zdCBFcHNzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2Vwc3MnKTtcclxuaW1wb3J0IHtIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnXHJcblxyXG5cclxuLypcclxuUGxlYXNlIHJldmlldyB0aGUgQUhSUSBDb3B5cmlnaHQgYW5kIERpc2NsYWltZXIgbm90aWNlIGJlZm9yZSB1c2luZyB0aGUgQVBJOiBodHRwczovL3d3dy51c3ByZXZlbnRpdmVzZXJ2aWNlc3Rhc2tmb3JjZS5vcmcvUGFnZS9OYW1lL2NvcHlyaWdodC1ub3RpY2UuXHJcbkluc3RydWN0aW9ucyBmb3IgdXNlIGFuZCBhY2Nlc3MgaW5mb3JtYXRpb24gY2FuIGJlIGZvdW5kIGF0OlxyXG7igKJcdEluc3RydWN0aW9uIGZvciBVc2U6ICBodHRwOi8vZXBzcy5haHJxLmdvdi9QREEvZG9jcy9lUFNTX0RhdGFfQVBJX1dJX3dMaW5rLnBkZlxyXG7igKJcdFVSTDogIGh0dHA6Ly9lcHNzZGF0YS5haHJxLmdvdi9cclxuICovXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAgICAgICAnZ2V0RXBzcyc6IGZ1bmN0aW9uIChwYXJhbXMpIHtcclxuICAgICAgICAgICAgLy9WZXJ5IGZpcnN0LCBjbGVhbiBvdXQgdGhlIGVQU1MgZGF0YVxyXG4gICAgICAgICAgICBFcHNzLnJlbW92ZSh7fSk7XHJcblxyXG4gICAgICAgICAgICAvLyBGaXJzdCwgd2UgbmVlZCB0byBrbm93IHRoZSBlcHNzIGFwaSB1cmxcclxuICAgICAgICAgICAgY29uc3QgdXJsID0gJ2h0dHA6Ly9lcHNzZGF0YS5haHJxLmdvdi8nO1xyXG5cclxuICAgICAgICAgICAgLy8gTmV4dCwgZ2V0IHRoZSBlUFNTIGtleSBmcm9tIHRoZSB0ZXh0IGZpbGUgaW4gdGhlIFByaXZhdGUgZm9sZGVyLlxyXG4gICAgICAgICAgICAvLyB0aGlzIGZvbGRlciB3aWxsIG5vdCBzeW5jIHdpdGggZ2l0IGFzIGl0IGlzIGluIHRoZSAuZ2l0aWdub3JlXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZVBTU19LZXkgPSBKU09OLnBhcnNlKEFzc2V0cy5nZXRUZXh0KCdlUFNTX0tleS5qc29uJykpXHJcbiAgICAgICAgICAgIH0gY2F0Y2goZSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcgZVBTUyBrZXkgZmFpbGVkLiBQbGVhc2UgbWFrZSBzdXJlIGVQU1NfS2V5Lmpzb24gZXhpc3RzIGluIHRoZSBwcml2YXRlIGZvbGRlci4nKVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBJZiB0aGUga2V5IGlzIGJsYW5rIG9yIG5vdCB1cGRhdGVkLCB3ZSBjYW5ub3QgY29udGludWUuLlxyXG4gICAgICAgICAgICAvL2xldCBibGFua0tleXMgPSBbJycsJ1BVVF9LRVlfSEVSRSddXHJcbiAgICAgICAgICAgIGlmIChlUFNTX0tleS5rZXkgPT09ICdQVVRfS0VZX0hFUkUnKXtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdlUFNTIEtleSBub3QgZm91bmQgb3IgaW52YWxpZC0gcGxlYXNlIGlucHV0IHlvdXIgZVBTUyBrZXkgaW50byBlUFNTX0tleS5qc29uIGZpbGUgaW4gcHJpdmF0ZSBmb2xkZXInKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyBJZiBubyBwYXJhbXMgYXJlIHBhc3NlZCwgcG9wdWxhdGUgc29tZSBkZWZhdWx0cyBmb3IgdGVzdGluZ1xyXG4gICAgICAgICAgICAgICAgLy8gdG9kbzogcmVtb3ZlIGRlZmF1bHRzIGFuZCBpbnN0ZWFkIHJldHVybiBhbiBlcnJvciAtIHRoaXMgc2hvdWxkIGJlIGZldGNoZWQgZnJvbSBwYXRpZW50IGRhdGFcclxuICAgICAgICAgICAgICAgIGlmICghcGFyYW1zKXtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZTogJzE4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V4OiAnTWFsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvYmFjY286ICdOJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V4dWFsbHlBY3RpdmU6ICdOJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhZGU6ICdBJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIGxhc3RseSwgaW5zZXJ0IGtleSBpbnRvIHBhcmFtc1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zLmtleSA9IGVQU1NfS2V5LmtleTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBUcnkgdG8gZmV0Y2ggdGhlIGVQU1MgcmVjb21tZW5kYXRpb25zIGJhc2VkIG9uIHRoZSBwYXJhbXMuXHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXMgPSBIVFRQLmNhbGwoJ2dldCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczogJ2FjY2VwdDoganNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuXHJcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vY29uc29sZS5kaXIocmVzLmRhdGEpXHJcbiAgICAgICAgICAgIEVwc3MuaW5zZXJ0KHJlcy5kYXRhKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZVBTUyBEYXRhIGluc2VydGVkJylcclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgICAgICAnY2xlYXJFcHNzJzogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgICAgIEVwc3MucmVtb3ZlKHt9KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9KTtcclxuXHJcbiAgICAgICAgTWV0ZW9yLnB1Ymxpc2goJ2Vwc3MnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICByZXR1cm4gRXBzcy5maW5kKClcclxuICAgICAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ2Vwc3MnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBNZXRyaWNzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ21ldHJpY3MnKTtcclxuXHJcbi8vIE9uY2Ugb3VyIHBhdGllbnQgaXMgc2VsZWN0ZWQgd2UgbmVlZCB0byBwb3B1bGF0ZSBvdXIgcGF0IGNvbGxlY3Rpb24uXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuICAgIE1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAgICAgICAvLyBjbGVhciBhbnQgUGF0IGRhdGEgYXQgc3RhcnR1cCBhcyB0aGVyZSBzaG91bGQgbm90IGJlIGFueSBwYXRpZW50IGluIGNvbnRleHQuXHJcbiAgICAgICAgTWV0cmljcy5yZW1vdmUoe30pXHJcblxyXG4gICAgfSk7XHJcblxyXG5cclxuICAgIE1ldGVvci5wdWJsaXNoKCdtZXRyaWNzJywgZnVuY3Rpb24oKXtcclxuICAgICAgICByZXR1cm4gTWV0cmljcy5maW5kKClcclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnZ2V0TWV0cmljcyc6IGZ1bmN0aW9uKHBhdElkKXtcclxuICAgICAgICAgICAgTWV0cmljcy5yZW1vdmUoe30pO1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbWV0cmljc1N0cmluZyA9IEFzc2V0cy5nZXRUZXh0KCdtZXRyaWNzLmNzdicpO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IG1ldHJpY3MgPSBQYXBhLnBhcnNlKG1ldHJpY3NTdHJpbmcsIHtoZWFkZXI6IHRydWV9KTtcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIG1ldHJpY3MuZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXRyaWNzLmRhdGFbeF0ucGF0SWQgPT09IHBhdElkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE1ldHJpY3MuaW5zZXJ0KG1ldHJpY3MuZGF0YVt4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IDFcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhjb3VudCArICcgbWV0cmljcyBlbnRlcmVkJylcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzb21ldGhpbmcgd2VudCB3cm9uZyB3aXRoIHBhcnNpbmcgdGhlIG1ldHJpY3MgZGF0YVwiKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUubWVzc2FnZSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnbWV0cmljcycpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IE9icyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdvYnMnKTtcclxuXHJcbi8vIE9uY2Ugb3VyIHBhdGllbnQgaXMgc2VsZWN0ZWQgd2UgbmVlZCB0byBwb3B1bGF0ZSBvdXIgcGF0IGNvbGxlY3Rpb24uXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuICAgIE1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAgICAgICAvLyBjbGVhciBhbnkgZGF0YSBhdCBzdGFydHVwIGFzIHRoZXJlIHNob3VsZCBub3QgYmUgYW55IHBhdGllbnQgaW4gY29udGV4dC5cclxuICAgICAgICBPYnMucmVtb3ZlKHt9KVxyXG5cclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBNZXRlb3IucHVibGlzaCgnb2JzJywgZnVuY3Rpb24oKXtcclxuICAgICAgICByZXR1cm4gT2JzLmZpbmQoKVxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICdnZXRPYnMnOiBmdW5jdGlvbihwYXRJZCl7XHJcbiAgICAgICAgICAgIE9icy5yZW1vdmUoe30pO1xyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IFN0cmluZyA9IEFzc2V0cy5nZXRUZXh0KCdvYnNlcnZhdGlvbnMuY3N2Jyk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29uc3QgcGFyc2UgPSBQYXBhLnBhcnNlKFN0cmluZywge2hlYWRlcjogdHJ1ZX0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gcGFyc2UuZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYXJzZS5kYXRhW3hdLnBhdElkID09PSBwYXRJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBPYnMuaW5zZXJ0KHBhcnNlLmRhdGFbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCArPSAxXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY291bnQgKyAnIG9ic2VydmF0aW9ucyBlbnRlcmVkJylcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzb21ldGhpbmcgd2VudCB3cm9uZyB3aXRoIHBhcnNpbmcgdGhlIG9ic2VydmF0aW9ucyBkYXRhXCIpXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnb2JzJylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmltcG9ydCB7UGF0aWVudHN9IGZyb20gXCIuL3BhdGllbnRzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgUGF0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3BhdCcpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBjb2xsZWN0aW9ucy4gVGhlIG1haW4gZnVuY3Rpb25zIGZvciB0aGlzIGFyZSBoYW5kbGVkIGhlcmVcclxuLy8gV2l0aCByZWZlcmVuY2VzIHRvIHRoZSBvdGhlciBjb2xsZWN0aW9ucyB3aGVuIG5lZWRlZC5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFudCBQYXQgZGF0YSBhdCBzdGFydHVwIGFzIHRoZXJlIHNob3VsZCBub3QgYmUgYW55IHBhdGllbnQgaW4gY29udGV4dC5cclxuICAgICAgICBQYXQucmVtb3ZlKHt9KVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAndXBkYXRlUGF0JzogZnVuY3Rpb24ocGF0SWQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVQYXQgd2FzIHJ1blwiKTtcclxuICAgICAgICAgICAgLy8gT2ssIEZpcnN0LCBsZXQncyBmZXRjaCB0aGUgb3RoZXIgZGF0YSBhYm91dCB0aGUgcGF0aWVudFxyXG4gICAgICAgICAgICAvLyBXZSdsbCBzdG9yZSB0aGlzIHNpbmdsZSBwYXRpZW50J3MgZGF0YSBpbiBhIG5ldyBDb2xsZWN0aW9uLCBwYXRcclxuXHJcbiAgICAgICAgICAgIC8vIElmIGFueSBvbGQgZGF0YSBpcyBpbiBQYXQsIG5lZWQgdG8gY2xlYXIgaXRcclxuICAgICAgICAgICAgUGF0LnJlbW92ZSh7fSlcclxuXHJcbiAgICAgICAgICAgIC8vIE5vdywgbGV0J3Mgc3RhcnQgZnJlc2ggd2l0aCBvdXIgY3VycmVudGx5IHNlbGVjdGVkIHBhdGllbnRcclxuICAgICAgICAgICAgUGF0Lmluc2VydCh7X2lkOiBwYXRJZH0pO1xyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIHRoZXNlIGhlbHBlciBmdW5jdGlvbnMgd2lsbCBtYWtlIGluc2VydGluZyBhbmQgcmVhZGluZyBkYXRhIGVhc2llclxyXG5cclxuICAgICAgICAgICAgLy8gVGhpcyBvbmUgYWRkcyBhIG5ldyBvYmplY3QgdG8gdGhlIGRhdGFiYXNlIGNvbGxlY3Rpb24gdW5kZXIgdGhpcyBwYXRJZFxyXG4gICAgICAgICAgICBmdW5jdGlvbiB1cGRhdGVQYXQob2JqZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG9iamVjdClcclxuICAgICAgICAgICAgICAgIFBhdC51cGRhdGUoe19pZDogcGF0SWR9LCB7JHNldDogIG9iamVjdH0pXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vZS5nLiAtIGZpcnN0IGxldCdzIHVzZSBvdXIgXCJQYXRpZW50c1wiIGxpc3QgYW5kIGdldCB0aGUgZnVsbCBuYW1lIGFuZCBhbHNvIHRoZSBhZ2VcclxuICAgICAgICAgICAgdXBkYXRlUGF0KHtcclxuICAgICAgICAgICAgICAgIG5hbWU6IFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pLmZuYW1lICsgJyAnICsgUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSkubG5hbWUsXHJcbiAgICAgICAgICAgICAgICBhZ2U6IGdldEFnZShQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KS5kb2IpXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgLy8gTGV0J3MgdGhyb3cgZXZlcnl0aGluZyBlbHNlIHRoYXQgaXMgaW4gdGhlIFwiUGF0aWVudHNcIiBjb2xsZWN0aW9uIGFib3V0IG91ciBwYXRpZW50IGluIGEgZ2VuIChmb3IgXCJnZW5lcmFsXCIpIG9iamVjdFxyXG4gICAgICAgICAgICB1cGRhdGVQYXQoe1xyXG4gICAgICAgICAgICAgICAgZ2VuOiBQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG4vLyBTaW11bGF0ZSBhIGNhbGwgdG8gYSB0YWJsZSB0aGF0IGhvbGRzIHBhdGllbnQgT2JzZXJ2YXRpb25zXHJcbiAgICAgICAgICAgIC8vIFRoZSBtZXRlb3IuY2FsbCBhY3R1YWxseSBqdXN0IHJlYWRzIGZyb20gdGhlIENTViwgYnV0IGl0IGRvZXMgdGhlbiBmaWx0ZXIgYnkgdGhlIHBhdElkXHJcbiAgICAgICAgICAgIC8vIHNvcnQgb2YgbGlrZSBob3cgYSByZWFsIFNRTCBjYWxsIHdvdWxkIHdvcmsuXHJcbiAgICAgICAgICAgIC8vIFdlIHdpbGwgc3RvcmUgdGhpcyBpbiBvdXIgUGF0IGNvbGxlY3Rpb24gdW5kZXIgdGhlIGdyb3VwICdvYnMnXHJcblxyXG4gICAgICAgICAgICBNZXRlb3IuY2FsbCgnZ2V0T2JzJywgcGF0SWQpXHJcblxyXG4vLyBOb3cgc2ltdWxhdGUgYSBjYWxsIGZvciBwYXRpZW50IE1ldHJpY3NcclxuICAgICAgICAgICAgLy8gdGhpcyB3aWxsIGdvIGluIGEgc2VwYXJhdGUgY29sbGVjdGlvbiBmb3Igc2VhcmNoaW5nLCBzbyBqdXN0IGlzIGEgbWV0ZW9yLmNhbGxcclxuXHJcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKCdnZXRNZXRyaWNzJywgcGF0SWQpXHJcblxyXG5cclxuXHJcbi8vIFdlIHdhbnQgdG8gdXBkYXRlIG91ciBlUFNTIHJlY29tbWVuZGF0aW9ucyB3aXRoIG91ciBwYXRpZW50IGluZm9ybWF0aW9uLlxyXG5cclxuICAgICAgICAgICAgLy8gV2UgbmVlZCB0byBidWlsZCBvdXIgcGFyYW0gb2JqZWN0IGZvciB0aGUgZVBTUyBjYWxsXHJcbiAgICAgICAgICAgIC8vIEhlcmUgaXMgdGhlIHRlbXBsYXRlIHdpdGggdGhlIHBvc3NpYmxlIHZhbHVlczpcclxuXHJcbiAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgIHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgYWdlOiAnMTgnLCAgLS1hbnkgaW50ZWdlclxyXG4gICAgICAgICAgICBzZXg6ICdNYWxlJywgLS0gKE1hbGUsIEZlbWFsZSlcclxuICAgICAgICAgICAgcHJlZ25hbnQ6ICdOJyAtLSAoWSxOKSAtIHJlcXVpcmVzIEZlbWFsZSBzZXggdG8gYmUgcHJlc2VudFxyXG4gICAgICAgICAgICB0b2JhY2NvOiAnTicsIC0tIChZLE4pXHJcbiAgICAgICAgICAgIHNleHVhbGx5QWN0aXZlOiAnTicgLS0gKFksTilcclxuICAgICAgICAgICAgZ3JhZGU6ICdBJyAoQSxCLEMsRCwgSSkgLS0gY2FuIGJlIHJlcGVhdGVkIHRvIGluY2x1ZGUgbXVsdGlwbGUgdmFsdWVzXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICovXHJcblxyXG4gICAgICAgICAgICBsZXQgUCA9IFBhdC5maW5kT25lKHt9KVxyXG5cclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIGFnZTogZ2V0QWdlKFAuZ2VuLmRvYiksXHJcbiAgICAgICAgICAgICAgICBzZXg6IFAuZ2VuLnNleCxcclxuICAgICAgICAgICAgICAgIC8vcHJlZ25hbnQ6ICdOJyAtLSAoWSxOKSAtIHJlcXVpcmVzIEZlbWFsZSBzZXggdG8gYmUgcHJlc2VudFxyXG4gICAgICAgICAgICAgICAgLy90b2JhY2NvOiAnTicsIC0tIChZLE4pXHJcbiAgICAgICAgICAgICAgICAvL3NleHVhbGx5QWN0aXZlOiAnTicgLS0gKFksTilcclxuICAgICAgICAgICAgICAgIGdyYWRlOiAnQSdcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKCdnZXRFcHNzJywgcGFyYW1zKVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgICdjbGVhclBhdCc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBQYXQucmVtb3ZlKHt9KVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdwYXQnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICByZXR1cm4gUGF0LmZpbmQoKVxyXG4gICAgICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgncGF0JylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmV4cG9ydCBjb25zdCBQYXRpZW50cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwYXRpZW50cycpO1xyXG5cclxuXHJcbi8vIFBvcHVsYXRlIG91ciBsb2NhbCBwYXRpZW50IGRhdGFiYXNlIHdpdGggc29tZSBwcmUtYnVpbHQgcGF0aWVudCBkYXRhLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAgIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXHJcblxyXG4gICAgLy8gT25seSBkbyB0aGlzIG9uIHN0YXJ0dXAgaWYgdGhlIGRiIGlzIGVtcHR5XHJcbiAgICBpZiAoUGF0aWVudHMuZmluZCgpLmNvdW50KCkgPT09IDApe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZm91bmQgbm8gcGF0aWVudHMtIGdldHRpbmcgZGF0YS4uLlwiKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgncmVzZXRQYXRpZW50cycpXHJcblxyXG4gICAgfSBlbHNle1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdmb3VuZCBwYXRpZW50cyBhbHJlYWR5IGluIGRhdGFiYXNlJylcclxuICAgIH1cclxuXHJcbn0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnY2xlYXJQYXRpZW50cyc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBQYXRpZW50cy5yZW1vdmUoe30pXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgJ3Jlc2V0UGF0aWVudHMnOiBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3Jlc2V0dGluZyBwYXRpZW50IERCJyk7XHJcbiAgICAgICAgICAgIFBhdGllbnRzLnJlbW92ZSh7fSk7XHJcblxyXG4gICAgICAgICAgICAvLyBUaGUgcGF0aWVudCBkYXRhIGlzIHN0b3JlZCBhcyBhIENTViBmaWxlIGluIG91ciBcInByaXZhdGVcIiBmb2xkZXJcclxuICAgICAgICAgICAgLy8gVGhpcyBhbGxvd3MgdXMgdG8gcXVpY2sgYW5kIGRpcnR5IHJlcGxpY2F0ZSB3aGF0IG1pZ2h0IGJlIGEgdmlldyBvbiBBY3VlcmVcclxuICAgICAgICAgICAgLy8gSXQgd291bGQgcHJvYmFibHkgYmUgZWFzaWVyIGlmIHRoaXMgd291bGQganVzdCBwdWxsIGZyb20gQWN1ZXJlLi4uXHJcblxyXG4gICAgICAgICAgICAvL0ZpcnN0LCBpbXBvcnQgdGhlIGNzdiBhcyBhIHN0cmluZzogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMTc0NTM4NDgvaXMtdGhlcmUtYS13YXktdG8taW1wb3J0LXN0cmluZ3MtZnJvbS1hLXRleHQtZmlsZS1pbi1qYXZhc2NyaXB0LW1ldGVvclxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhdGllbnRTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgncGF0aWVudHMuY3N2Jyk7XHJcbiAgICAgICAgICAgICAgICAvLyBwYXRpZW50U3RyaW5nIHdpbGwgY29udGFpbiB0aGUgZGF0YSBhcyBvbmUgbG9uZyBDU1Ygc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAvLyBXZSBuZWVkIHRvIHBhcnNlIGl0IHRvIGEgSlNPTiBvYmplY3QuXHJcbiAgICAgICAgICAgICAgICAvLyB3aWxsIHVzZSB0aGUgUGFwYSBwYXJzZSBwYWNrYWdlIHRvIGRvIHRoaXMuLi5cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXRpZW50RGF0YSA9IFBhcGEucGFyc2UocGF0aWVudFN0cmluZywge2hlYWRlcjogdHJ1ZX0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIFdlIHdpbGwgc3RvcmUgdGhlIGRhdGEgaW4gb3VyIG93biBNb25nbyBjb2xsZWN0aW9uIHRoYXQgd2UgZGVmaW5lZCBhYm92ZS0gUGF0aWVudHNcclxuICAgICAgICAgICAgICAgIC8vIFByZWZlciB0byBzdG9yZSBlYWNoIHBhdGllbnQgYXMgdGhlaXIgb3duIFwiZG9jdW1lbnRcIiB0byBtYWtlIHNlYXJjaGVzIGFuZCBzdHVmZiBlYXNpZXIsIHNvIGxvb3AgdGhyb3VnaCB0aGUgQ1NWIGRhdGEgYW5kIGluc2VydCBvbmUgYXQgYSB0aW1lXHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBwYXRpZW50RGF0YS5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgUGF0aWVudHMuaW5zZXJ0KHBhdGllbnREYXRhLmRhdGFbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IDFcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBwYXRpZW50cyBlbnRlcmVkJylcclxuXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBnZXR0aW5nIHRoZSBwYXRpZW50IGxpc3RcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdwYXRpZW50cycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHJldHVybiBQYXRpZW50cy5maW5kKClcclxuICAgICAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ3BhdGllbnRzJylcclxufSIsIi8vIGdsb2JhbCBmdW5jdGlvbnMgZ28gaGVyZVxyXG5cclxuZ2V0QWdlID0gZnVuY3Rpb24oZG9iU3RyaW5nKXtcclxuICAgIGxldCBkb2IgPSBuZXcgRGF0ZSAoZG9iU3RyaW5nKVxyXG4gICAgbGV0IGFnZURpZk1zID0gRGF0ZS5ub3coKSAtIGRvYi5nZXRUaW1lKClcclxuICAgIGxldCBhZ2VEYXRlID0gbmV3IERhdGUoYWdlRGlmTXMpXHJcbiAgICByZXR1cm4gTWF0aC5hYnMoYWdlRGF0ZS5nZXRVVENGdWxsWWVhcigpLSAxOTcwKVxyXG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCAnLi4vaW1wb3J0cy9nbG9iYWwnO1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXHJcbn0pO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgJ21haW5NZW51JzogZnVuY3Rpb24ob3B0aW9uKXtcclxuICAgICAgICBzd2l0Y2gob3B0aW9uKXtcclxuICAgICAgICAgICAgY2FzZSAncmVzZXREYic6XHJcbiAgICAgICAgICAgICAgICB7Y29uc29sZS5sb2coJ3Jlc2V0RGJDYWxsZWQnKX1cclxuICAgICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdyZXNldFBhdGllbnRzJylcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdjbGVhckRiJzpcclxuICAgICAgICAgICAgICAgIHtjb25zb2xlLmxvZygnY2xlYXJEQiBDYWxsZWQnKX1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vdGhpbmcgY2FsbGVkPycpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KSJdfQ==
