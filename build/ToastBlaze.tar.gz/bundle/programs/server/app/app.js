var require = meteorInstall({"collections":{"epss.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/epss.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Epss: () => Epss
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let HTTP;
module.watch(require("meteor/http"), {
    HTTP(v) {
        HTTP = v;
    }

}, 1);
let Pat;
module.watch(require("./pat"), {
    Pat(v) {
        Pat = v;
    }

}, 2);
let Observations;
module.watch(require("./observations"), {
    Observations(v) {
        Observations = v;
    }

}, 3);
const Epss = new Mongo.Collection('epss');

/*
This is where we will fetch and store the AHRQ EPSS recommendations
use of this requires an ePSS key, and there is some logic to fetch and validate the key here
The key should be placed in the Private folder, in a file called 'ePSS_Key.json'
THe file should be a simple json object:

{
  "Key":"PUT_KEY_HERE"
}

Please review the AHRQ Copyright and Disclaimer notice before using the API: https://www.uspreventiveservicestaskforce.org/Page/Name/copyright-notice.
Instructions for use and access information can be found at:
•	Instruction for Use:  http://epss.ahrq.gov/PDA/docs/ePSS_Data_API_WI_wLink.pdf
•	URL:  http://epssdata.ahrq.gov/
 */if (Meteor.isServer) {
    Meteor.methods({
        'getEpss': function () {
            // only update if empty- updatePat should empty this collection...
            if (Epss.find().count() > 0) {
                return;
            } // First, we need to know the epss api url


            const url = 'http://epssdata.ahrq.gov/';
            let ePSS_Key = ''; // Next, get the ePSS key from the text file in the Private folder.
            // this file will not sync with git if it is in the .gitignore

            try {
                ePSS_Key = JSON.parse(Assets.getText('ePSS_Key.json')); // If the key is blank or not updated, we cannot continue..

                if (ePSS_Key.key === 'PUT_KEY_HERE') {
                    console.log('ePSS Key not found or invalid- please input your ePSS key into ePSS_Key.json file in private folder');
                    return;
                }
            } catch (e) {
                console.log('Fetching ePSS key failed. Please make sure ePSS_Key.json exists in the private folder.');
                console.log(e.message);
            } // get info from Pat, Observations collections


            let sex = Pat.findOne().gen.sex;
            let age = getAge(Pat.findOne().gen.dob);
            let tobacco = '';

            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Smoking Status'
            })) {
                tobacco = Observations.findOne({
                    category: 'socialHistory',
                    name: 'Smoking Status'
                }).value;
            }

            let sexuallyActive = '';
            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            })) sexuallyActive = Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            }).value;
            let pregnant = null;

            if (sex === 'F') {
                pregnant = 'N'; // placeholder for real logic
            } //build the params object


            let params = {
                age: age,
                sex: sex,
                pregnant: pregnant,
                // 'N' -- (Y,N) - requires Female sex to be present
                tobacco: tobacco,
                sexuallyActive: sexuallyActive,
                grade: ['A', 'B']
            }; // lastly, insert key into params

            params.key = ePSS_Key.key; // Try to fetch the ePSS recommendations based on the params.

            try {
                HTTP.call('get', url, {
                    headers: 'accept: json',
                    params
                }, function (err, result) {
                    if (err) {
                        throw err;
                    } else {
                        //only want to store the specific recommendations array objects
                        let epssCount = 0;
                        let recs = result.data.specificRecommendations;

                        for (let x in recs) {
                            Epss.insert(recs[x]);
                            epssCount += 1;
                        }

                        console.log(epssCount + ' ePSS recs inserted');
                        return true;
                    }
                });
            } catch (e) {
                console.log(e);
            }
        },
        'clearEpss': function () {
            Epss.remove({});
        }
    }); // Publication function from the server- this let's us define what the client-side db gets

    Meteor.publish('epss', function () {
        // we will return the entire collection.
        return Epss.find();
    });
} // as the client, subscribes to the above publication


if (Meteor.isClient) {
    Meteor.subscribe('epss');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metrics.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/metrics.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Metrics: () => Metrics
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Metrics = new Mongo.Collection('metrics');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Metrics.remove({});
    });
    Meteor.publish('metrics', function () {
        return Metrics.find();
    });
    Meteor.methods({
        'getMetrics': function (patId) {
            Metrics.remove({});

            try {
                const metricsString = Assets.getText('metrics.csv');
                const metrics = Papa.parse(metricsString, {
                    header: true
                });
                let count = 0;

                for (let x in metrics.data) {
                    if (metrics.data[x].patId === patId) {
                        Metrics.insert(metrics.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' metrics entered');
            } catch (e) {
                console.log("something went wrong with parsing the metrics data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('metrics');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Observations: () => Observations
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Observations = new Mongo.Collection('obs');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear any data at startup as there should not be any patient in context.
        Observations.remove({});
    });
    Meteor.publish('obs', function () {
        return Observations.find();
    });
    Meteor.methods({
        'getObs': function (patId) {
            Observations.remove({});

            try {
                const String = Assets.getText('observations.csv');
                const parse = Papa.parse(String, {
                    header: true
                });
                let count = 0;

                for (let x in parse.data) {
                    if (parse.data[x].patId === patId) {
                        Observations.insert(parse.data[x]);
                        count += 1;
                    }
                } // Observations are in there, but the date field is just a string.
                // This will transform the string in the "date" field into a javascript date.


                let all = Observations.find().fetch();

                for (let x in all) {
                    let _id = all[x]._id;
                    let date = new Date(all[x].date); //console.log(date)

                    Observations.upsert({
                        _id: _id
                    }, {
                        $set: {
                            date: date
                        }
                    });
                }

                console.log(count + ' observations entered');
            } catch (e) {
                console.log("something went wrong with parsing the observations data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('obs');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pat.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/pat.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
            Pat: () => Pat
});
let Mongo;
module.watch(require("meteor/mongo"), {
            Mongo(v) {
                        Mongo = v;
            }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
            Meteor(v) {
                        Meteor = v;
            }

}, 1);
let Patients;
module.watch(require("./patients"), {
            Patients(v) {
                        Patients = v;
            }

}, 2);
let Epss;
module.watch(require("./epss"), {
            Epss(v) {
                        Epss = v;
            }

}, 3);
const Pat = new Mongo.Collection('pat');

// Once our patient is selected we need to populate our collections. The main functions for this are handled here
// With references to the other collections when needed.
if (Meteor.isServer) {
            Meteor.startup(() => {
                        // clear ant Pat data at startup as there should not be any patient in context.
                        Pat.remove({});
            });
            Meteor.methods({
                        'updatePat': function (patId) {
                                    console.log("updatePat was run"); // Ok, First, let's fetch the other data about the patient
                                    // We'll store this single patient's data in a new Collection, pat
                                    // If any old data is in Pat or Epss need to clear it

                                    Pat.remove({});
                                    Epss.remove({}); // Now, let's start fresh with our currently selected patient

                                    Pat.insert({
                                                _id: patId
                                    }); // these helper functions will make inserting and reading data easier
                                    // This one adds a new object to the database collection under this patId

                                    function updatePat(object) {
                                                //console.log(object)
                                                Pat.update({
                                                            _id: patId
                                                }, {
                                                            $set: object
                                                });
                                    } //e.g. - first let's use our "Patients" list and get the full name and also the age


                                    updatePat({
                                                name: Patients.findOne({
                                                            patId: patId
                                                }).fname + ' ' + Patients.findOne({
                                                            patId: patId
                                                }).lname,
                                                age: getAge(Patients.findOne({
                                                            patId: patId
                                                }).dob)
                                    }); // Let's throw everything else that is in the "Patients" collection about our patient in a gen (for "general") object

                                    updatePat({
                                                gen: Patients.findOne({
                                                            patId: patId
                                                })
                                    }); // Simulate a call to a table that holds patient Observations
                                    // The meteor.call actually just reads from the CSV, but it does then filter by the patId
                                    // sort of like how a real SQL call would work.
                                    // We will store this in our Pat collection under the group 'obs'

                                    Meteor.call('getObs', patId); // Now simulate a call for patient Metrics
                                    // this will go in a separate collection for searching, so just is a meteor.call

                                    Meteor.call('getMetrics', patId);
                        },
                        'clearPat': function () {
                                    Pat.remove({});
                        }
            });
            Meteor.publish('pat', function () {
                        return Pat.find();
            });
}

if (Meteor.isClient) {
            Meteor.subscribe('pat');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patients.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/patients.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Patients: () => Patients
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Patients = new Mongo.Collection('patients');

// Populate our local patient database with some pre-built patient data.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // code to run on server at startup
        // Only do this on startup if the db is empty
        if (Patients.find().count() === 0) {
            console.log("found no patients- getting data...");
            Meteor.call('resetPatients');
        } else {
            console.log('found patients already in database');
        }
    });
    Meteor.methods({
        'clearPatients': function () {
            Patients.remove({});
        },
        'resetPatients': function () {
            console.log('resetting patient DB');
            Patients.remove({}); // The patient data is stored as a CSV file in our "private" folder
            // This allows us to quick and dirty replicate what might be a view on Acuere
            // It would probably be easier if this would just pull from Acuere...
            //First, import the csv as a string: https://stackoverflow.com/questions/17453848/is-there-a-way-to-import-strings-from-a-text-file-in-javascript-meteor

            try {
                const patientString = Assets.getText('patients.csv'); // patientString will contain the data as one long CSV string
                // We need to parse it to a JSON object.
                // will use the Papa parse package to do this...

                const patientData = Papa.parse(patientString, {
                    header: true
                }); // We will store the data in our own Mongo collection that we defined above- Patients
                // Prefer to store each patient as their own "document" to make searches and stuff easier, so loop through the CSV data and insert one at a time

                let count = 0;

                for (let x in patientData.data) {
                    if (patientData.data[x].patId !== '') {
                        // ignores any blank rows (i.e. last row that always comes back)
                        Patients.insert(patientData.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' patients entered');
            } catch (e) {
                console.log("something went wrong with getting the patient list");
                console.log(e.message);
            }
        }
    });
    Meteor.publish('patients', function () {
        return Patients.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('patients');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/global.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// global functions go here
// this just calculates the age in years based on birthdate
getAge = function (dobString) {
    let dob = new Date(dobString);
    let ageDifMs = Date.now() - dob.getTime();
    let ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
module.watch(require("../imports/global"));
Meteor.startup(() => {// code to run on server at startup
});
Meteor.methods({
    'resetAll': function () {
        console.log('Full reset called...');
        Meteor.call('resetPatients');
        Meteor.call('clearEpss');
        Meteor.call('clearPat');
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/epss.js");
require("./collections/metrics.js");
require("./collections/observations.js");
require("./collections/pat.js");
require("./collections/patients.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvZXBzcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvbWV0cmljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvb2JzZXJ2YXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9wYXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3BhdGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2dsb2JhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRXBzcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkhUVFAiLCJQYXQiLCJPYnNlcnZhdGlvbnMiLCJDb2xsZWN0aW9uIiwiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJtZXRob2RzIiwiZmluZCIsImNvdW50IiwidXJsIiwiZVBTU19LZXkiLCJKU09OIiwicGFyc2UiLCJBc3NldHMiLCJnZXRUZXh0Iiwia2V5IiwiY29uc29sZSIsImxvZyIsImUiLCJtZXNzYWdlIiwic2V4IiwiZmluZE9uZSIsImdlbiIsImFnZSIsImdldEFnZSIsImRvYiIsInRvYmFjY28iLCJjYXRlZ29yeSIsIm5hbWUiLCJ2YWx1ZSIsInNleHVhbGx5QWN0aXZlIiwicHJlZ25hbnQiLCJwYXJhbXMiLCJncmFkZSIsImNhbGwiLCJoZWFkZXJzIiwiZXJyIiwicmVzdWx0IiwiZXBzc0NvdW50IiwicmVjcyIsImRhdGEiLCJzcGVjaWZpY1JlY29tbWVuZGF0aW9ucyIsIngiLCJpbnNlcnQiLCJyZW1vdmUiLCJwdWJsaXNoIiwiaXNDbGllbnQiLCJzdWJzY3JpYmUiLCJNZXRyaWNzIiwic3RhcnR1cCIsInBhdElkIiwibWV0cmljc1N0cmluZyIsIm1ldHJpY3MiLCJQYXBhIiwiaGVhZGVyIiwiU3RyaW5nIiwiYWxsIiwiZmV0Y2giLCJfaWQiLCJkYXRlIiwiRGF0ZSIsInVwc2VydCIsIiRzZXQiLCJQYXRpZW50cyIsInVwZGF0ZVBhdCIsIm9iamVjdCIsInVwZGF0ZSIsImZuYW1lIiwibG5hbWUiLCJwYXRpZW50U3RyaW5nIiwicGF0aWVudERhdGEiLCJkb2JTdHJpbmciLCJhZ2VEaWZNcyIsIm5vdyIsImdldFRpbWUiLCJhZ2VEYXRlIiwiTWF0aCIsImFicyIsImdldFVUQ0Z1bGxZZWFyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsVUFBSyxNQUFJQTtBQUFWLENBQWQ7QUFBK0IsSUFBSUMsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxJQUFKO0FBQVNQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0UsU0FBS0QsQ0FBTCxFQUFPO0FBQUNDLGVBQUtELENBQUw7QUFBTzs7QUFBaEIsQ0FBcEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsR0FBSjtBQUFRUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNHLFFBQUlGLENBQUosRUFBTTtBQUFDRSxjQUFJRixDQUFKO0FBQU07O0FBQWQsQ0FBOUIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ0ksaUJBQWFILENBQWIsRUFBZTtBQUFDRyx1QkFBYUgsQ0FBYjtBQUFlOztBQUFoQyxDQUF2QyxFQUF5RSxDQUF6RTtBQUMxTyxNQUFNSixPQUFPLElBQUlDLE1BQU1PLFVBQVYsQ0FBcUIsTUFBckIsQ0FBYjs7QUFPUDs7Ozs7Ozs7Ozs7Ozs7R0FnQkEsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsV0FBT0UsT0FBUCxDQUFlO0FBRVgsbUJBQVcsWUFBWTtBQUVuQjtBQUNBLGdCQUFJWCxLQUFLWSxJQUFMLEdBQVlDLEtBQVosS0FBc0IsQ0FBMUIsRUFBOEI7QUFDMUI7QUFDSCxhQUxrQixDQU9uQjs7O0FBQ0Esa0JBQU1DLE1BQU0sMkJBQVo7QUFDQSxnQkFBSUMsV0FBVyxFQUFmLENBVG1CLENBVW5CO0FBQ0E7O0FBRUEsZ0JBQUk7QUFDQUEsMkJBQVdDLEtBQUtDLEtBQUwsQ0FBV0MsT0FBT0MsT0FBUCxDQUFlLGVBQWYsQ0FBWCxDQUFYLENBREEsQ0FFQTs7QUFFQSxvQkFBSUosU0FBU0ssR0FBVCxLQUFpQixjQUFyQixFQUFxQztBQUNqQ0MsNEJBQVFDLEdBQVIsQ0FBWSxxR0FBWjtBQUNBO0FBQ0g7QUFDSixhQVJELENBUUUsT0FBTUMsQ0FBTixFQUFRO0FBQ05GLHdCQUFRQyxHQUFSLENBQVksd0ZBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUMsRUFBRUMsT0FBZDtBQUNILGFBeEJrQixDQTJCbkI7OztBQUVBLGdCQUFJQyxNQUFNbkIsSUFBSW9CLE9BQUosR0FBY0MsR0FBZCxDQUFrQkYsR0FBNUI7QUFDQSxnQkFBSUcsTUFBTUMsT0FBT3ZCLElBQUlvQixPQUFKLEdBQWNDLEdBQWQsQ0FBa0JHLEdBQXpCLENBQVY7QUFDQSxnQkFBSUMsVUFBVSxFQUFkOztBQUNBLGdCQUFJeEIsYUFBYW1CLE9BQWIsQ0FBcUI7QUFBQ00sMEJBQVUsZUFBWDtBQUE0QkMsc0JBQU07QUFBbEMsYUFBckIsQ0FBSixFQUErRTtBQUMzRUYsMEJBQVV4QixhQUFhbUIsT0FBYixDQUFxQjtBQUFDTSw4QkFBVSxlQUFYO0FBQTRCQywwQkFBTTtBQUFsQyxpQkFBckIsRUFBMEVDLEtBQXBGO0FBQ0g7O0FBRUQsZ0JBQUlDLGlCQUFpQixFQUFyQjtBQUNBLGdCQUFJNUIsYUFBYW1CLE9BQWIsQ0FBcUI7QUFBQ00sMEJBQVUsZUFBWDtBQUE0QkMsc0JBQU07QUFBbEMsYUFBckIsQ0FBSixFQUNJRSxpQkFBaUI1QixhQUFhbUIsT0FBYixDQUFxQjtBQUFDTSwwQkFBVSxlQUFYO0FBQTRCQyxzQkFBTTtBQUFsQyxhQUFyQixFQUEyRUMsS0FBNUY7QUFDSixnQkFBSUUsV0FBVyxJQUFmOztBQUNBLGdCQUFHWCxRQUFPLEdBQVYsRUFBYztBQUNWVywyQkFBVyxHQUFYLENBRFUsQ0FDSztBQUNsQixhQTFDa0IsQ0E0Q25COzs7QUFDQSxnQkFBSUMsU0FBUztBQUNUVCxxQkFBS0EsR0FESTtBQUVUSCxxQkFBS0EsR0FGSTtBQUdUVywwQkFBVUEsUUFIRDtBQUdXO0FBQ3BCTCx5QkFBU0EsT0FKQTtBQUtUSSxnQ0FBZ0JBLGNBTFA7QUFNVEcsdUJBQU8sQ0FBQyxHQUFELEVBQU0sR0FBTjtBQU5FLGFBQWIsQ0E3Q21CLENBc0RuQjs7QUFDQUQsbUJBQU9qQixHQUFQLEdBQWFMLFNBQVNLLEdBQXRCLENBdkRtQixDQXlEbkI7O0FBQ0EsZ0JBQUk7QUFDQWYscUJBQUtrQyxJQUFMLENBQVUsS0FBVixFQUFpQnpCLEdBQWpCLEVBQXFCO0FBQ2IwQiw2QkFBUyxjQURJO0FBRWJIO0FBRmEsaUJBQXJCLEVBR08sVUFBU0ksR0FBVCxFQUFjQyxNQUFkLEVBQXFCO0FBQ3hCLHdCQUFHRCxHQUFILEVBQU87QUFDSCw4QkFBTUEsR0FBTjtBQUNILHFCQUZELE1BRU87QUFDSDtBQUNBLDRCQUFJRSxZQUFZLENBQWhCO0FBQ0EsNEJBQUlDLE9BQU9GLE9BQU9HLElBQVAsQ0FBWUMsdUJBQXZCOztBQUNBLDZCQUFLLElBQUlDLENBQVQsSUFBY0gsSUFBZCxFQUFvQjtBQUNoQjVDLGlDQUFLZ0QsTUFBTCxDQUFZSixLQUFLRyxDQUFMLENBQVo7QUFDQUoseUNBQVksQ0FBWjtBQUNIOztBQUNEdEIsZ0NBQVFDLEdBQVIsQ0FBWXFCLFlBQVkscUJBQXhCO0FBQ0EsK0JBQU8sSUFBUDtBQUNIO0FBRUEsaUJBbEJMO0FBcUJILGFBdEJELENBc0JFLE9BQU9wQixDQUFQLEVBQVU7QUFDUkYsd0JBQVFDLEdBQVIsQ0FBWUMsQ0FBWjtBQUNIO0FBQ0osU0FyRlU7QUF1RlgscUJBQWEsWUFBVztBQUNwQnZCLGlCQUFLaUQsTUFBTCxDQUFZLEVBQVo7QUFDSDtBQXpGVSxLQUFmLEVBRmlCLENBK0ZiOztBQUNBeEMsV0FBT3lDLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFlBQVU7QUFDN0I7QUFDQSxlQUFPbEQsS0FBS1ksSUFBTCxFQUFQO0FBQ0gsS0FIRDtBQUlQLEMsQ0FDTzs7O0FBQ1IsSUFBSUgsT0FBTzBDLFFBQVgsRUFBb0I7QUFDaEIxQyxXQUFPMkMsU0FBUCxDQUFpQixNQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDaElEdEQsT0FBT0MsTUFBUCxDQUFjO0FBQUNzRCxhQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJcEQsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJSyxNQUFKO0FBQVdYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sV0FBT0wsQ0FBUCxFQUFTO0FBQUNLLGlCQUFPTCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRy9HLE1BQU1pRCxVQUFVLElBQUlwRCxNQUFNTyxVQUFWLENBQXFCLFNBQXJCLENBQWhCOztBQUVQO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsV0FBTzZDLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBQ0FELGdCQUFRSixNQUFSLENBQWUsRUFBZjtBQUVILEtBSkQ7QUFPQXhDLFdBQU95QyxPQUFQLENBQWUsU0FBZixFQUEwQixZQUFVO0FBQ2hDLGVBQU9HLFFBQVF6QyxJQUFSLEVBQVA7QUFDSCxLQUZEO0FBSUFILFdBQU9FLE9BQVAsQ0FBZTtBQUNYLHNCQUFjLFVBQVM0QyxLQUFULEVBQWU7QUFDekJGLG9CQUFRSixNQUFSLENBQWUsRUFBZjs7QUFDQSxnQkFBSTtBQUNBLHNCQUFNTyxnQkFBZ0J0QyxPQUFPQyxPQUFQLENBQWUsYUFBZixDQUF0QjtBQUVBLHNCQUFNc0MsVUFBVUMsS0FBS3pDLEtBQUwsQ0FBV3VDLGFBQVgsRUFBMEI7QUFBQ0csNEJBQVE7QUFBVCxpQkFBMUIsQ0FBaEI7QUFDQSxvQkFBSTlDLFFBQVEsQ0FBWjs7QUFDQSxxQkFBSyxJQUFJa0MsQ0FBVCxJQUFjVSxRQUFRWixJQUF0QixFQUE0QjtBQUN4Qix3QkFBSVksUUFBUVosSUFBUixDQUFhRSxDQUFiLEVBQWdCUSxLQUFoQixLQUEwQkEsS0FBOUIsRUFBcUM7QUFDakNGLGdDQUFRTCxNQUFSLENBQWVTLFFBQVFaLElBQVIsQ0FBYUUsQ0FBYixDQUFmO0FBQ0FsQyxpQ0FBUyxDQUFUO0FBQ0g7QUFDSjs7QUFDRFEsd0JBQVFDLEdBQVIsQ0FBWVQsUUFBUSxrQkFBcEI7QUFDSCxhQVpELENBWUUsT0FBT1UsQ0FBUCxFQUFVO0FBQ1JGLHdCQUFRQyxHQUFSLENBQVksb0RBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUMsRUFBRUMsT0FBZDtBQUNBLHVCQUFPLEtBQVA7QUFDSDs7QUFDRCxtQkFBTyxJQUFQO0FBQ0g7QUFyQlUsS0FBZjtBQXVCSDs7QUFFRCxJQUFJZixPQUFPMEMsUUFBWCxFQUFvQjtBQUNoQjFDLFdBQU8yQyxTQUFQLENBQWlCLFNBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNoRER0RCxPQUFPQyxNQUFQLENBQWM7QUFBQ1Esa0JBQWEsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJTixLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHekgsTUFBTUcsZUFBZSxJQUFJTixNQUFNTyxVQUFWLENBQXFCLEtBQXJCLENBQXJCOztBQUVQO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsV0FBTzZDLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBQ0EvQyxxQkFBYTBDLE1BQWIsQ0FBb0IsRUFBcEI7QUFFSCxLQUpEO0FBT0F4QyxXQUFPeUMsT0FBUCxDQUFlLEtBQWYsRUFBc0IsWUFBVTtBQUM1QixlQUFPM0MsYUFBYUssSUFBYixFQUFQO0FBQ0gsS0FGRDtBQUlBSCxXQUFPRSxPQUFQLENBQWU7QUFDWCxrQkFBVSxVQUFTNEMsS0FBVCxFQUFlO0FBQ3JCaEQseUJBQWEwQyxNQUFiLENBQW9CLEVBQXBCOztBQUVBLGdCQUFJO0FBQ0Esc0JBQU1XLFNBQVMxQyxPQUFPQyxPQUFQLENBQWUsa0JBQWYsQ0FBZjtBQUVBLHNCQUFNRixRQUFReUMsS0FBS3pDLEtBQUwsQ0FBVzJDLE1BQVgsRUFBbUI7QUFBQ0QsNEJBQVE7QUFBVCxpQkFBbkIsQ0FBZDtBQUNBLG9CQUFJOUMsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUlrQyxDQUFULElBQWM5QixNQUFNNEIsSUFBcEIsRUFBMEI7QUFDdEIsd0JBQUk1QixNQUFNNEIsSUFBTixDQUFXRSxDQUFYLEVBQWNRLEtBQWQsS0FBd0JBLEtBQTVCLEVBQW1DO0FBQy9CaEQscUNBQWF5QyxNQUFiLENBQW9CL0IsTUFBTTRCLElBQU4sQ0FBV0UsQ0FBWCxDQUFwQjtBQUNBbEMsaUNBQVMsQ0FBVDtBQUNIO0FBQ0osaUJBVkQsQ0FXQTtBQUNBOzs7QUFDQSxvQkFBSWdELE1BQU10RCxhQUFhSyxJQUFiLEdBQW9Ca0QsS0FBcEIsRUFBVjs7QUFDQSxxQkFBSyxJQUFJZixDQUFULElBQWNjLEdBQWQsRUFBa0I7QUFDZCx3QkFBSUUsTUFBTUYsSUFBSWQsQ0FBSixFQUFPZ0IsR0FBakI7QUFDQSx3QkFBSUMsT0FBTyxJQUFJQyxJQUFKLENBQVNKLElBQUlkLENBQUosRUFBT2lCLElBQWhCLENBQVgsQ0FGYyxDQUdkOztBQUNBekQsaUNBQWEyRCxNQUFiLENBQW9CO0FBQUNILDZCQUFLQTtBQUFOLHFCQUFwQixFQUErQjtBQUFDSSw4QkFBTTtBQUFDSCxrQ0FBTUE7QUFBUDtBQUFQLHFCQUEvQjtBQUNIOztBQUVEM0Msd0JBQVFDLEdBQVIsQ0FBWVQsUUFBUSx1QkFBcEI7QUFDSCxhQXRCRCxDQXNCRSxPQUFPVSxDQUFQLEVBQVU7QUFDUkYsd0JBQVFDLEdBQVIsQ0FBWSx5REFBWjtBQUNBRCx3QkFBUUMsR0FBUixDQUFZQyxFQUFFQyxPQUFkO0FBQ0EsdUJBQU8sS0FBUDtBQUNIOztBQUNELG1CQUFPLElBQVA7QUFDSDtBQWhDVSxLQUFmO0FBa0NIOztBQUVELElBQUlmLE9BQU8wQyxRQUFYLEVBQW9CO0FBQ2hCMUMsV0FBTzJDLFNBQVAsQ0FBaUIsS0FBakI7QUFDSCxDOzs7Ozs7Ozs7OztBQzNERHRELE9BQU9DLE1BQVAsQ0FBYztBQUFDTyxpQkFBSSxNQUFJQTtBQUFULENBQWQ7QUFBNkIsSUFBSUwsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLGtCQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0NBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUssTUFBSjtBQUFXWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNNLG1CQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUNBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWdFLFFBQUo7QUFBYXRFLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ2lFLHFCQUFTaEUsQ0FBVCxFQUFXO0FBQUNnRSxtQ0FBU2hFLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSUosSUFBSjtBQUFTRixPQUFPSSxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNILGlCQUFLSSxDQUFMLEVBQU87QUFBQ0osK0JBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBL0IsRUFBaUQsQ0FBakQ7QUFLNVAsTUFBTUUsTUFBTSxJQUFJTCxNQUFNTyxVQUFWLENBQXFCLEtBQXJCLENBQVo7O0FBRVA7QUFDQTtBQUdBLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELG1CQUFPNkMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQWhELDRCQUFJMkMsTUFBSixDQUFXLEVBQVg7QUFFSCxhQUpEO0FBTUF4QyxtQkFBT0UsT0FBUCxDQUFlO0FBQ1gscUNBQWEsVUFBUzRDLEtBQVQsRUFBZ0I7QUFDekJsQyw0Q0FBUUMsR0FBUixDQUFZLG1CQUFaLEVBRHlCLENBSXpCO0FBQ0E7QUFFQTs7QUFDQWhCLHdDQUFJMkMsTUFBSixDQUFXLEVBQVg7QUFDQWpELHlDQUFLaUQsTUFBTCxDQUFZLEVBQVosRUFUeUIsQ0FXekI7O0FBQ0EzQyx3Q0FBSTBDLE1BQUosQ0FBVztBQUFDZSxxREFBS1I7QUFBTixxQ0FBWCxFQVp5QixDQWV6QjtBQUVBOztBQUNBLDZDQUFTYyxTQUFULENBQW1CQyxNQUFuQixFQUEyQjtBQUN2QjtBQUNBaEUsb0RBQUlpRSxNQUFKLENBQVc7QUFBQ1IsaUVBQUtSO0FBQU4saURBQVgsRUFBeUI7QUFBQ1ksa0VBQU9HO0FBQVIsaURBQXpCO0FBQ0gscUNBckJ3QixDQXVCekI7OztBQUNBRCw4Q0FBVTtBQUNOcEMsc0RBQU1tQyxTQUFTMUMsT0FBVCxDQUFpQjtBQUFDNkIsbUVBQU9BO0FBQVIsaURBQWpCLEVBQWlDaUIsS0FBakMsR0FBeUMsR0FBekMsR0FBK0NKLFNBQVMxQyxPQUFULENBQWlCO0FBQUM2QixtRUFBT0E7QUFBUixpREFBakIsRUFBaUNrQixLQURoRjtBQUVON0MscURBQUtDLE9BQU91QyxTQUFTMUMsT0FBVCxDQUFpQjtBQUFDNkIsbUVBQU9BO0FBQVIsaURBQWpCLEVBQWlDekIsR0FBeEM7QUFGQyxxQ0FBVixFQXhCeUIsQ0E2QnpCOztBQUNBdUMsOENBQVU7QUFDTjFDLHFEQUFLeUMsU0FBUzFDLE9BQVQsQ0FBaUI7QUFBQzZCLG1FQUFPQTtBQUFSLGlEQUFqQjtBQURDLHFDQUFWLEVBOUJ5QixDQWtDckM7QUFDWTtBQUNBO0FBQ0E7O0FBRUE5QywyQ0FBTzhCLElBQVAsQ0FBWSxRQUFaLEVBQXNCZ0IsS0FBdEIsRUF2Q3lCLENBeUNyQztBQUNZOztBQUVBOUMsMkNBQU84QixJQUFQLENBQVksWUFBWixFQUEwQmdCLEtBQTFCO0FBRUgseUJBL0NVO0FBaURYLG9DQUFZLFlBQVc7QUFDbkJqRCx3Q0FBSTJDLE1BQUosQ0FBVyxFQUFYO0FBQ0g7QUFuRFUsYUFBZjtBQXVESXhDLG1CQUFPeUMsT0FBUCxDQUFlLEtBQWYsRUFBc0IsWUFBVTtBQUM1QiwrQkFBTzVDLElBQUlNLElBQUosRUFBUDtBQUNILGFBRkQ7QUFHUDs7QUFFRCxJQUFJSCxPQUFPMEMsUUFBWCxFQUFvQjtBQUNoQjFDLG1CQUFPMkMsU0FBUCxDQUFpQixLQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDakZEdEQsT0FBT0MsTUFBUCxDQUFjO0FBQUNxRSxjQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJbkUsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJSyxNQUFKO0FBQVdYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sV0FBT0wsQ0FBUCxFQUFTO0FBQUNLLGlCQUFPTCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRWpILE1BQU1nRSxXQUFXLElBQUluRSxNQUFNTyxVQUFWLENBQXFCLFVBQXJCLENBQWpCOztBQUdQO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVyQkQsV0FBTzZDLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBRUE7QUFDQSxZQUFJYyxTQUFTeEQsSUFBVCxHQUFnQkMsS0FBaEIsT0FBNEIsQ0FBaEMsRUFBa0M7QUFDOUJRLG9CQUFRQyxHQUFSLENBQVksb0NBQVo7QUFDQWIsbUJBQU84QixJQUFQLENBQVksZUFBWjtBQUVILFNBSkQsTUFJTTtBQUNGbEIsb0JBQVFDLEdBQVIsQ0FBWSxvQ0FBWjtBQUNIO0FBRUosS0FaRDtBQWNJYixXQUFPRSxPQUFQLENBQWU7QUFDWCx5QkFBaUIsWUFBVztBQUN4QnlELHFCQUFTbkIsTUFBVCxDQUFnQixFQUFoQjtBQUNILFNBSFU7QUFLWCx5QkFBaUIsWUFBVztBQUN4QjVCLG9CQUFRQyxHQUFSLENBQVksc0JBQVo7QUFDQThDLHFCQUFTbkIsTUFBVCxDQUFnQixFQUFoQixFQUZ3QixDQUl4QjtBQUNBO0FBQ0E7QUFFQTs7QUFFQSxnQkFBSTtBQUNBLHNCQUFNeUIsZ0JBQWdCeEQsT0FBT0MsT0FBUCxDQUFlLGNBQWYsQ0FBdEIsQ0FEQSxDQUVBO0FBQ0E7QUFDQTs7QUFFQSxzQkFBTXdELGNBQWNqQixLQUFLekMsS0FBTCxDQUFXeUQsYUFBWCxFQUEwQjtBQUFDZiw0QkFBUTtBQUFULGlCQUExQixDQUFwQixDQU5BLENBUUE7QUFDQTs7QUFDQSxvQkFBSTlDLFFBQVEsQ0FBWjs7QUFDQSxxQkFBSyxJQUFJa0MsQ0FBVCxJQUFjNEIsWUFBWTlCLElBQTFCLEVBQWdDO0FBQzVCLHdCQUFHOEIsWUFBWTlCLElBQVosQ0FBaUJFLENBQWpCLEVBQW9CUSxLQUFwQixLQUE2QixFQUFoQyxFQUFtQztBQUFFO0FBQ2pDYSxpQ0FBU3BCLE1BQVQsQ0FBZ0IyQixZQUFZOUIsSUFBWixDQUFpQkUsQ0FBakIsQ0FBaEI7QUFDQWxDLGlDQUFTLENBQVQ7QUFDSDtBQUNKOztBQUNEUSx3QkFBUUMsR0FBUixDQUFZVCxRQUFRLG1CQUFwQjtBQUVILGFBbkJELENBbUJFLE9BQU9VLENBQVAsRUFBVTtBQUNSRix3QkFBUUMsR0FBUixDQUFZLG9EQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDSDtBQUNKO0FBdENVLEtBQWY7QUEwQ0lmLFdBQU95QyxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFVO0FBQ2pDLGVBQU9rQixTQUFTeEQsSUFBVCxFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUlILE9BQU8wQyxRQUFYLEVBQW9CO0FBQ2hCMUMsV0FBTzJDLFNBQVAsQ0FBaUIsVUFBakI7QUFDSCxDOzs7Ozs7Ozs7OztBQ3pFRDtBQUVBO0FBQ0F2QixTQUFTLFVBQVMrQyxTQUFULEVBQW1CO0FBQ3hCLFFBQUk5QyxNQUFNLElBQUltQyxJQUFKLENBQVVXLFNBQVYsQ0FBVjtBQUNBLFFBQUlDLFdBQVdaLEtBQUthLEdBQUwsS0FBYWhELElBQUlpRCxPQUFKLEVBQTVCO0FBQ0EsUUFBSUMsVUFBVSxJQUFJZixJQUFKLENBQVNZLFFBQVQsQ0FBZDtBQUNBLFdBQU9JLEtBQUtDLEdBQUwsQ0FBU0YsUUFBUUcsY0FBUixLQUEwQixJQUFuQyxDQUFQO0FBQ0gsQ0FMRCxDOzs7Ozs7Ozs7OztBQ0hBLElBQUkxRSxNQUFKO0FBQVdYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sV0FBT0wsQ0FBUCxFQUFTO0FBQUNLLGlCQUFPTCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStETixPQUFPSSxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUcxRU0sT0FBTzZDLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRDtBQUlBN0MsT0FBT0UsT0FBUCxDQUFlO0FBQ1gsZ0JBQVksWUFBVTtBQUNsQlUsZ0JBQVFDLEdBQVIsQ0FBWSxzQkFBWjtBQUNBYixlQUFPOEIsSUFBUCxDQUFZLGVBQVo7QUFDQTlCLGVBQU84QixJQUFQLENBQVksV0FBWjtBQUNBOUIsZUFBTzhCLElBQVAsQ0FBWSxVQUFaO0FBQ0g7QUFOVSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuZXhwb3J0IGNvbnN0IEVwc3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXBzcycpO1xyXG5pbXBvcnQge0hUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcclxuaW1wb3J0IHtQYXR9IGZyb20gXCIuL3BhdFwiO1xyXG5pbXBvcnQge09ic2VydmF0aW9uc30gZnJvbSBcIi4vb2JzZXJ2YXRpb25zXCI7XHJcblxyXG5cclxuXHJcbi8qXHJcblRoaXMgaXMgd2hlcmUgd2Ugd2lsbCBmZXRjaCBhbmQgc3RvcmUgdGhlIEFIUlEgRVBTUyByZWNvbW1lbmRhdGlvbnNcclxudXNlIG9mIHRoaXMgcmVxdWlyZXMgYW4gZVBTUyBrZXksIGFuZCB0aGVyZSBpcyBzb21lIGxvZ2ljIHRvIGZldGNoIGFuZCB2YWxpZGF0ZSB0aGUga2V5IGhlcmVcclxuVGhlIGtleSBzaG91bGQgYmUgcGxhY2VkIGluIHRoZSBQcml2YXRlIGZvbGRlciwgaW4gYSBmaWxlIGNhbGxlZCAnZVBTU19LZXkuanNvbidcclxuVEhlIGZpbGUgc2hvdWxkIGJlIGEgc2ltcGxlIGpzb24gb2JqZWN0OlxyXG5cclxue1xyXG4gIFwiS2V5XCI6XCJQVVRfS0VZX0hFUkVcIlxyXG59XHJcblxyXG5QbGVhc2UgcmV2aWV3IHRoZSBBSFJRIENvcHlyaWdodCBhbmQgRGlzY2xhaW1lciBub3RpY2UgYmVmb3JlIHVzaW5nIHRoZSBBUEk6IGh0dHBzOi8vd3d3LnVzcHJldmVudGl2ZXNlcnZpY2VzdGFza2ZvcmNlLm9yZy9QYWdlL05hbWUvY29weXJpZ2h0LW5vdGljZS5cclxuSW5zdHJ1Y3Rpb25zIGZvciB1c2UgYW5kIGFjY2VzcyBpbmZvcm1hdGlvbiBjYW4gYmUgZm91bmQgYXQ6XHJcbuKAolx0SW5zdHJ1Y3Rpb24gZm9yIFVzZTogIGh0dHA6Ly9lcHNzLmFocnEuZ292L1BEQS9kb2NzL2VQU1NfRGF0YV9BUElfV0lfd0xpbmsucGRmXHJcbuKAolx0VVJMOiAgaHR0cDovL2Vwc3NkYXRhLmFocnEuZ292L1xyXG4gKi9cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gICAgICAgICdnZXRFcHNzJzogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgICAgICAgICAgLy8gb25seSB1cGRhdGUgaWYgZW1wdHktIHVwZGF0ZVBhdCBzaG91bGQgZW1wdHkgdGhpcyBjb2xsZWN0aW9uLi4uXHJcbiAgICAgICAgICAgIGlmIChFcHNzLmZpbmQoKS5jb3VudCgpID4gMCApIHtcclxuICAgICAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBGaXJzdCwgd2UgbmVlZCB0byBrbm93IHRoZSBlcHNzIGFwaSB1cmxcclxuICAgICAgICAgICAgY29uc3QgdXJsID0gJ2h0dHA6Ly9lcHNzZGF0YS5haHJxLmdvdi8nO1xyXG4gICAgICAgICAgICBsZXQgZVBTU19LZXkgPSAnJztcclxuICAgICAgICAgICAgLy8gTmV4dCwgZ2V0IHRoZSBlUFNTIGtleSBmcm9tIHRoZSB0ZXh0IGZpbGUgaW4gdGhlIFByaXZhdGUgZm9sZGVyLlxyXG4gICAgICAgICAgICAvLyB0aGlzIGZpbGUgd2lsbCBub3Qgc3luYyB3aXRoIGdpdCBpZiBpdCBpcyBpbiB0aGUgLmdpdGlnbm9yZVxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGVQU1NfS2V5ID0gSlNPTi5wYXJzZShBc3NldHMuZ2V0VGV4dCgnZVBTU19LZXkuanNvbicpKTtcclxuICAgICAgICAgICAgICAgIC8vIElmIHRoZSBrZXkgaXMgYmxhbmsgb3Igbm90IHVwZGF0ZWQsIHdlIGNhbm5vdCBjb250aW51ZS4uXHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGVQU1NfS2V5LmtleSA9PT0gJ1BVVF9LRVlfSEVSRScpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZVBTUyBLZXkgbm90IGZvdW5kIG9yIGludmFsaWQtIHBsZWFzZSBpbnB1dCB5b3VyIGVQU1Mga2V5IGludG8gZVBTU19LZXkuanNvbiBmaWxlIGluIHByaXZhdGUgZm9sZGVyJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoKGUpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZldGNoaW5nIGVQU1Mga2V5IGZhaWxlZC4gUGxlYXNlIG1ha2Ugc3VyZSBlUFNTX0tleS5qc29uIGV4aXN0cyBpbiB0aGUgcHJpdmF0ZSBmb2xkZXIuJyk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICAvLyBnZXQgaW5mbyBmcm9tIFBhdCwgT2JzZXJ2YXRpb25zIGNvbGxlY3Rpb25zXHJcblxyXG4gICAgICAgICAgICBsZXQgc2V4ID0gUGF0LmZpbmRPbmUoKS5nZW4uc2V4O1xyXG4gICAgICAgICAgICBsZXQgYWdlID0gZ2V0QWdlKFBhdC5maW5kT25lKCkuZ2VuLmRvYik7XHJcbiAgICAgICAgICAgIGxldCB0b2JhY2NvID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChPYnNlcnZhdGlvbnMuZmluZE9uZSh7Y2F0ZWdvcnk6ICdzb2NpYWxIaXN0b3J5JywgbmFtZTogJ1Ntb2tpbmcgU3RhdHVzJ30pKSB7XHJcbiAgICAgICAgICAgICAgICB0b2JhY2NvID0gT2JzZXJ2YXRpb25zLmZpbmRPbmUoe2NhdGVnb3J5OiAnc29jaWFsSGlzdG9yeScsIG5hbWU6ICdTbW9raW5nIFN0YXR1cyd9KS52YWx1ZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IHNleHVhbGx5QWN0aXZlID0gJyc7XHJcbiAgICAgICAgICAgIGlmIChPYnNlcnZhdGlvbnMuZmluZE9uZSh7Y2F0ZWdvcnk6ICdzb2NpYWxIaXN0b3J5JywgbmFtZTogJ1NleHVhbGx5IEFjdGl2ZSd9KSlcclxuICAgICAgICAgICAgICAgIHNleHVhbGx5QWN0aXZlID0gT2JzZXJ2YXRpb25zLmZpbmRPbmUoe2NhdGVnb3J5OiAnc29jaWFsSGlzdG9yeScsIG5hbWU6ICdTZXh1YWxseSBBY3RpdmUnfSkudmFsdWU7XHJcbiAgICAgICAgICAgIGxldCBwcmVnbmFudCA9IG51bGw7XHJcbiAgICAgICAgICAgIGlmKHNleCA9PT0nRicpe1xyXG4gICAgICAgICAgICAgICAgcHJlZ25hbnQgPSAnTicgLy8gcGxhY2Vob2xkZXIgZm9yIHJlYWwgbG9naWNcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy9idWlsZCB0aGUgcGFyYW1zIG9iamVjdFxyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgYWdlOiBhZ2UsXHJcbiAgICAgICAgICAgICAgICBzZXg6IHNleCxcclxuICAgICAgICAgICAgICAgIHByZWduYW50OiBwcmVnbmFudCwgLy8gJ04nIC0tIChZLE4pIC0gcmVxdWlyZXMgRmVtYWxlIHNleCB0byBiZSBwcmVzZW50XHJcbiAgICAgICAgICAgICAgICB0b2JhY2NvOiB0b2JhY2NvLFxyXG4gICAgICAgICAgICAgICAgc2V4dWFsbHlBY3RpdmU6IHNleHVhbGx5QWN0aXZlLFxyXG4gICAgICAgICAgICAgICAgZ3JhZGU6IFsnQScsICdCJ11cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8vIGxhc3RseSwgaW5zZXJ0IGtleSBpbnRvIHBhcmFtc1xyXG4gICAgICAgICAgICBwYXJhbXMua2V5ID0gZVBTU19LZXkua2V5O1xyXG5cclxuICAgICAgICAgICAgLy8gVHJ5IHRvIGZldGNoIHRoZSBlUFNTIHJlY29tbWVuZGF0aW9ucyBiYXNlZCBvbiB0aGUgcGFyYW1zLlxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgSFRUUC5jYWxsKCdnZXQnLCB1cmwse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiAnYWNjZXB0OiBqc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zXHJcbiAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24oZXJyLCByZXN1bHQpe1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVycil7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVyclxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vb25seSB3YW50IHRvIHN0b3JlIHRoZSBzcGVjaWZpYyByZWNvbW1lbmRhdGlvbnMgYXJyYXkgb2JqZWN0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZXBzc0NvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlY3MgPSByZXN1bHQuZGF0YS5zcGVjaWZpY1JlY29tbWVuZGF0aW9ucztcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiByZWNzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFcHNzLmluc2VydChyZWNzW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVwc3NDb3VudCArPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXBzc0NvdW50ICsgJyBlUFNTIHJlY3MgaW5zZXJ0ZWQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgJ2NsZWFyRXBzcyc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBFcHNzLnJlbW92ZSh7fSlcclxuICAgICAgICB9XHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIC8vIFB1YmxpY2F0aW9uIGZ1bmN0aW9uIGZyb20gdGhlIHNlcnZlci0gdGhpcyBsZXQncyB1cyBkZWZpbmUgd2hhdCB0aGUgY2xpZW50LXNpZGUgZGIgZ2V0c1xyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdlcHNzJywgZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgLy8gd2Ugd2lsbCByZXR1cm4gdGhlIGVudGlyZSBjb2xsZWN0aW9uLlxyXG4gICAgICAgICAgICByZXR1cm4gRXBzcy5maW5kKClcclxuICAgICAgICB9KVxyXG59XHJcbiAgICAgICAgLy8gYXMgdGhlIGNsaWVudCwgc3Vic2NyaWJlcyB0byB0aGUgYWJvdmUgcHVibGljYXRpb25cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdlcHNzJylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTWV0cmljcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtZXRyaWNzJyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIHBhdCBjb2xsZWN0aW9uLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW50IFBhdCBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIE1ldHJpY3MucmVtb3ZlKHt9KVxyXG5cclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBNZXRlb3IucHVibGlzaCgnbWV0cmljcycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIE1ldHJpY3MuZmluZCgpXHJcbiAgICB9KTtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcbiAgICAgICAgJ2dldE1ldHJpY3MnOiBmdW5jdGlvbihwYXRJZCl7XHJcbiAgICAgICAgICAgIE1ldHJpY3MucmVtb3ZlKHt9KTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG1ldHJpY3NTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgnbWV0cmljcy5jc3YnKTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBtZXRyaWNzID0gUGFwYS5wYXJzZShtZXRyaWNzU3RyaW5nLCB7aGVhZGVyOiB0cnVlfSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBtZXRyaWNzLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobWV0cmljcy5kYXRhW3hdLnBhdElkID09PSBwYXRJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRyaWNzLmluc2VydChtZXRyaWNzLmRhdGFbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCArPSAxXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY291bnQgKyAnIG1ldHJpY3MgZW50ZXJlZCcpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBwYXJzaW5nIHRoZSBtZXRyaWNzIGRhdGFcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ21ldHJpY3MnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBPYnNlcnZhdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignb2JzJyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIHBhdCBjb2xsZWN0aW9uLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW55IGRhdGEgYXQgc3RhcnR1cCBhcyB0aGVyZSBzaG91bGQgbm90IGJlIGFueSBwYXRpZW50IGluIGNvbnRleHQuXHJcbiAgICAgICAgT2JzZXJ2YXRpb25zLnJlbW92ZSh7fSlcclxuXHJcbiAgICB9KTtcclxuXHJcblxyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ29icycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIE9ic2VydmF0aW9ucy5maW5kKClcclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnZ2V0T2JzJzogZnVuY3Rpb24ocGF0SWQpe1xyXG4gICAgICAgICAgICBPYnNlcnZhdGlvbnMucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgnb2JzZXJ2YXRpb25zLmNzdicpO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlID0gUGFwYS5wYXJzZShTdHJpbmcsIHtoZWFkZXI6IHRydWV9KTtcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHBhcnNlLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2UuZGF0YVt4XS5wYXRJZCA9PT0gcGF0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgT2JzZXJ2YXRpb25zLmluc2VydChwYXJzZS5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIE9ic2VydmF0aW9ucyBhcmUgaW4gdGhlcmUsIGJ1dCB0aGUgZGF0ZSBmaWVsZCBpcyBqdXN0IGEgc3RyaW5nLlxyXG4gICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHRyYW5zZm9ybSB0aGUgc3RyaW5nIGluIHRoZSBcImRhdGVcIiBmaWVsZCBpbnRvIGEgamF2YXNjcmlwdCBkYXRlLlxyXG4gICAgICAgICAgICAgICAgbGV0IGFsbCA9IE9ic2VydmF0aW9ucy5maW5kKCkuZmV0Y2goKVxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBhbGwpe1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfaWQgPSBhbGxbeF0uX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGUgPSBuZXcgRGF0ZShhbGxbeF0uZGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgT2JzZXJ2YXRpb25zLnVwc2VydCh7X2lkOiBfaWR9LHskc2V0OiB7ZGF0ZTogZGF0ZX19KVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBvYnNlcnZhdGlvbnMgZW50ZXJlZCcpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBwYXJzaW5nIHRoZSBvYnNlcnZhdGlvbnMgZGF0YVwiKVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ29icycpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5pbXBvcnQge1BhdGllbnRzfSBmcm9tIFwiLi9wYXRpZW50c1wiO1xyXG5pbXBvcnQge0Vwc3N9IGZyb20gXCIuL2Vwc3NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBQYXQgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGF0Jyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIGNvbGxlY3Rpb25zLiBUaGUgbWFpbiBmdW5jdGlvbnMgZm9yIHRoaXMgYXJlIGhhbmRsZWQgaGVyZVxyXG4vLyBXaXRoIHJlZmVyZW5jZXMgdG8gdGhlIG90aGVyIGNvbGxlY3Rpb25zIHdoZW4gbmVlZGVkLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW50IFBhdCBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIFBhdC5yZW1vdmUoe30pXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICd1cGRhdGVQYXQnOiBmdW5jdGlvbihwYXRJZCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVBhdCB3YXMgcnVuXCIpO1xyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIE9rLCBGaXJzdCwgbGV0J3MgZmV0Y2ggdGhlIG90aGVyIGRhdGEgYWJvdXQgdGhlIHBhdGllbnRcclxuICAgICAgICAgICAgLy8gV2UnbGwgc3RvcmUgdGhpcyBzaW5nbGUgcGF0aWVudCdzIGRhdGEgaW4gYSBuZXcgQ29sbGVjdGlvbiwgcGF0XHJcblxyXG4gICAgICAgICAgICAvLyBJZiBhbnkgb2xkIGRhdGEgaXMgaW4gUGF0IG9yIEVwc3MgbmVlZCB0byBjbGVhciBpdFxyXG4gICAgICAgICAgICBQYXQucmVtb3ZlKHt9KTtcclxuICAgICAgICAgICAgRXBzcy5yZW1vdmUoe30pO1xyXG5cclxuICAgICAgICAgICAgLy8gTm93LCBsZXQncyBzdGFydCBmcmVzaCB3aXRoIG91ciBjdXJyZW50bHkgc2VsZWN0ZWQgcGF0aWVudFxyXG4gICAgICAgICAgICBQYXQuaW5zZXJ0KHtfaWQ6IHBhdElkfSk7XHJcblxyXG5cclxuICAgICAgICAgICAgLy8gdGhlc2UgaGVscGVyIGZ1bmN0aW9ucyB3aWxsIG1ha2UgaW5zZXJ0aW5nIGFuZCByZWFkaW5nIGRhdGEgZWFzaWVyXHJcblxyXG4gICAgICAgICAgICAvLyBUaGlzIG9uZSBhZGRzIGEgbmV3IG9iamVjdCB0byB0aGUgZGF0YWJhc2UgY29sbGVjdGlvbiB1bmRlciB0aGlzIHBhdElkXHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIHVwZGF0ZVBhdChvYmplY3QpIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2cob2JqZWN0KVxyXG4gICAgICAgICAgICAgICAgUGF0LnVwZGF0ZSh7X2lkOiBwYXRJZH0sIHskc2V0OiAgb2JqZWN0fSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy9lLmcuIC0gZmlyc3QgbGV0J3MgdXNlIG91ciBcIlBhdGllbnRzXCIgbGlzdCBhbmQgZ2V0IHRoZSBmdWxsIG5hbWUgYW5kIGFsc28gdGhlIGFnZVxyXG4gICAgICAgICAgICB1cGRhdGVQYXQoe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSkuZm5hbWUgKyAnICcgKyBQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KS5sbmFtZSxcclxuICAgICAgICAgICAgICAgIGFnZTogZ2V0QWdlKFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pLmRvYilcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAvLyBMZXQncyB0aHJvdyBldmVyeXRoaW5nIGVsc2UgdGhhdCBpcyBpbiB0aGUgXCJQYXRpZW50c1wiIGNvbGxlY3Rpb24gYWJvdXQgb3VyIHBhdGllbnQgaW4gYSBnZW4gKGZvciBcImdlbmVyYWxcIikgb2JqZWN0XHJcbiAgICAgICAgICAgIHVwZGF0ZVBhdCh7XHJcbiAgICAgICAgICAgICAgICBnZW46IFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuLy8gU2ltdWxhdGUgYSBjYWxsIHRvIGEgdGFibGUgdGhhdCBob2xkcyBwYXRpZW50IE9ic2VydmF0aW9uc1xyXG4gICAgICAgICAgICAvLyBUaGUgbWV0ZW9yLmNhbGwgYWN0dWFsbHkganVzdCByZWFkcyBmcm9tIHRoZSBDU1YsIGJ1dCBpdCBkb2VzIHRoZW4gZmlsdGVyIGJ5IHRoZSBwYXRJZFxyXG4gICAgICAgICAgICAvLyBzb3J0IG9mIGxpa2UgaG93IGEgcmVhbCBTUUwgY2FsbCB3b3VsZCB3b3JrLlxyXG4gICAgICAgICAgICAvLyBXZSB3aWxsIHN0b3JlIHRoaXMgaW4gb3VyIFBhdCBjb2xsZWN0aW9uIHVuZGVyIHRoZSBncm91cCAnb2JzJ1xyXG5cclxuICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ2dldE9icycsIHBhdElkKTtcclxuXHJcbi8vIE5vdyBzaW11bGF0ZSBhIGNhbGwgZm9yIHBhdGllbnQgTWV0cmljc1xyXG4gICAgICAgICAgICAvLyB0aGlzIHdpbGwgZ28gaW4gYSBzZXBhcmF0ZSBjb2xsZWN0aW9uIGZvciBzZWFyY2hpbmcsIHNvIGp1c3QgaXMgYSBtZXRlb3IuY2FsbFxyXG5cclxuICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ2dldE1ldHJpY3MnLCBwYXRJZClcclxuXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgJ2NsZWFyUGF0JzogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgICAgIFBhdC5yZW1vdmUoe30pXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICB9KTtcclxuXHJcbiAgICAgICAgTWV0ZW9yLnB1Ymxpc2goJ3BhdCcsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHJldHVybiBQYXQuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdwYXQnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuZXhwb3J0IGNvbnN0IFBhdGllbnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3BhdGllbnRzJyk7XHJcblxyXG5cclxuLy8gUG9wdWxhdGUgb3VyIGxvY2FsIHBhdGllbnQgZGF0YWJhc2Ugd2l0aCBzb21lIHByZS1idWlsdCBwYXRpZW50IGRhdGEuXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcclxuXHJcbiAgICAvLyBPbmx5IGRvIHRoaXMgb24gc3RhcnR1cCBpZiB0aGUgZGIgaXMgZW1wdHlcclxuICAgIGlmIChQYXRpZW50cy5maW5kKCkuY291bnQoKSA9PT0gMCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmb3VuZCBubyBwYXRpZW50cy0gZ2V0dGluZyBkYXRhLi4uXCIpO1xyXG4gICAgICAgIE1ldGVvci5jYWxsKCdyZXNldFBhdGllbnRzJylcclxuXHJcbiAgICB9IGVsc2V7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2ZvdW5kIHBhdGllbnRzIGFscmVhZHkgaW4gZGF0YWJhc2UnKVxyXG4gICAgfVxyXG5cclxufSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICdjbGVhclBhdGllbnRzJzogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgICAgIFBhdGllbnRzLnJlbW92ZSh7fSlcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAncmVzZXRQYXRpZW50cyc6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncmVzZXR0aW5nIHBhdGllbnQgREInKTtcclxuICAgICAgICAgICAgUGF0aWVudHMucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIFRoZSBwYXRpZW50IGRhdGEgaXMgc3RvcmVkIGFzIGEgQ1NWIGZpbGUgaW4gb3VyIFwicHJpdmF0ZVwiIGZvbGRlclxyXG4gICAgICAgICAgICAvLyBUaGlzIGFsbG93cyB1cyB0byBxdWljayBhbmQgZGlydHkgcmVwbGljYXRlIHdoYXQgbWlnaHQgYmUgYSB2aWV3IG9uIEFjdWVyZVxyXG4gICAgICAgICAgICAvLyBJdCB3b3VsZCBwcm9iYWJseSBiZSBlYXNpZXIgaWYgdGhpcyB3b3VsZCBqdXN0IHB1bGwgZnJvbSBBY3VlcmUuLi5cclxuXHJcbiAgICAgICAgICAgIC8vRmlyc3QsIGltcG9ydCB0aGUgY3N2IGFzIGEgc3RyaW5nOiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xNzQ1Mzg0OC9pcy10aGVyZS1hLXdheS10by1pbXBvcnQtc3RyaW5ncy1mcm9tLWEtdGV4dC1maWxlLWluLWphdmFzY3JpcHQtbWV0ZW9yXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF0aWVudFN0cmluZyA9IEFzc2V0cy5nZXRUZXh0KCdwYXRpZW50cy5jc3YnKTtcclxuICAgICAgICAgICAgICAgIC8vIHBhdGllbnRTdHJpbmcgd2lsbCBjb250YWluIHRoZSBkYXRhIGFzIG9uZSBsb25nIENTViBzdHJpbmdcclxuICAgICAgICAgICAgICAgIC8vIFdlIG5lZWQgdG8gcGFyc2UgaXQgdG8gYSBKU09OIG9iamVjdC5cclxuICAgICAgICAgICAgICAgIC8vIHdpbGwgdXNlIHRoZSBQYXBhIHBhcnNlIHBhY2thZ2UgdG8gZG8gdGhpcy4uLlxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhdGllbnREYXRhID0gUGFwYS5wYXJzZShwYXRpZW50U3RyaW5nLCB7aGVhZGVyOiB0cnVlfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gV2Ugd2lsbCBzdG9yZSB0aGUgZGF0YSBpbiBvdXIgb3duIE1vbmdvIGNvbGxlY3Rpb24gdGhhdCB3ZSBkZWZpbmVkIGFib3ZlLSBQYXRpZW50c1xyXG4gICAgICAgICAgICAgICAgLy8gUHJlZmVyIHRvIHN0b3JlIGVhY2ggcGF0aWVudCBhcyB0aGVpciBvd24gXCJkb2N1bWVudFwiIHRvIG1ha2Ugc2VhcmNoZXMgYW5kIHN0dWZmIGVhc2llciwgc28gbG9vcCB0aHJvdWdoIHRoZSBDU1YgZGF0YSBhbmQgaW5zZXJ0IG9uZSBhdCBhIHRpbWVcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHBhdGllbnREYXRhLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZihwYXRpZW50RGF0YS5kYXRhW3hdLnBhdElkICE9PScnKXsgLy8gaWdub3JlcyBhbnkgYmxhbmsgcm93cyAoaS5lLiBsYXN0IHJvdyB0aGF0IGFsd2F5cyBjb21lcyBiYWNrKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXRpZW50cy5pbnNlcnQocGF0aWVudERhdGEuZGF0YVt4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IDFcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhjb3VudCArICcgcGF0aWVudHMgZW50ZXJlZCcpXHJcblxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNvbWV0aGluZyB3ZW50IHdyb25nIHdpdGggZ2V0dGluZyB0aGUgcGF0aWVudCBsaXN0XCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICAgICBNZXRlb3IucHVibGlzaCgncGF0aWVudHMnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICByZXR1cm4gUGF0aWVudHMuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdwYXRpZW50cycpXHJcbn0iLCIvLyBnbG9iYWwgZnVuY3Rpb25zIGdvIGhlcmVcclxuXHJcbi8vIHRoaXMganVzdCBjYWxjdWxhdGVzIHRoZSBhZ2UgaW4geWVhcnMgYmFzZWQgb24gYmlydGhkYXRlXHJcbmdldEFnZSA9IGZ1bmN0aW9uKGRvYlN0cmluZyl7XHJcbiAgICBsZXQgZG9iID0gbmV3IERhdGUgKGRvYlN0cmluZyk7XHJcbiAgICBsZXQgYWdlRGlmTXMgPSBEYXRlLm5vdygpIC0gZG9iLmdldFRpbWUoKTtcclxuICAgIGxldCBhZ2VEYXRlID0gbmV3IERhdGUoYWdlRGlmTXMpO1xyXG4gICAgcmV0dXJuIE1hdGguYWJzKGFnZURhdGUuZ2V0VVRDRnVsbFllYXIoKS0gMTk3MClcclxufTtcclxuXHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgJy4uL2ltcG9ydHMvZ2xvYmFsJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxyXG59KTtcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdyZXNldEFsbCc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ0Z1bGwgcmVzZXQgY2FsbGVkLi4uJyk7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0UGF0aWVudHMnKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgnY2xlYXJFcHNzJyk7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ2NsZWFyUGF0Jyk7XHJcbiAgICB9XHJcbn0pOyJdfQ==
