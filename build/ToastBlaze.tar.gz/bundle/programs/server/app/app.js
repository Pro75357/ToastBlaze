var require = meteorInstall({"collections":{"epss.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/epss.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Epss: () => Epss
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let HTTP;
module.watch(require("meteor/http"), {
    HTTP(v) {
        HTTP = v;
    }

}, 1);
let Pat;
module.watch(require("./pat"), {
    Pat(v) {
        Pat = v;
    }

}, 2);
let Observations;
module.watch(require("./observations"), {
    Observations(v) {
        Observations = v;
    }

}, 3);
const Epss = new Mongo.Collection('epss');

/*
Please review the AHRQ Copyright and Disclaimer notice before using the API: https://www.uspreventiveservicestaskforce.org/Page/Name/copyright-notice.
Instructions for use and access information can be found at:
•	Instruction for Use:  http://epss.ahrq.gov/PDA/docs/ePSS_Data_API_WI_wLink.pdf
•	URL:  http://epssdata.ahrq.gov/
 */if (Meteor.isServer) {
    Meteor.methods({
        'getEpss': function () {
            //Very first, clean out old ePSS data (if any)
            Epss.remove({}); // First, we need to know the epss api url

            const url = 'http://epssdata.ahrq.gov/';
            let ePSS_Key = ''; // Next, get the ePSS key from the text file in the Private folder.
            // this folder will not sync with git as it is in the .gitignore

            try {
                ePSS_Key = JSON.parse(Assets.getText('ePSS_Key.json')); // If the key is blank or not updated, we cannot continue..
                //let blankKeys = ['','PUT_KEY_HERE']

                if (ePSS_Key.key === 'PUT_KEY_HERE') {
                    console.log('ePSS Key not found or invalid- please input your ePSS key into ePSS_Key.json file in private folder');
                    return;
                }
            } catch (e) {
                console.log('Fetching ePSS key failed. Please make sure ePSS_Key.json exists in the private folder.');
                console.log(e.message);
            } // build our params


            let sex = Pat.findOne().gen.sex;
            let age = getAge(Pat.findOne().gen.dob);
            let tobacco = '';

            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Smoking Status'
            })) {
                tobacco = Observations.findOne({
                    category: 'socialHistory',
                    name: 'Smoking Status'
                }).value;
            }

            let sexuallyActive = '';
            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            })) sexuallyActive = Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            }).value;
            let pregnant = null;

            if (sex === 'F') {
                pregnant = 'N'; // placeholder for real logic
            }

            let params = {
                age: age,
                sex: sex,
                pregnant: pregnant,
                // 'N' -- (Y,N) - requires Female sex to be present
                tobacco: tobacco,
                sexuallyActive: sexuallyActive,
                grade: ['A', 'B']
            }; // lastly, insert key into params

            params.key = ePSS_Key.key; // Try to fetch the ePSS recommendations based on the params.

            try {
                HTTP.call('get', url, {
                    headers: 'accept: json',
                    params
                }, function (err, result) {
                    if (err) {
                        throw err;
                    } else {
                        //only want to store the specific recommendations array objects
                        let epssCount = 0;
                        let recs = result.data.specificRecommendations;

                        for (let x in recs) {
                            Epss.insert(recs[x]);
                            epssCount += 1;
                        }

                        console.log(epssCount + ' ePSS recs inserted');
                        return true;
                    }
                });
            } catch (e) {
                console.log(e);
            }
        },
        'clearEpss': function () {
            Epss.remove({});
        }
    });
    Meteor.publish('epss', function () {
        return Epss.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('epss');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metrics.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/metrics.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Metrics: () => Metrics
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Metrics = new Mongo.Collection('metrics');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Metrics.remove({});
    });
    Meteor.publish('metrics', function () {
        return Metrics.find();
    });
    Meteor.methods({
        'getMetrics': function (patId) {
            Metrics.remove({});

            try {
                const metricsString = Assets.getText('metrics.csv');
                const metrics = Papa.parse(metricsString, {
                    header: true
                });
                let count = 0;

                for (let x in metrics.data) {
                    if (metrics.data[x].patId === patId) {
                        Metrics.insert(metrics.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' metrics entered');
            } catch (e) {
                console.log("something went wrong with parsing the metrics data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('metrics');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Observations: () => Observations
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Observations = new Mongo.Collection('obs');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear any data at startup as there should not be any patient in context.
        Observations.remove({});
    });
    Meteor.publish('obs', function () {
        return Observations.find();
    });
    Meteor.methods({
        'getObs': function (patId) {
            Observations.remove({});

            try {
                const String = Assets.getText('observations.csv');
                const parse = Papa.parse(String, {
                    header: true
                });
                let count = 0;

                for (let x in parse.data) {
                    if (parse.data[x].patId === patId) {
                        Observations.insert(parse.data[x]);
                        count += 1;
                    }
                } // Observations are in there, but the date field is just a string.
                // This will transform the string in the "date" field into a javascript date.


                let all = Observations.find().fetch();

                for (let x in all) {
                    let _id = all[x]._id;
                    let date = new Date(all[x].date); //console.log(date)

                    Observations.upsert({
                        _id: _id
                    }, {
                        $set: {
                            date: date
                        }
                    });
                }

                console.log(count + ' observations entered');
            } catch (e) {
                console.log("something went wrong with parsing the observations data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('obs');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pat.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/pat.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Pat: () => Pat
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
let Patients;
module.watch(require("./patients"), {
    Patients(v) {
        Patients = v;
    }

}, 2);
const Pat = new Mongo.Collection('pat');

// Once our patient is selected we need to populate our collections. The main functions for this are handled here
// With references to the other collections when needed.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Pat.remove({});
    });
    Meteor.methods({
        'updatePat': function (patId) {
            console.log("updatePat was run"); // Ok, First, let's fetch the other data about the patient
            // We'll store this single patient's data in a new Collection, pat
            // If any old data is in Pat, need to clear it

            Pat.remove({}); // Now, let's start fresh with our currently selected patient

            Pat.insert({
                _id: patId
            }); // these helper functions will make inserting and reading data easier
            // This one adds a new object to the database collection under this patId

            function updatePat(object) {
                //console.log(object)
                Pat.update({
                    _id: patId
                }, {
                    $set: object
                });
            } //e.g. - first let's use our "Patients" list and get the full name and also the age


            updatePat({
                name: Patients.findOne({
                    patId: patId
                }).fname + ' ' + Patients.findOne({
                    patId: patId
                }).lname,
                age: getAge(Patients.findOne({
                    patId: patId
                }).dob)
            }); // Let's throw everything else that is in the "Patients" collection about our patient in a gen (for "general") object

            updatePat({
                gen: Patients.findOne({
                    patId: patId
                })
            }); // Simulate a call to a table that holds patient Observations
            // The meteor.call actually just reads from the CSV, but it does then filter by the patId
            // sort of like how a real SQL call would work.
            // We will store this in our Pat collection under the group 'obs'

            Meteor.call('getObs', patId); // Now simulate a call for patient Metrics
            // this will go in a separate collection for searching, so just is a meteor.call

            Meteor.call('getMetrics', patId);
        },
        'clearPat': function () {
            Pat.remove({});
        }
    });
    Meteor.publish('pat', function () {
        return Pat.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('pat');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patients.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/patients.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Patients: () => Patients
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Patients = new Mongo.Collection('patients');

// Populate our local patient database with some pre-built patient data.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // code to run on server at startup
        // Only do this on startup if the db is empty
        if (Patients.find().count() === 0) {
            console.log("found no patients- getting data...");
            Meteor.call('resetPatients');
        } else {
            console.log('found patients already in database');
        }
    });
    Meteor.methods({
        'clearPatients': function () {
            Patients.remove({});
        },
        'resetPatients': function () {
            console.log('resetting patient DB');
            Patients.remove({}); // The patient data is stored as a CSV file in our "private" folder
            // This allows us to quick and dirty replicate what might be a view on Acuere
            // It would probably be easier if this would just pull from Acuere...
            //First, import the csv as a string: https://stackoverflow.com/questions/17453848/is-there-a-way-to-import-strings-from-a-text-file-in-javascript-meteor

            try {
                const patientString = Assets.getText('patients.csv'); // patientString will contain the data as one long CSV string
                // We need to parse it to a JSON object.
                // will use the Papa parse package to do this...

                const patientData = Papa.parse(patientString, {
                    header: true
                }); // We will store the data in our own Mongo collection that we defined above- Patients
                // Prefer to store each patient as their own "document" to make searches and stuff easier, so loop through the CSV data and insert one at a time

                let count = 0;

                for (let x in patientData.data) {
                    if (patientData.data[x].patId !== '') {
                        // ignores any blank rows (i.e. last row that always comes back)
                        Patients.insert(patientData.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' patients entered');
            } catch (e) {
                console.log("something went wrong with getting the patient list");
                console.log(e.message);
            }
        }
    });
    Meteor.publish('patients', function () {
        return Patients.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('patients');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/global.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// global functions go here
getAge = function (dobString) {
    let dob = new Date(dobString);
    let ageDifMs = Date.now() - dob.getTime();
    let ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
module.watch(require("../imports/global"));
Meteor.startup(() => {// code to run on server at startup
});
Meteor.methods({
    'resetAll': function () {
        console.log('Full reset called...');
        Meteor.call('resetPatients');
        Meteor.call('clearEpss');
        Meteor.call('clearPat');
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/epss.js");
require("./collections/metrics.js");
require("./collections/observations.js");
require("./collections/pat.js");
require("./collections/patients.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvZXBzcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvbWV0cmljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvb2JzZXJ2YXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9wYXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3BhdGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2dsb2JhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRXBzcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkhUVFAiLCJQYXQiLCJPYnNlcnZhdGlvbnMiLCJDb2xsZWN0aW9uIiwiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJtZXRob2RzIiwicmVtb3ZlIiwidXJsIiwiZVBTU19LZXkiLCJKU09OIiwicGFyc2UiLCJBc3NldHMiLCJnZXRUZXh0Iiwia2V5IiwiY29uc29sZSIsImxvZyIsImUiLCJtZXNzYWdlIiwic2V4IiwiZmluZE9uZSIsImdlbiIsImFnZSIsImdldEFnZSIsImRvYiIsInRvYmFjY28iLCJjYXRlZ29yeSIsIm5hbWUiLCJ2YWx1ZSIsInNleHVhbGx5QWN0aXZlIiwicHJlZ25hbnQiLCJwYXJhbXMiLCJncmFkZSIsImNhbGwiLCJoZWFkZXJzIiwiZXJyIiwicmVzdWx0IiwiZXBzc0NvdW50IiwicmVjcyIsImRhdGEiLCJzcGVjaWZpY1JlY29tbWVuZGF0aW9ucyIsIngiLCJpbnNlcnQiLCJwdWJsaXNoIiwiZmluZCIsImlzQ2xpZW50Iiwic3Vic2NyaWJlIiwiTWV0cmljcyIsInN0YXJ0dXAiLCJwYXRJZCIsIm1ldHJpY3NTdHJpbmciLCJtZXRyaWNzIiwiUGFwYSIsImhlYWRlciIsImNvdW50IiwiU3RyaW5nIiwiYWxsIiwiZmV0Y2giLCJfaWQiLCJkYXRlIiwiRGF0ZSIsInVwc2VydCIsIiRzZXQiLCJQYXRpZW50cyIsInVwZGF0ZVBhdCIsIm9iamVjdCIsInVwZGF0ZSIsImZuYW1lIiwibG5hbWUiLCJwYXRpZW50U3RyaW5nIiwicGF0aWVudERhdGEiLCJkb2JTdHJpbmciLCJhZ2VEaWZNcyIsIm5vdyIsImdldFRpbWUiLCJhZ2VEYXRlIiwiTWF0aCIsImFicyIsImdldFVUQ0Z1bGxZZWFyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsVUFBSyxNQUFJQTtBQUFWLENBQWQ7QUFBK0IsSUFBSUMsS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxJQUFKO0FBQVNQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0UsU0FBS0QsQ0FBTCxFQUFPO0FBQUNDLGVBQUtELENBQUw7QUFBTzs7QUFBaEIsQ0FBcEMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsR0FBSjtBQUFRUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNHLFFBQUlGLENBQUosRUFBTTtBQUFDRSxjQUFJRixDQUFKO0FBQU07O0FBQWQsQ0FBOUIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ0ksaUJBQWFILENBQWIsRUFBZTtBQUFDRyx1QkFBYUgsQ0FBYjtBQUFlOztBQUFoQyxDQUF2QyxFQUF5RSxDQUF6RTtBQUMxTyxNQUFNSixPQUFPLElBQUlDLE1BQU1PLFVBQVYsQ0FBcUIsTUFBckIsQ0FBYjs7QUFNUDs7Ozs7R0FPQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPRSxPQUFQLENBQWU7QUFFWCxtQkFBVyxZQUFZO0FBQ25CO0FBR0FYLGlCQUFLWSxNQUFMLENBQVksRUFBWixFQUptQixDQU1uQjs7QUFDQSxrQkFBTUMsTUFBTSwyQkFBWjtBQUNBLGdCQUFJQyxXQUFXLEVBQWYsQ0FSbUIsQ0FTbkI7QUFDQTs7QUFFQSxnQkFBSTtBQUNBQSwyQkFBV0MsS0FBS0MsS0FBTCxDQUFXQyxPQUFPQyxPQUFQLENBQWUsZUFBZixDQUFYLENBQVgsQ0FEQSxDQUVBO0FBQ0E7O0FBQ0Esb0JBQUlKLFNBQVNLLEdBQVQsS0FBaUIsY0FBckIsRUFBcUM7QUFDakNDLDRCQUFRQyxHQUFSLENBQVkscUdBQVo7QUFDQTtBQUNIO0FBQ0osYUFSRCxDQVFFLE9BQU1DLENBQU4sRUFBUTtBQUNORix3QkFBUUMsR0FBUixDQUFZLHdGQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDSCxhQXZCa0IsQ0EwQi9COzs7QUFDWSxnQkFBSUMsTUFBTWxCLElBQUltQixPQUFKLEdBQWNDLEdBQWQsQ0FBa0JGLEdBQTVCO0FBQ0EsZ0JBQUlHLE1BQU1DLE9BQU90QixJQUFJbUIsT0FBSixHQUFjQyxHQUFkLENBQWtCRyxHQUF6QixDQUFWO0FBQ0EsZ0JBQUlDLFVBQVUsRUFBZDs7QUFDQSxnQkFBSXZCLGFBQWFrQixPQUFiLENBQXFCO0FBQUNNLDBCQUFVLGVBQVg7QUFBNEJDLHNCQUFNO0FBQWxDLGFBQXJCLENBQUosRUFBK0U7QUFDM0VGLDBCQUFVdkIsYUFBYWtCLE9BQWIsQ0FBcUI7QUFBQ00sOEJBQVUsZUFBWDtBQUE0QkMsMEJBQU07QUFBbEMsaUJBQXJCLEVBQTBFQyxLQUFwRjtBQUNIOztBQUVELGdCQUFJQyxpQkFBaUIsRUFBckI7QUFDQSxnQkFBSTNCLGFBQWFrQixPQUFiLENBQXFCO0FBQUNNLDBCQUFVLGVBQVg7QUFBNEJDLHNCQUFNO0FBQWxDLGFBQXJCLENBQUosRUFDSUUsaUJBQWlCM0IsYUFBYWtCLE9BQWIsQ0FBcUI7QUFBQ00sMEJBQVUsZUFBWDtBQUE0QkMsc0JBQU07QUFBbEMsYUFBckIsRUFBMkVDLEtBQTVGO0FBQ0osZ0JBQUlFLFdBQVcsSUFBZjs7QUFDQSxnQkFBR1gsUUFBTyxHQUFWLEVBQWM7QUFDVlcsMkJBQVcsR0FBWCxDQURVLENBQ0s7QUFDbEI7O0FBRUQsZ0JBQUlDLFNBQVM7QUFDVFQscUJBQUtBLEdBREk7QUFFVEgscUJBQUtBLEdBRkk7QUFHVFcsMEJBQVVBLFFBSEQ7QUFHVztBQUNwQkwseUJBQVNBLE9BSkE7QUFLVEksZ0NBQWdCQSxjQUxQO0FBTVRHLHVCQUFPLENBQUMsR0FBRCxFQUFNLEdBQU47QUFORSxhQUFiLENBMUNtQixDQW1EbkI7O0FBQ0FELG1CQUFPakIsR0FBUCxHQUFhTCxTQUFTSyxHQUF0QixDQXBEbUIsQ0FzRG5COztBQUNBLGdCQUFJO0FBQ0FkLHFCQUFLaUMsSUFBTCxDQUFVLEtBQVYsRUFDSXpCLEdBREosRUFFSTtBQUNJMEIsNkJBQVMsY0FEYjtBQUVJSDtBQUZKLGlCQUZKLEVBS08sVUFBU0ksR0FBVCxFQUFjQyxNQUFkLEVBQXFCO0FBQ3hCLHdCQUFHRCxHQUFILEVBQU87QUFDSCw4QkFBTUEsR0FBTjtBQUNILHFCQUZELE1BRU87QUFDSDtBQUNBLDRCQUFJRSxZQUFZLENBQWhCO0FBQ0EsNEJBQUlDLE9BQU9GLE9BQU9HLElBQVAsQ0FBWUMsdUJBQXZCOztBQUNBLDZCQUFLLElBQUlDLENBQVQsSUFBY0gsSUFBZCxFQUFvQjtBQUNoQjNDLGlDQUFLK0MsTUFBTCxDQUFZSixLQUFLRyxDQUFMLENBQVo7QUFDQUoseUNBQVksQ0FBWjtBQUNIOztBQUNEdEIsZ0NBQVFDLEdBQVIsQ0FBWXFCLFlBQVkscUJBQXhCO0FBQ0EsK0JBQU8sSUFBUDtBQUNIO0FBRUEsaUJBcEJMO0FBdUJILGFBeEJELENBd0JFLE9BQU9wQixDQUFQLEVBQVU7QUFDUkYsd0JBQVFDLEdBQVIsQ0FBWUMsQ0FBWjtBQUNIO0FBQ0osU0FwRlU7QUFzRlgscUJBQWEsWUFBVztBQUNwQnRCLGlCQUFLWSxNQUFMLENBQVksRUFBWjtBQUNIO0FBeEZVLEtBQWY7QUE0RklILFdBQU91QyxPQUFQLENBQWUsTUFBZixFQUF1QixZQUFVO0FBQzdCLGVBQU9oRCxLQUFLaUQsSUFBTCxFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUl4QyxPQUFPeUMsUUFBWCxFQUFvQjtBQUNoQnpDLFdBQU8wQyxTQUFQLENBQWlCLE1BQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNuSERyRCxPQUFPQyxNQUFQLENBQWM7QUFBQ3FELGFBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUluRCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHL0csTUFBTWdELFVBQVUsSUFBSW5ELE1BQU1PLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7O0FBRVA7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPNEMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQUQsZ0JBQVF4QyxNQUFSLENBQWUsRUFBZjtBQUVILEtBSkQ7QUFPQUgsV0FBT3VDLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVU7QUFDaEMsZUFBT0ksUUFBUUgsSUFBUixFQUFQO0FBQ0gsS0FGRDtBQUlBeEMsV0FBT0UsT0FBUCxDQUFlO0FBQ1gsc0JBQWMsVUFBUzJDLEtBQVQsRUFBZTtBQUN6QkYsb0JBQVF4QyxNQUFSLENBQWUsRUFBZjs7QUFDQSxnQkFBSTtBQUNBLHNCQUFNMkMsZ0JBQWdCdEMsT0FBT0MsT0FBUCxDQUFlLGFBQWYsQ0FBdEI7QUFFQSxzQkFBTXNDLFVBQVVDLEtBQUt6QyxLQUFMLENBQVd1QyxhQUFYLEVBQTBCO0FBQUNHLDRCQUFRO0FBQVQsaUJBQTFCLENBQWhCO0FBQ0Esb0JBQUlDLFFBQVEsQ0FBWjs7QUFDQSxxQkFBSyxJQUFJYixDQUFULElBQWNVLFFBQVFaLElBQXRCLEVBQTRCO0FBQ3hCLHdCQUFJWSxRQUFRWixJQUFSLENBQWFFLENBQWIsRUFBZ0JRLEtBQWhCLEtBQTBCQSxLQUE5QixFQUFxQztBQUNqQ0YsZ0NBQVFMLE1BQVIsQ0FBZVMsUUFBUVosSUFBUixDQUFhRSxDQUFiLENBQWY7QUFDQWEsaUNBQVMsQ0FBVDtBQUNIO0FBQ0o7O0FBQ0R2Qyx3QkFBUUMsR0FBUixDQUFZc0MsUUFBUSxrQkFBcEI7QUFDSCxhQVpELENBWUUsT0FBT3JDLENBQVAsRUFBVTtBQUNSRix3QkFBUUMsR0FBUixDQUFZLG9EQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDQSx1QkFBTyxLQUFQO0FBQ0g7O0FBQ0QsbUJBQU8sSUFBUDtBQUNIO0FBckJVLEtBQWY7QUF1Qkg7O0FBRUQsSUFBSWQsT0FBT3lDLFFBQVgsRUFBb0I7QUFDaEJ6QyxXQUFPMEMsU0FBUCxDQUFpQixTQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDaEREckQsT0FBT0MsTUFBUCxDQUFjO0FBQUNRLGtCQUFhLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSU4sS0FBSjtBQUFVSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJSyxNQUFKO0FBQVdYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sV0FBT0wsQ0FBUCxFQUFTO0FBQUNLLGlCQUFPTCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBR3pILE1BQU1HLGVBQWUsSUFBSU4sTUFBTU8sVUFBVixDQUFxQixLQUFyQixDQUFyQjs7QUFFUDtBQUdBLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU80QyxPQUFQLENBQWUsTUFBTTtBQUNqQjtBQUNBOUMscUJBQWFLLE1BQWIsQ0FBb0IsRUFBcEI7QUFFSCxLQUpEO0FBT0FILFdBQU91QyxPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLGVBQU96QyxhQUFhMEMsSUFBYixFQUFQO0FBQ0gsS0FGRDtBQUlBeEMsV0FBT0UsT0FBUCxDQUFlO0FBQ1gsa0JBQVUsVUFBUzJDLEtBQVQsRUFBZTtBQUNyQi9DLHlCQUFhSyxNQUFiLENBQW9CLEVBQXBCOztBQUVBLGdCQUFJO0FBQ0Esc0JBQU1nRCxTQUFTM0MsT0FBT0MsT0FBUCxDQUFlLGtCQUFmLENBQWY7QUFFQSxzQkFBTUYsUUFBUXlDLEtBQUt6QyxLQUFMLENBQVc0QyxNQUFYLEVBQW1CO0FBQUNGLDRCQUFRO0FBQVQsaUJBQW5CLENBQWQ7QUFDQSxvQkFBSUMsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUliLENBQVQsSUFBYzlCLE1BQU00QixJQUFwQixFQUEwQjtBQUN0Qix3QkFBSTVCLE1BQU00QixJQUFOLENBQVdFLENBQVgsRUFBY1EsS0FBZCxLQUF3QkEsS0FBNUIsRUFBbUM7QUFDL0IvQyxxQ0FBYXdDLE1BQWIsQ0FBb0IvQixNQUFNNEIsSUFBTixDQUFXRSxDQUFYLENBQXBCO0FBQ0FhLGlDQUFTLENBQVQ7QUFDSDtBQUNKLGlCQVZELENBV0E7QUFDQTs7O0FBQ0Esb0JBQUlFLE1BQU10RCxhQUFhMEMsSUFBYixHQUFvQmEsS0FBcEIsRUFBVjs7QUFDQSxxQkFBSyxJQUFJaEIsQ0FBVCxJQUFjZSxHQUFkLEVBQWtCO0FBQ2Qsd0JBQUlFLE1BQU1GLElBQUlmLENBQUosRUFBT2lCLEdBQWpCO0FBQ0Esd0JBQUlDLE9BQU8sSUFBSUMsSUFBSixDQUFTSixJQUFJZixDQUFKLEVBQU9rQixJQUFoQixDQUFYLENBRmMsQ0FHZDs7QUFDQXpELGlDQUFhMkQsTUFBYixDQUFvQjtBQUFDSCw2QkFBS0E7QUFBTixxQkFBcEIsRUFBK0I7QUFBQ0ksOEJBQU07QUFBQ0gsa0NBQU1BO0FBQVA7QUFBUCxxQkFBL0I7QUFDSDs7QUFFRDVDLHdCQUFRQyxHQUFSLENBQVlzQyxRQUFRLHVCQUFwQjtBQUNILGFBdEJELENBc0JFLE9BQU9yQyxDQUFQLEVBQVU7QUFDUkYsd0JBQVFDLEdBQVIsQ0FBWSx5REFBWjtBQUNBRCx3QkFBUUMsR0FBUixDQUFZQyxFQUFFQyxPQUFkO0FBQ0EsdUJBQU8sS0FBUDtBQUNIOztBQUNELG1CQUFPLElBQVA7QUFDSDtBQWhDVSxLQUFmO0FBa0NIOztBQUVELElBQUlkLE9BQU95QyxRQUFYLEVBQW9CO0FBQ2hCekMsV0FBTzBDLFNBQVAsQ0FBaUIsS0FBakI7QUFDSCxDOzs7Ozs7Ozs7OztBQzNERHJELE9BQU9DLE1BQVAsQ0FBYztBQUFDTyxTQUFJLE1BQUlBO0FBQVQsQ0FBZDtBQUE2QixJQUFJTCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWdFLFFBQUo7QUFBYXRFLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ2lFLGFBQVNoRSxDQUFULEVBQVc7QUFBQ2dFLG1CQUFTaEUsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUluTCxNQUFNRSxNQUFNLElBQUlMLE1BQU1PLFVBQVYsQ0FBcUIsS0FBckIsQ0FBWjs7QUFFUDtBQUNBO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsV0FBTzRDLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBQ0EvQyxZQUFJTSxNQUFKLENBQVcsRUFBWDtBQUVILEtBSkQ7QUFNQUgsV0FBT0UsT0FBUCxDQUFlO0FBQ1gscUJBQWEsVUFBUzJDLEtBQVQsRUFBZ0I7QUFDekJsQyxvQkFBUUMsR0FBUixDQUFZLG1CQUFaLEVBRHlCLENBRXpCO0FBQ0E7QUFFQTs7QUFDQWYsZ0JBQUlNLE1BQUosQ0FBVyxFQUFYLEVBTnlCLENBUXpCOztBQUNBTixnQkFBSXlDLE1BQUosQ0FBVztBQUFDZ0IscUJBQUtUO0FBQU4sYUFBWCxFQVR5QixDQVl6QjtBQUVBOztBQUNBLHFCQUFTZSxTQUFULENBQW1CQyxNQUFuQixFQUEyQjtBQUN2QjtBQUNBaEUsb0JBQUlpRSxNQUFKLENBQVc7QUFBQ1IseUJBQUtUO0FBQU4saUJBQVgsRUFBeUI7QUFBQ2EsMEJBQU9HO0FBQVIsaUJBQXpCO0FBQ0gsYUFsQndCLENBb0J6Qjs7O0FBQ0FELHNCQUFVO0FBQ05yQyxzQkFBTW9DLFNBQVMzQyxPQUFULENBQWlCO0FBQUM2QiwyQkFBT0E7QUFBUixpQkFBakIsRUFBaUNrQixLQUFqQyxHQUF5QyxHQUF6QyxHQUErQ0osU0FBUzNDLE9BQVQsQ0FBaUI7QUFBQzZCLDJCQUFPQTtBQUFSLGlCQUFqQixFQUFpQ21CLEtBRGhGO0FBRU45QyxxQkFBS0MsT0FBT3dDLFNBQVMzQyxPQUFULENBQWlCO0FBQUM2QiwyQkFBT0E7QUFBUixpQkFBakIsRUFBaUN6QixHQUF4QztBQUZDLGFBQVYsRUFyQnlCLENBMEJ6Qjs7QUFDQXdDLHNCQUFVO0FBQ04zQyxxQkFBSzBDLFNBQVMzQyxPQUFULENBQWlCO0FBQUM2QiwyQkFBT0E7QUFBUixpQkFBakI7QUFEQyxhQUFWLEVBM0J5QixDQStCckM7QUFDWTtBQUNBO0FBQ0E7O0FBRUE3QyxtQkFBTzZCLElBQVAsQ0FBWSxRQUFaLEVBQXNCZ0IsS0FBdEIsRUFwQ3lCLENBc0NyQztBQUNZOztBQUVBN0MsbUJBQU82QixJQUFQLENBQVksWUFBWixFQUEwQmdCLEtBQTFCO0FBRUgsU0E1Q1U7QUE4Q1gsb0JBQVksWUFBVztBQUNuQmhELGdCQUFJTSxNQUFKLENBQVcsRUFBWDtBQUNIO0FBaERVLEtBQWY7QUFvRElILFdBQU91QyxPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLGVBQU8xQyxJQUFJMkMsSUFBSixFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUl4QyxPQUFPeUMsUUFBWCxFQUFvQjtBQUNoQnpDLFdBQU8wQyxTQUFQLENBQWlCLEtBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUM3RURyRCxPQUFPQyxNQUFQLENBQWM7QUFBQ3FFLGNBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUluRSxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFakgsTUFBTWdFLFdBQVcsSUFBSW5FLE1BQU1PLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBR1A7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRXJCRCxXQUFPNEMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFFQTtBQUNBLFlBQUllLFNBQVNuQixJQUFULEdBQWdCVSxLQUFoQixPQUE0QixDQUFoQyxFQUFrQztBQUM5QnZDLG9CQUFRQyxHQUFSLENBQVksb0NBQVo7QUFDQVosbUJBQU82QixJQUFQLENBQVksZUFBWjtBQUVILFNBSkQsTUFJTTtBQUNGbEIsb0JBQVFDLEdBQVIsQ0FBWSxvQ0FBWjtBQUNIO0FBRUosS0FaRDtBQWNJWixXQUFPRSxPQUFQLENBQWU7QUFDWCx5QkFBaUIsWUFBVztBQUN4QnlELHFCQUFTeEQsTUFBVCxDQUFnQixFQUFoQjtBQUNILFNBSFU7QUFLWCx5QkFBaUIsWUFBVztBQUN4QlEsb0JBQVFDLEdBQVIsQ0FBWSxzQkFBWjtBQUNBK0MscUJBQVN4RCxNQUFULENBQWdCLEVBQWhCLEVBRndCLENBSXhCO0FBQ0E7QUFDQTtBQUVBOztBQUVBLGdCQUFJO0FBQ0Esc0JBQU04RCxnQkFBZ0J6RCxPQUFPQyxPQUFQLENBQWUsY0FBZixDQUF0QixDQURBLENBRUE7QUFDQTtBQUNBOztBQUVBLHNCQUFNeUQsY0FBY2xCLEtBQUt6QyxLQUFMLENBQVcwRCxhQUFYLEVBQTBCO0FBQUNoQiw0QkFBUTtBQUFULGlCQUExQixDQUFwQixDQU5BLENBUUE7QUFDQTs7QUFDQSxvQkFBSUMsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUliLENBQVQsSUFBYzZCLFlBQVkvQixJQUExQixFQUFnQztBQUM1Qix3QkFBRytCLFlBQVkvQixJQUFaLENBQWlCRSxDQUFqQixFQUFvQlEsS0FBcEIsS0FBNkIsRUFBaEMsRUFBbUM7QUFBRTtBQUNqQ2MsaUNBQVNyQixNQUFULENBQWdCNEIsWUFBWS9CLElBQVosQ0FBaUJFLENBQWpCLENBQWhCO0FBQ0FhLGlDQUFTLENBQVQ7QUFDSDtBQUNKOztBQUNEdkMsd0JBQVFDLEdBQVIsQ0FBWXNDLFFBQVEsbUJBQXBCO0FBRUgsYUFuQkQsQ0FtQkUsT0FBT3JDLENBQVAsRUFBVTtBQUNSRix3QkFBUUMsR0FBUixDQUFZLG9EQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDSDtBQUNKO0FBdENVLEtBQWY7QUEwQ0lkLFdBQU91QyxPQUFQLENBQWUsVUFBZixFQUEyQixZQUFVO0FBQ2pDLGVBQU9vQixTQUFTbkIsSUFBVCxFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUl4QyxPQUFPeUMsUUFBWCxFQUFvQjtBQUNoQnpDLFdBQU8wQyxTQUFQLENBQWlCLFVBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUN6RUQ7QUFFQXZCLFNBQVMsVUFBU2dELFNBQVQsRUFBbUI7QUFDeEIsUUFBSS9DLE1BQU0sSUFBSW9DLElBQUosQ0FBVVcsU0FBVixDQUFWO0FBQ0EsUUFBSUMsV0FBV1osS0FBS2EsR0FBTCxLQUFhakQsSUFBSWtELE9BQUosRUFBNUI7QUFDQSxRQUFJQyxVQUFVLElBQUlmLElBQUosQ0FBU1ksUUFBVCxDQUFkO0FBQ0EsV0FBT0ksS0FBS0MsR0FBTCxDQUFTRixRQUFRRyxjQUFSLEtBQTBCLElBQW5DLENBQVA7QUFDSCxDQUxELEM7Ozs7Ozs7Ozs7O0FDRkEsSUFBSTFFLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0ROLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiO0FBRzFFTSxPQUFPNEMsT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZEO0FBSUE1QyxPQUFPRSxPQUFQLENBQWU7QUFDWCxnQkFBWSxZQUFVO0FBQ2xCUyxnQkFBUUMsR0FBUixDQUFZLHNCQUFaO0FBQ0FaLGVBQU82QixJQUFQLENBQVksZUFBWjtBQUNBN0IsZUFBTzZCLElBQVAsQ0FBWSxXQUFaO0FBQ0E3QixlQUFPNkIsSUFBUCxDQUFZLFVBQVo7QUFDSDtBQU5VLENBQWYsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5leHBvcnQgY29uc3QgRXBzcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdlcHNzJyk7XHJcbmltcG9ydCB7SFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xyXG5pbXBvcnQge1BhdH0gZnJvbSBcIi4vcGF0XCI7XHJcbmltcG9ydCB7T2JzZXJ2YXRpb25zfSBmcm9tIFwiLi9vYnNlcnZhdGlvbnNcIjtcclxuXHJcblxyXG4vKlxyXG5QbGVhc2UgcmV2aWV3IHRoZSBBSFJRIENvcHlyaWdodCBhbmQgRGlzY2xhaW1lciBub3RpY2UgYmVmb3JlIHVzaW5nIHRoZSBBUEk6IGh0dHBzOi8vd3d3LnVzcHJldmVudGl2ZXNlcnZpY2VzdGFza2ZvcmNlLm9yZy9QYWdlL05hbWUvY29weXJpZ2h0LW5vdGljZS5cclxuSW5zdHJ1Y3Rpb25zIGZvciB1c2UgYW5kIGFjY2VzcyBpbmZvcm1hdGlvbiBjYW4gYmUgZm91bmQgYXQ6XHJcbuKAolx0SW5zdHJ1Y3Rpb24gZm9yIFVzZTogIGh0dHA6Ly9lcHNzLmFocnEuZ292L1BEQS9kb2NzL2VQU1NfRGF0YV9BUElfV0lfd0xpbmsucGRmXHJcbuKAolx0VVJMOiAgaHR0cDovL2Vwc3NkYXRhLmFocnEuZ292L1xyXG4gKi9cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gICAgICAgICdnZXRFcHNzJzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvL1ZlcnkgZmlyc3QsIGNsZWFuIG91dCBvbGQgZVBTUyBkYXRhIChpZiBhbnkpXHJcblxyXG5cclxuICAgICAgICAgICAgRXBzcy5yZW1vdmUoe30pO1xyXG5cclxuICAgICAgICAgICAgLy8gRmlyc3QsIHdlIG5lZWQgdG8ga25vdyB0aGUgZXBzcyBhcGkgdXJsXHJcbiAgICAgICAgICAgIGNvbnN0IHVybCA9ICdodHRwOi8vZXBzc2RhdGEuYWhycS5nb3YvJztcclxuICAgICAgICAgICAgbGV0IGVQU1NfS2V5ID0gJyc7XHJcbiAgICAgICAgICAgIC8vIE5leHQsIGdldCB0aGUgZVBTUyBrZXkgZnJvbSB0aGUgdGV4dCBmaWxlIGluIHRoZSBQcml2YXRlIGZvbGRlci5cclxuICAgICAgICAgICAgLy8gdGhpcyBmb2xkZXIgd2lsbCBub3Qgc3luYyB3aXRoIGdpdCBhcyBpdCBpcyBpbiB0aGUgLmdpdGlnbm9yZVxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGVQU1NfS2V5ID0gSlNPTi5wYXJzZShBc3NldHMuZ2V0VGV4dCgnZVBTU19LZXkuanNvbicpKTtcclxuICAgICAgICAgICAgICAgIC8vIElmIHRoZSBrZXkgaXMgYmxhbmsgb3Igbm90IHVwZGF0ZWQsIHdlIGNhbm5vdCBjb250aW51ZS4uXHJcbiAgICAgICAgICAgICAgICAvL2xldCBibGFua0tleXMgPSBbJycsJ1BVVF9LRVlfSEVSRSddXHJcbiAgICAgICAgICAgICAgICBpZiAoZVBTU19LZXkua2V5ID09PSAnUFVUX0tFWV9IRVJFJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdlUFNTIEtleSBub3QgZm91bmQgb3IgaW52YWxpZC0gcGxlYXNlIGlucHV0IHlvdXIgZVBTUyBrZXkgaW50byBlUFNTX0tleS5qc29uIGZpbGUgaW4gcHJpdmF0ZSBmb2xkZXInKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2goZSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcgZVBTUyBrZXkgZmFpbGVkLiBQbGVhc2UgbWFrZSBzdXJlIGVQU1NfS2V5Lmpzb24gZXhpc3RzIGluIHRoZSBwcml2YXRlIGZvbGRlci4nKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUubWVzc2FnZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbi8vIGJ1aWxkIG91ciBwYXJhbXNcclxuICAgICAgICAgICAgbGV0IHNleCA9IFBhdC5maW5kT25lKCkuZ2VuLnNleDtcclxuICAgICAgICAgICAgbGV0IGFnZSA9IGdldEFnZShQYXQuZmluZE9uZSgpLmdlbi5kb2IpO1xyXG4gICAgICAgICAgICBsZXQgdG9iYWNjbyA9ICcnO1xyXG4gICAgICAgICAgICBpZiAoT2JzZXJ2YXRpb25zLmZpbmRPbmUoe2NhdGVnb3J5OiAnc29jaWFsSGlzdG9yeScsIG5hbWU6ICdTbW9raW5nIFN0YXR1cyd9KSkge1xyXG4gICAgICAgICAgICAgICAgdG9iYWNjbyA9IE9ic2VydmF0aW9ucy5maW5kT25lKHtjYXRlZ29yeTogJ3NvY2lhbEhpc3RvcnknLCBuYW1lOiAnU21va2luZyBTdGF0dXMnfSkudmFsdWU7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBzZXh1YWxseUFjdGl2ZSA9ICcnO1xyXG4gICAgICAgICAgICBpZiAoT2JzZXJ2YXRpb25zLmZpbmRPbmUoe2NhdGVnb3J5OiAnc29jaWFsSGlzdG9yeScsIG5hbWU6ICdTZXh1YWxseSBBY3RpdmUnfSkpXHJcbiAgICAgICAgICAgICAgICBzZXh1YWxseUFjdGl2ZSA9IE9ic2VydmF0aW9ucy5maW5kT25lKHtjYXRlZ29yeTogJ3NvY2lhbEhpc3RvcnknLCBuYW1lOiAnU2V4dWFsbHkgQWN0aXZlJ30pLnZhbHVlO1xyXG4gICAgICAgICAgICBsZXQgcHJlZ25hbnQgPSBudWxsO1xyXG4gICAgICAgICAgICBpZihzZXggPT09J0YnKXtcclxuICAgICAgICAgICAgICAgIHByZWduYW50ID0gJ04nIC8vIHBsYWNlaG9sZGVyIGZvciByZWFsIGxvZ2ljXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBhZ2U6IGFnZSxcclxuICAgICAgICAgICAgICAgIHNleDogc2V4LFxyXG4gICAgICAgICAgICAgICAgcHJlZ25hbnQ6IHByZWduYW50LCAvLyAnTicgLS0gKFksTikgLSByZXF1aXJlcyBGZW1hbGUgc2V4IHRvIGJlIHByZXNlbnRcclxuICAgICAgICAgICAgICAgIHRvYmFjY286IHRvYmFjY28sXHJcbiAgICAgICAgICAgICAgICBzZXh1YWxseUFjdGl2ZTogc2V4dWFsbHlBY3RpdmUsXHJcbiAgICAgICAgICAgICAgICBncmFkZTogWydBJywgJ0InXVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLy8gbGFzdGx5LCBpbnNlcnQga2V5IGludG8gcGFyYW1zXHJcbiAgICAgICAgICAgIHBhcmFtcy5rZXkgPSBlUFNTX0tleS5rZXk7XHJcblxyXG4gICAgICAgICAgICAvLyBUcnkgdG8gZmV0Y2ggdGhlIGVQU1MgcmVjb21tZW5kYXRpb25zIGJhc2VkIG9uIHRoZSBwYXJhbXMuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBIVFRQLmNhbGwoJ2dldCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsLFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczogJ2FjY2VwdDoganNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtc1xyXG4gICAgICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uKGVyciwgcmVzdWx0KXtcclxuICAgICAgICAgICAgICAgICAgICBpZihlcnIpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnJcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL29ubHkgd2FudCB0byBzdG9yZSB0aGUgc3BlY2lmaWMgcmVjb21tZW5kYXRpb25zIGFycmF5IG9iamVjdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVwc3NDb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZWNzID0gcmVzdWx0LmRhdGEuc3BlY2lmaWNSZWNvbW1lbmRhdGlvbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gcmVjcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRXBzcy5pbnNlcnQocmVjc1t4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcHNzQ291bnQgKz0xO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVwc3NDb3VudCArICcgZVBTUyByZWNzIGluc2VydGVkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgICdjbGVhckVwc3MnOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICAgICAgRXBzcy5yZW1vdmUoe30pXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICAgICBNZXRlb3IucHVibGlzaCgnZXBzcycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHJldHVybiBFcHNzLmZpbmQoKVxyXG4gICAgICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnZXBzcycpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IE1ldHJpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWV0cmljcycpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBwYXQgY29sbGVjdGlvbi5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFudCBQYXQgZGF0YSBhdCBzdGFydHVwIGFzIHRoZXJlIHNob3VsZCBub3QgYmUgYW55IHBhdGllbnQgaW4gY29udGV4dC5cclxuICAgICAgICBNZXRyaWNzLnJlbW92ZSh7fSlcclxuXHJcbiAgICB9KTtcclxuXHJcblxyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ21ldHJpY3MnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgIHJldHVybiBNZXRyaWNzLmZpbmQoKVxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICdnZXRNZXRyaWNzJzogZnVuY3Rpb24ocGF0SWQpe1xyXG4gICAgICAgICAgICBNZXRyaWNzLnJlbW92ZSh7fSk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtZXRyaWNzU3RyaW5nID0gQXNzZXRzLmdldFRleHQoJ21ldHJpY3MuY3N2Jyk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29uc3QgbWV0cmljcyA9IFBhcGEucGFyc2UobWV0cmljc1N0cmluZywge2hlYWRlcjogdHJ1ZX0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gbWV0cmljcy5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1ldHJpY3MuZGF0YVt4XS5wYXRJZCA9PT0gcGF0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgTWV0cmljcy5pbnNlcnQobWV0cmljcy5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBtZXRyaWNzIGVudGVyZWQnKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNvbWV0aGluZyB3ZW50IHdyb25nIHdpdGggcGFyc2luZyB0aGUgbWV0cmljcyBkYXRhXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdtZXRyaWNzJylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcblxyXG5leHBvcnQgY29uc3QgT2JzZXJ2YXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ29icycpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBwYXQgY29sbGVjdGlvbi5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFueSBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIE9ic2VydmF0aW9ucy5yZW1vdmUoe30pXHJcblxyXG4gICAgfSk7XHJcblxyXG5cclxuICAgIE1ldGVvci5wdWJsaXNoKCdvYnMnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgIHJldHVybiBPYnNlcnZhdGlvbnMuZmluZCgpXHJcbiAgICB9KTtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcbiAgICAgICAgJ2dldE9icyc6IGZ1bmN0aW9uKHBhdElkKXtcclxuICAgICAgICAgICAgT2JzZXJ2YXRpb25zLnJlbW92ZSh7fSk7XHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgU3RyaW5nID0gQXNzZXRzLmdldFRleHQoJ29ic2VydmF0aW9ucy5jc3YnKTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJzZSA9IFBhcGEucGFyc2UoU3RyaW5nLCB7aGVhZGVyOiB0cnVlfSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBwYXJzZS5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcnNlLmRhdGFbeF0ucGF0SWQgPT09IHBhdElkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE9ic2VydmF0aW9ucy5pbnNlcnQocGFyc2UuZGF0YVt4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IDFcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBPYnNlcnZhdGlvbnMgYXJlIGluIHRoZXJlLCBidXQgdGhlIGRhdGUgZmllbGQgaXMganVzdCBhIHN0cmluZy5cclxuICAgICAgICAgICAgICAgIC8vIFRoaXMgd2lsbCB0cmFuc2Zvcm0gdGhlIHN0cmluZyBpbiB0aGUgXCJkYXRlXCIgZmllbGQgaW50byBhIGphdmFzY3JpcHQgZGF0ZS5cclxuICAgICAgICAgICAgICAgIGxldCBhbGwgPSBPYnNlcnZhdGlvbnMuZmluZCgpLmZldGNoKClcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gYWxsKXtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgX2lkID0gYWxsW3hdLl9pZFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoYWxsW3hdLmRhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhkYXRlKVxyXG4gICAgICAgICAgICAgICAgICAgIE9ic2VydmF0aW9ucy51cHNlcnQoe19pZDogX2lkfSx7JHNldDoge2RhdGU6IGRhdGV9fSlcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhjb3VudCArICcgb2JzZXJ2YXRpb25zIGVudGVyZWQnKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNvbWV0aGluZyB3ZW50IHdyb25nIHdpdGggcGFyc2luZyB0aGUgb2JzZXJ2YXRpb25zIGRhdGFcIilcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUubWVzc2FnZSlcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdvYnMnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuaW1wb3J0IHtQYXRpZW50c30gZnJvbSBcIi4vcGF0aWVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBQYXQgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGF0Jyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIGNvbGxlY3Rpb25zLiBUaGUgbWFpbiBmdW5jdGlvbnMgZm9yIHRoaXMgYXJlIGhhbmRsZWQgaGVyZVxyXG4vLyBXaXRoIHJlZmVyZW5jZXMgdG8gdGhlIG90aGVyIGNvbGxlY3Rpb25zIHdoZW4gbmVlZGVkLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW50IFBhdCBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIFBhdC5yZW1vdmUoe30pXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICd1cGRhdGVQYXQnOiBmdW5jdGlvbihwYXRJZCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVBhdCB3YXMgcnVuXCIpO1xyXG4gICAgICAgICAgICAvLyBPaywgRmlyc3QsIGxldCdzIGZldGNoIHRoZSBvdGhlciBkYXRhIGFib3V0IHRoZSBwYXRpZW50XHJcbiAgICAgICAgICAgIC8vIFdlJ2xsIHN0b3JlIHRoaXMgc2luZ2xlIHBhdGllbnQncyBkYXRhIGluIGEgbmV3IENvbGxlY3Rpb24sIHBhdFxyXG5cclxuICAgICAgICAgICAgLy8gSWYgYW55IG9sZCBkYXRhIGlzIGluIFBhdCwgbmVlZCB0byBjbGVhciBpdFxyXG4gICAgICAgICAgICBQYXQucmVtb3ZlKHt9KVxyXG5cclxuICAgICAgICAgICAgLy8gTm93LCBsZXQncyBzdGFydCBmcmVzaCB3aXRoIG91ciBjdXJyZW50bHkgc2VsZWN0ZWQgcGF0aWVudFxyXG4gICAgICAgICAgICBQYXQuaW5zZXJ0KHtfaWQ6IHBhdElkfSk7XHJcblxyXG5cclxuICAgICAgICAgICAgLy8gdGhlc2UgaGVscGVyIGZ1bmN0aW9ucyB3aWxsIG1ha2UgaW5zZXJ0aW5nIGFuZCByZWFkaW5nIGRhdGEgZWFzaWVyXHJcblxyXG4gICAgICAgICAgICAvLyBUaGlzIG9uZSBhZGRzIGEgbmV3IG9iamVjdCB0byB0aGUgZGF0YWJhc2UgY29sbGVjdGlvbiB1bmRlciB0aGlzIHBhdElkXHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIHVwZGF0ZVBhdChvYmplY3QpIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2cob2JqZWN0KVxyXG4gICAgICAgICAgICAgICAgUGF0LnVwZGF0ZSh7X2lkOiBwYXRJZH0sIHskc2V0OiAgb2JqZWN0fSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy9lLmcuIC0gZmlyc3QgbGV0J3MgdXNlIG91ciBcIlBhdGllbnRzXCIgbGlzdCBhbmQgZ2V0IHRoZSBmdWxsIG5hbWUgYW5kIGFsc28gdGhlIGFnZVxyXG4gICAgICAgICAgICB1cGRhdGVQYXQoe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSkuZm5hbWUgKyAnICcgKyBQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KS5sbmFtZSxcclxuICAgICAgICAgICAgICAgIGFnZTogZ2V0QWdlKFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pLmRvYilcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAvLyBMZXQncyB0aHJvdyBldmVyeXRoaW5nIGVsc2UgdGhhdCBpcyBpbiB0aGUgXCJQYXRpZW50c1wiIGNvbGxlY3Rpb24gYWJvdXQgb3VyIHBhdGllbnQgaW4gYSBnZW4gKGZvciBcImdlbmVyYWxcIikgb2JqZWN0XHJcbiAgICAgICAgICAgIHVwZGF0ZVBhdCh7XHJcbiAgICAgICAgICAgICAgICBnZW46IFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuLy8gU2ltdWxhdGUgYSBjYWxsIHRvIGEgdGFibGUgdGhhdCBob2xkcyBwYXRpZW50IE9ic2VydmF0aW9uc1xyXG4gICAgICAgICAgICAvLyBUaGUgbWV0ZW9yLmNhbGwgYWN0dWFsbHkganVzdCByZWFkcyBmcm9tIHRoZSBDU1YsIGJ1dCBpdCBkb2VzIHRoZW4gZmlsdGVyIGJ5IHRoZSBwYXRJZFxyXG4gICAgICAgICAgICAvLyBzb3J0IG9mIGxpa2UgaG93IGEgcmVhbCBTUUwgY2FsbCB3b3VsZCB3b3JrLlxyXG4gICAgICAgICAgICAvLyBXZSB3aWxsIHN0b3JlIHRoaXMgaW4gb3VyIFBhdCBjb2xsZWN0aW9uIHVuZGVyIHRoZSBncm91cCAnb2JzJ1xyXG5cclxuICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ2dldE9icycsIHBhdElkKTtcclxuXHJcbi8vIE5vdyBzaW11bGF0ZSBhIGNhbGwgZm9yIHBhdGllbnQgTWV0cmljc1xyXG4gICAgICAgICAgICAvLyB0aGlzIHdpbGwgZ28gaW4gYSBzZXBhcmF0ZSBjb2xsZWN0aW9uIGZvciBzZWFyY2hpbmcsIHNvIGp1c3QgaXMgYSBtZXRlb3IuY2FsbFxyXG5cclxuICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ2dldE1ldHJpY3MnLCBwYXRJZClcclxuXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgJ2NsZWFyUGF0JzogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgICAgIFBhdC5yZW1vdmUoe30pXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICB9KTtcclxuXHJcbiAgICAgICAgTWV0ZW9yLnB1Ymxpc2goJ3BhdCcsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHJldHVybiBQYXQuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdwYXQnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuZXhwb3J0IGNvbnN0IFBhdGllbnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3BhdGllbnRzJyk7XHJcblxyXG5cclxuLy8gUG9wdWxhdGUgb3VyIGxvY2FsIHBhdGllbnQgZGF0YWJhc2Ugd2l0aCBzb21lIHByZS1idWlsdCBwYXRpZW50IGRhdGEuXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcclxuXHJcbiAgICAvLyBPbmx5IGRvIHRoaXMgb24gc3RhcnR1cCBpZiB0aGUgZGIgaXMgZW1wdHlcclxuICAgIGlmIChQYXRpZW50cy5maW5kKCkuY291bnQoKSA9PT0gMCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmb3VuZCBubyBwYXRpZW50cy0gZ2V0dGluZyBkYXRhLi4uXCIpO1xyXG4gICAgICAgIE1ldGVvci5jYWxsKCdyZXNldFBhdGllbnRzJylcclxuXHJcbiAgICB9IGVsc2V7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2ZvdW5kIHBhdGllbnRzIGFscmVhZHkgaW4gZGF0YWJhc2UnKVxyXG4gICAgfVxyXG5cclxufSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICdjbGVhclBhdGllbnRzJzogZnVuY3Rpb24gKCl7XHJcbiAgICAgICAgICAgIFBhdGllbnRzLnJlbW92ZSh7fSlcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAncmVzZXRQYXRpZW50cyc6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncmVzZXR0aW5nIHBhdGllbnQgREInKTtcclxuICAgICAgICAgICAgUGF0aWVudHMucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIFRoZSBwYXRpZW50IGRhdGEgaXMgc3RvcmVkIGFzIGEgQ1NWIGZpbGUgaW4gb3VyIFwicHJpdmF0ZVwiIGZvbGRlclxyXG4gICAgICAgICAgICAvLyBUaGlzIGFsbG93cyB1cyB0byBxdWljayBhbmQgZGlydHkgcmVwbGljYXRlIHdoYXQgbWlnaHQgYmUgYSB2aWV3IG9uIEFjdWVyZVxyXG4gICAgICAgICAgICAvLyBJdCB3b3VsZCBwcm9iYWJseSBiZSBlYXNpZXIgaWYgdGhpcyB3b3VsZCBqdXN0IHB1bGwgZnJvbSBBY3VlcmUuLi5cclxuXHJcbiAgICAgICAgICAgIC8vRmlyc3QsIGltcG9ydCB0aGUgY3N2IGFzIGEgc3RyaW5nOiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xNzQ1Mzg0OC9pcy10aGVyZS1hLXdheS10by1pbXBvcnQtc3RyaW5ncy1mcm9tLWEtdGV4dC1maWxlLWluLWphdmFzY3JpcHQtbWV0ZW9yXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF0aWVudFN0cmluZyA9IEFzc2V0cy5nZXRUZXh0KCdwYXRpZW50cy5jc3YnKTtcclxuICAgICAgICAgICAgICAgIC8vIHBhdGllbnRTdHJpbmcgd2lsbCBjb250YWluIHRoZSBkYXRhIGFzIG9uZSBsb25nIENTViBzdHJpbmdcclxuICAgICAgICAgICAgICAgIC8vIFdlIG5lZWQgdG8gcGFyc2UgaXQgdG8gYSBKU09OIG9iamVjdC5cclxuICAgICAgICAgICAgICAgIC8vIHdpbGwgdXNlIHRoZSBQYXBhIHBhcnNlIHBhY2thZ2UgdG8gZG8gdGhpcy4uLlxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhdGllbnREYXRhID0gUGFwYS5wYXJzZShwYXRpZW50U3RyaW5nLCB7aGVhZGVyOiB0cnVlfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gV2Ugd2lsbCBzdG9yZSB0aGUgZGF0YSBpbiBvdXIgb3duIE1vbmdvIGNvbGxlY3Rpb24gdGhhdCB3ZSBkZWZpbmVkIGFib3ZlLSBQYXRpZW50c1xyXG4gICAgICAgICAgICAgICAgLy8gUHJlZmVyIHRvIHN0b3JlIGVhY2ggcGF0aWVudCBhcyB0aGVpciBvd24gXCJkb2N1bWVudFwiIHRvIG1ha2Ugc2VhcmNoZXMgYW5kIHN0dWZmIGVhc2llciwgc28gbG9vcCB0aHJvdWdoIHRoZSBDU1YgZGF0YSBhbmQgaW5zZXJ0IG9uZSBhdCBhIHRpbWVcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHBhdGllbnREYXRhLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZihwYXRpZW50RGF0YS5kYXRhW3hdLnBhdElkICE9PScnKXsgLy8gaWdub3JlcyBhbnkgYmxhbmsgcm93cyAoaS5lLiBsYXN0IHJvdyB0aGF0IGFsd2F5cyBjb21lcyBiYWNrKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXRpZW50cy5pbnNlcnQocGF0aWVudERhdGEuZGF0YVt4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IDFcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhjb3VudCArICcgcGF0aWVudHMgZW50ZXJlZCcpXHJcblxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNvbWV0aGluZyB3ZW50IHdyb25nIHdpdGggZ2V0dGluZyB0aGUgcGF0aWVudCBsaXN0XCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICAgICBNZXRlb3IucHVibGlzaCgncGF0aWVudHMnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICByZXR1cm4gUGF0aWVudHMuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdwYXRpZW50cycpXHJcbn0iLCIvLyBnbG9iYWwgZnVuY3Rpb25zIGdvIGhlcmVcclxuXHJcbmdldEFnZSA9IGZ1bmN0aW9uKGRvYlN0cmluZyl7XHJcbiAgICBsZXQgZG9iID0gbmV3IERhdGUgKGRvYlN0cmluZylcclxuICAgIGxldCBhZ2VEaWZNcyA9IERhdGUubm93KCkgLSBkb2IuZ2V0VGltZSgpXHJcbiAgICBsZXQgYWdlRGF0ZSA9IG5ldyBEYXRlKGFnZURpZk1zKVxyXG4gICAgcmV0dXJuIE1hdGguYWJzKGFnZURhdGUuZ2V0VVRDRnVsbFllYXIoKS0gMTk3MClcclxufTtcclxuXHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgJy4uL2ltcG9ydHMvZ2xvYmFsJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxyXG59KTtcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdyZXNldEFsbCc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ0Z1bGwgcmVzZXQgY2FsbGVkLi4uJyk7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0UGF0aWVudHMnKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgnY2xlYXJFcHNzJyk7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ2NsZWFyUGF0Jyk7XHJcbiAgICB9XHJcbn0pOyJdfQ==
