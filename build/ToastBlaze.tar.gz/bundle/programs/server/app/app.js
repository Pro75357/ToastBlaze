var require = meteorInstall({"collections":{"epss.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/epss.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Epss: () => Epss
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let HTTP;
module.watch(require("meteor/http"), {
    HTTP(v) {
        HTTP = v;
    }

}, 1);
let Pat;
module.watch(require("./pat"), {
    Pat(v) {
        Pat = v;
    }

}, 2);
let Observations;
module.watch(require("./observations"), {
    Observations(v) {
        Observations = v;
    }

}, 3);
const Epss = new Mongo.Collection('epss');

/*
This is where we will fetch and store the AHRQ EPSS recommendations
use of this requires an ePSS key, and there is some logic to fetch and validate the key here
The key should be placed in the Private folder, in a file called 'ePSS_Key.json'
THe file should be a simple json object:

{
  "Key":"PUT_KEY_HERE"
}

Please review the AHRQ Copyright and Disclaimer notice before using the API: https://www.uspreventiveservicestaskforce.org/Page/Name/copyright-notice.
Instructions for use and access information can be found at:
•	Instruction for Use:  http://epss.ahrq.gov/PDA/docs/ePSS_Data_API_WI_wLink.pdf
•	URL:  http://epssdata.ahrq.gov/
 */if (Meteor.isServer) {
    Meteor.methods({
        'getEpss': function () {
            // only update if empty- updatePat should empty this collection...
            if (Epss.find().count() > 0) {
                return;
            } // First, we need to know the epss api url


            const url = 'http://epssdata.ahrq.gov/';
            let ePSS_Key = ''; // Next, get the ePSS key from the text file in the Private folder.
            // this file will not sync with git if it is in the .gitignore

            try {
                ePSS_Key = JSON.parse(Assets.getText('ePSS_Key.json')); // If the key is blank or not updated, we cannot continue..

                if (ePSS_Key.key === 'PUT_KEY_HERE') {
                    console.log('ePSS Key not found or invalid- please input your ePSS key into ePSS_Key.json file in private folder');
                    return;
                }
            } catch (e) {
                console.log('Fetching ePSS key failed. Please make sure ePSS_Key.json exists in the private folder.');
                console.log(e.message);
            } // get info from Pat, Observations collections


            let sex = Pat.findOne().gen.sex;
            let age = getAge(Pat.findOne().gen.dob);
            let tobacco = '';

            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Smoking Status'
            })) {
                tobacco = Observations.findOne({
                    category: 'socialHistory',
                    name: 'Smoking Status'
                }).value;
            }

            let sexuallyActive = '';
            if (Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            })) sexuallyActive = Observations.findOne({
                category: 'socialHistory',
                name: 'Sexually Active'
            }).value;
            let pregnant = null;

            if (sex === 'F') {
                pregnant = 'N'; // placeholder for real logic
            } //build the params object


            let params = {
                age: age,
                sex: sex,
                pregnant: pregnant,
                // 'N' -- (Y,N) - requires Female sex to be present
                tobacco: tobacco,
                sexuallyActive: sexuallyActive //grade: ['A', 'B']

            }; // lastly, insert key into params

            params.key = ePSS_Key.key; // Try to fetch the ePSS recommendations based on the params.

            try {
                // to speed this up, and to be able to grab multiple grades, we will do this twice
                // the first time, we will use grade: 'A',
                // the second time, we will use grade: 'B
                // to simplify code, we will define the http call as a function with a grade argument
                const getEpss = function (grade) {
                    // plug grade into the params
                    params.grade = grade;
                    HTTP.call('get', url, {
                        headers: 'Accept: application/json',
                        // params go here
                        params // async callback

                    }, function (err, result) {
                        if (err) {
                            throw err;
                        } else {
                            //results end up here: we only want to store the specific recommendations array objects
                            // so, we will just insert these into our Epss collection individually.
                            // this will make them easy to search.
                            let epssCount = 0;
                            let recs = result.data.specificRecommendations;

                            for (let x in recs) {
                                Epss.insert(recs[x]);
                                epssCount += 1;
                            }

                            console.log(epssCount + ' Grade ' + grade + ' ePSS recs inserted');
                            return true;
                        }
                    });
                };

                getEpss('A');
                getEpss('B');
            } catch (e) {
                console.log(e);
            }
        },
        'clearEpss': function () {
            Epss.remove({});
        }
    }); // Publication function from the server- this let's us define what the client-side db gets

    Meteor.publish('epss', function () {
        // we will return the entire collection.
        return Epss.find();
    });
} // as the client, subscribes to the above publication


if (Meteor.isClient) {
    Meteor.subscribe('epss');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metrics.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/metrics.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Metrics: () => Metrics
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Metrics = new Mongo.Collection('metrics');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Metrics.remove({});
    });
    Meteor.publish('metrics', function () {
        return Metrics.find();
    });
    Meteor.methods({
        'getMetrics': function (patId) {
            Metrics.remove({});

            try {
                const metricsString = Assets.getText('metrics.csv');
                const metrics = Papa.parse(metricsString, {
                    header: true
                });
                let count = 0;

                for (let x in metrics.data) {
                    if (metrics.data[x].patId === patId) {
                        Metrics.insert(metrics.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' metrics entered');
            } catch (e) {
                console.log("something went wrong with parsing the metrics data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('metrics');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Observations: () => Observations
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Observations = new Mongo.Collection('obs');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear any data at startup as there should not be any patient in context.
        Observations.remove({});
    });
    Meteor.publish('obs', function () {
        return Observations.find();
    });
    Meteor.methods({
        'getObs': function (patId) {
            Observations.remove({});

            try {
                const String = Assets.getText('observations.csv');
                const parse = Papa.parse(String, {
                    header: true
                });
                let count = 0;

                for (let x in parse.data) {
                    if (parse.data[x].patId === patId) {
                        Observations.insert(parse.data[x]);
                        count += 1;
                    }
                } // Observations are in there, but the date field is just a string.
                // This will transform the string in the "date" field into a javascript date.


                let all = Observations.find().fetch();

                for (let x in all) {
                    let _id = all[x]._id;
                    let date = new Date(all[x].date); //console.log(date)

                    Observations.upsert({
                        _id: _id
                    }, {
                        $set: {
                            date: date
                        }
                    });
                }

                console.log(count + ' observations entered');
            } catch (e) {
                console.log("something went wrong with parsing the observations data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('obs');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pat.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/pat.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
            Pat: () => Pat
});
let Mongo;
module.watch(require("meteor/mongo"), {
            Mongo(v) {
                        Mongo = v;
            }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
            Meteor(v) {
                        Meteor = v;
            }

}, 1);
let Patients;
module.watch(require("./patients"), {
            Patients(v) {
                        Patients = v;
            }

}, 2);
let Epss;
module.watch(require("./epss"), {
            Epss(v) {
                        Epss = v;
            }

}, 3);
const Pat = new Mongo.Collection('pat');

// Once our patient is selected we need to populate our collections. The main functions for this are handled here
// With references to the other collections when needed.
if (Meteor.isServer) {
            Meteor.startup(() => {
                        // clear ant Pat data at startup as there should not be any patient in context.
                        Pat.remove({});
            });
            Meteor.methods({
                        'updatePat': function (patId) {
                                    console.log("updatePat was run"); // Ok, First, let's fetch the other data about the patient
                                    // We'll store this single patient's data in a new Collection, pat
                                    // If any old data is in Pat or Epss need to clear it

                                    Pat.remove({});
                                    Epss.remove({}); // Now, let's start fresh with our currently selected patient

                                    Pat.insert({
                                                _id: patId
                                    }); // these helper functions will make inserting and reading data easier
                                    // This one adds a new object to the database collection under this patId

                                    function updatePat(object) {
                                                //console.log(object)
                                                Pat.update({
                                                            _id: patId
                                                }, {
                                                            $set: object
                                                });
                                    } //e.g. - first let's use our "Patients" list and get the full name and also the age


                                    updatePat({
                                                name: Patients.findOne({
                                                            patId: patId
                                                }).fname + ' ' + Patients.findOne({
                                                            patId: patId
                                                }).lname,
                                                age: getAge(Patients.findOne({
                                                            patId: patId
                                                }).dob)
                                    }); // Let's throw everything else that is in the "Patients" collection about our patient in a gen (for "general") object

                                    updatePat({
                                                gen: Patients.findOne({
                                                            patId: patId
                                                })
                                    }); // Simulate a call to a table that holds patient Observations
                                    // The meteor.call actually just reads from the CSV, but it does then filter by the patId
                                    // sort of like how a real SQL call would work.
                                    // We will store this in our Pat collection under the group 'obs'

                                    Meteor.call('getObs', patId); // Now simulate a call for patient Metrics
                                    // this will go in a separate collection for searching, so just is a meteor.call

                                    Meteor.call('getMetrics', patId);
                        },
                        'clearPat': function () {
                                    Pat.remove({});
                        }
            });
            Meteor.publish('pat', function () {
                        return Pat.find();
            });
}

if (Meteor.isClient) {
            Meteor.subscribe('pat');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patients.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/patients.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Patients: () => Patients
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Patients = new Mongo.Collection('patients');

// Populate our local patient database with some pre-built patient data.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // code to run on server at startup
        // Only do this on startup if the db is empty
        if (Patients.find().count() === 0) {
            console.log("found no patients- getting data...");
            Meteor.call('resetPatients');
        } else {
            console.log('found patients already in database');
        }
    });
    Meteor.methods({
        'clearPatients': function () {
            Patients.remove({});
        },
        'resetPatients': function () {
            console.log('resetting patient DB');
            Patients.remove({}); // The patient data is stored as a CSV file in our "private" folder
            // This allows us to quick and dirty replicate what might be a view on Acuere
            // It would probably be easier if this would just pull from Acuere...
            //First, import the csv as a string: https://stackoverflow.com/questions/17453848/is-there-a-way-to-import-strings-from-a-text-file-in-javascript-meteor

            try {
                const patientString = Assets.getText('patients.csv'); // patientString will contain the data as one long CSV string
                // We need to parse it to a JSON object.
                // will use the Papa parse package to do this...

                const patientData = Papa.parse(patientString, {
                    header: true
                }); // We will store the data in our own Mongo collection that we defined above- Patients
                // Prefer to store each patient as their own "document" to make searches and stuff easier, so loop through the CSV data and insert one at a time

                let count = 0;

                for (let x in patientData.data) {
                    if (patientData.data[x].patId !== '') {
                        // ignores any blank rows (i.e. last row that always comes back)
                        Patients.insert(patientData.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' patients entered');
            } catch (e) {
                console.log("something went wrong with getting the patient list");
                console.log(e.message);
            }
        }
    });
    Meteor.publish('patients', function () {
        return Patients.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('patients');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/global.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// global functions go here
// this just calculates the age in years based on birthdate
getAge = function (dobString) {
    let dob = new Date(dobString);
    let ageDifMs = Date.now() - dob.getTime();
    let ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
module.watch(require("../imports/global"));
Meteor.startup(() => {// code to run on server at startup
});
Meteor.methods({
    'resetAll': function () {
        console.log('Full reset called...');
        Meteor.call('resetPatients');
        Meteor.call('clearEpss');
        Meteor.call('clearPat');
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/epss.js");
require("./collections/metrics.js");
require("./collections/observations.js");
require("./collections/pat.js");
require("./collections/patients.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvZXBzcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvbWV0cmljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvb2JzZXJ2YXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9wYXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3BhdGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2dsb2JhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRXBzcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkhUVFAiLCJQYXQiLCJPYnNlcnZhdGlvbnMiLCJDb2xsZWN0aW9uIiwiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJtZXRob2RzIiwiZmluZCIsImNvdW50IiwidXJsIiwiZVBTU19LZXkiLCJKU09OIiwicGFyc2UiLCJBc3NldHMiLCJnZXRUZXh0Iiwia2V5IiwiY29uc29sZSIsImxvZyIsImUiLCJtZXNzYWdlIiwic2V4IiwiZmluZE9uZSIsImdlbiIsImFnZSIsImdldEFnZSIsImRvYiIsInRvYmFjY28iLCJjYXRlZ29yeSIsIm5hbWUiLCJ2YWx1ZSIsInNleHVhbGx5QWN0aXZlIiwicHJlZ25hbnQiLCJwYXJhbXMiLCJnZXRFcHNzIiwiZ3JhZGUiLCJjYWxsIiwiaGVhZGVycyIsImVyciIsInJlc3VsdCIsImVwc3NDb3VudCIsInJlY3MiLCJkYXRhIiwic3BlY2lmaWNSZWNvbW1lbmRhdGlvbnMiLCJ4IiwiaW5zZXJ0IiwicmVtb3ZlIiwicHVibGlzaCIsImlzQ2xpZW50Iiwic3Vic2NyaWJlIiwiTWV0cmljcyIsInN0YXJ0dXAiLCJwYXRJZCIsIm1ldHJpY3NTdHJpbmciLCJtZXRyaWNzIiwiUGFwYSIsImhlYWRlciIsIlN0cmluZyIsImFsbCIsImZldGNoIiwiX2lkIiwiZGF0ZSIsIkRhdGUiLCJ1cHNlcnQiLCIkc2V0IiwiUGF0aWVudHMiLCJ1cGRhdGVQYXQiLCJvYmplY3QiLCJ1cGRhdGUiLCJmbmFtZSIsImxuYW1lIiwicGF0aWVudFN0cmluZyIsInBhdGllbnREYXRhIiwiZG9iU3RyaW5nIiwiYWdlRGlmTXMiLCJub3ciLCJnZXRUaW1lIiwiYWdlRGF0ZSIsIk1hdGgiLCJhYnMiLCJnZXRVVENGdWxsWWVhciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFVBQUssTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUlDLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixVQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0JBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsSUFBSjtBQUFTUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNFLFNBQUtELENBQUwsRUFBTztBQUFDQyxlQUFLRCxDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQXlELElBQUlFLEdBQUo7QUFBUVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDRyxRQUFJRixDQUFKLEVBQU07QUFBQ0UsY0FBSUYsQ0FBSjtBQUFNOztBQUFkLENBQTlCLEVBQThDLENBQTlDO0FBQWlELElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNJLGlCQUFhSCxDQUFiLEVBQWU7QUFBQ0csdUJBQWFILENBQWI7QUFBZTs7QUFBaEMsQ0FBdkMsRUFBeUUsQ0FBekU7QUFDMU8sTUFBTUosT0FBTyxJQUFJQyxNQUFNTyxVQUFWLENBQXFCLE1BQXJCLENBQWI7O0FBT1A7Ozs7Ozs7Ozs7Ozs7O0dBZ0JBLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU9FLE9BQVAsQ0FBZTtBQUVYLG1CQUFXLFlBQVk7QUFFbkI7QUFDQSxnQkFBSVgsS0FBS1ksSUFBTCxHQUFZQyxLQUFaLEtBQXNCLENBQTFCLEVBQThCO0FBQzFCO0FBQ0gsYUFMa0IsQ0FPbkI7OztBQUNBLGtCQUFNQyxNQUFNLDJCQUFaO0FBQ0EsZ0JBQUlDLFdBQVcsRUFBZixDQVRtQixDQVVuQjtBQUNBOztBQUVBLGdCQUFJO0FBQ0FBLDJCQUFXQyxLQUFLQyxLQUFMLENBQVdDLE9BQU9DLE9BQVAsQ0FBZSxlQUFmLENBQVgsQ0FBWCxDQURBLENBRUE7O0FBRUEsb0JBQUlKLFNBQVNLLEdBQVQsS0FBaUIsY0FBckIsRUFBcUM7QUFDakNDLDRCQUFRQyxHQUFSLENBQVkscUdBQVo7QUFDQTtBQUNIO0FBQ0osYUFSRCxDQVFFLE9BQU1DLENBQU4sRUFBUTtBQUNORix3QkFBUUMsR0FBUixDQUFZLHdGQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDSCxhQXhCa0IsQ0EyQm5COzs7QUFFQSxnQkFBSUMsTUFBTW5CLElBQUlvQixPQUFKLEdBQWNDLEdBQWQsQ0FBa0JGLEdBQTVCO0FBQ0EsZ0JBQUlHLE1BQU1DLE9BQU92QixJQUFJb0IsT0FBSixHQUFjQyxHQUFkLENBQWtCRyxHQUF6QixDQUFWO0FBQ0EsZ0JBQUlDLFVBQVUsRUFBZDs7QUFDQSxnQkFBSXhCLGFBQWFtQixPQUFiLENBQXFCO0FBQUNNLDBCQUFVLGVBQVg7QUFBNEJDLHNCQUFNO0FBQWxDLGFBQXJCLENBQUosRUFBK0U7QUFDM0VGLDBCQUFVeEIsYUFBYW1CLE9BQWIsQ0FBcUI7QUFBQ00sOEJBQVUsZUFBWDtBQUE0QkMsMEJBQU07QUFBbEMsaUJBQXJCLEVBQTBFQyxLQUFwRjtBQUNIOztBQUVELGdCQUFJQyxpQkFBaUIsRUFBckI7QUFDQSxnQkFBSTVCLGFBQWFtQixPQUFiLENBQXFCO0FBQUNNLDBCQUFVLGVBQVg7QUFBNEJDLHNCQUFNO0FBQWxDLGFBQXJCLENBQUosRUFDSUUsaUJBQWlCNUIsYUFBYW1CLE9BQWIsQ0FBcUI7QUFBQ00sMEJBQVUsZUFBWDtBQUE0QkMsc0JBQU07QUFBbEMsYUFBckIsRUFBMkVDLEtBQTVGO0FBQ0osZ0JBQUlFLFdBQVcsSUFBZjs7QUFDQSxnQkFBR1gsUUFBTyxHQUFWLEVBQWM7QUFDVlcsMkJBQVcsR0FBWCxDQURVLENBQ0s7QUFDbEIsYUExQ2tCLENBNENuQjs7O0FBQ0EsZ0JBQUlDLFNBQVM7QUFDVFQscUJBQUtBLEdBREk7QUFFVEgscUJBQUtBLEdBRkk7QUFHVFcsMEJBQVVBLFFBSEQ7QUFHVztBQUNwQkwseUJBQVNBLE9BSkE7QUFLVEksZ0NBQWdCQSxjQUxQLENBTVQ7O0FBTlMsYUFBYixDQTdDbUIsQ0FzRG5COztBQUNBRSxtQkFBT2pCLEdBQVAsR0FBYUwsU0FBU0ssR0FBdEIsQ0F2RG1CLENBeURuQjs7QUFDQSxnQkFBSTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsc0JBQU1rQixVQUFVLFVBQVNDLEtBQVQsRUFBZTtBQUMzQjtBQUNBRiwyQkFBT0UsS0FBUCxHQUFlQSxLQUFmO0FBQ0FsQyx5QkFBS21DLElBQUwsQ0FBVSxLQUFWLEVBQWlCMUIsR0FBakIsRUFBcUI7QUFDYjJCLGlDQUFTLDBCQURJO0FBRWpCO0FBQ0lKLDhCQUhhLENBSWpCOztBQUppQixxQkFBckIsRUFLTyxVQUFTSyxHQUFULEVBQWNDLE1BQWQsRUFBcUI7QUFDeEIsNEJBQUdELEdBQUgsRUFBTztBQUNILGtDQUFNQSxHQUFOO0FBQ0gseUJBRkQsTUFFTztBQUNIO0FBQ0E7QUFDQTtBQUNBLGdDQUFJRSxZQUFZLENBQWhCO0FBQ0EsZ0NBQUlDLE9BQU9GLE9BQU9HLElBQVAsQ0FBWUMsdUJBQXZCOztBQUNBLGlDQUFLLElBQUlDLENBQVQsSUFBY0gsSUFBZCxFQUFvQjtBQUNoQjdDLHFDQUFLaUQsTUFBTCxDQUFZSixLQUFLRyxDQUFMLENBQVo7QUFDQUosNkNBQVksQ0FBWjtBQUNIOztBQUNEdkIsb0NBQVFDLEdBQVIsQ0FBWXNCLFlBQVksU0FBWixHQUFzQkwsS0FBdEIsR0FBNEIscUJBQXhDO0FBQ0EsbUNBQU8sSUFBUDtBQUNIO0FBRUEscUJBdEJMO0FBd0JILGlCQTNCRDs7QUE2QkFELHdCQUFRLEdBQVI7QUFDQUEsd0JBQVEsR0FBUjtBQUdILGFBekNELENBeUNFLE9BQU9mLENBQVAsRUFBVTtBQUNSRix3QkFBUUMsR0FBUixDQUFZQyxDQUFaO0FBQ0g7QUFDSixTQXhHVTtBQTBHWCxxQkFBYSxZQUFXO0FBQ3BCdkIsaUJBQUtrRCxNQUFMLENBQVksRUFBWjtBQUNIO0FBNUdVLEtBQWYsRUFGaUIsQ0FrSGI7O0FBQ0F6QyxXQUFPMEMsT0FBUCxDQUFlLE1BQWYsRUFBdUIsWUFBVTtBQUM3QjtBQUNBLGVBQU9uRCxLQUFLWSxJQUFMLEVBQVA7QUFDSCxLQUhEO0FBSVAsQyxDQUNPOzs7QUFDUixJQUFJSCxPQUFPMkMsUUFBWCxFQUFvQjtBQUNoQjNDLFdBQU80QyxTQUFQLENBQWlCLE1BQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNuSkR2RCxPQUFPQyxNQUFQLENBQWM7QUFBQ3VELGFBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlyRCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHL0csTUFBTWtELFVBQVUsSUFBSXJELE1BQU1PLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7O0FBRVA7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPOEMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQUQsZ0JBQVFKLE1BQVIsQ0FBZSxFQUFmO0FBRUgsS0FKRDtBQU9BekMsV0FBTzBDLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVU7QUFDaEMsZUFBT0csUUFBUTFDLElBQVIsRUFBUDtBQUNILEtBRkQ7QUFJQUgsV0FBT0UsT0FBUCxDQUFlO0FBQ1gsc0JBQWMsVUFBUzZDLEtBQVQsRUFBZTtBQUN6QkYsb0JBQVFKLE1BQVIsQ0FBZSxFQUFmOztBQUNBLGdCQUFJO0FBQ0Esc0JBQU1PLGdCQUFnQnZDLE9BQU9DLE9BQVAsQ0FBZSxhQUFmLENBQXRCO0FBRUEsc0JBQU11QyxVQUFVQyxLQUFLMUMsS0FBTCxDQUFXd0MsYUFBWCxFQUEwQjtBQUFDRyw0QkFBUTtBQUFULGlCQUExQixDQUFoQjtBQUNBLG9CQUFJL0MsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUltQyxDQUFULElBQWNVLFFBQVFaLElBQXRCLEVBQTRCO0FBQ3hCLHdCQUFJWSxRQUFRWixJQUFSLENBQWFFLENBQWIsRUFBZ0JRLEtBQWhCLEtBQTBCQSxLQUE5QixFQUFxQztBQUNqQ0YsZ0NBQVFMLE1BQVIsQ0FBZVMsUUFBUVosSUFBUixDQUFhRSxDQUFiLENBQWY7QUFDQW5DLGlDQUFTLENBQVQ7QUFDSDtBQUNKOztBQUNEUSx3QkFBUUMsR0FBUixDQUFZVCxRQUFRLGtCQUFwQjtBQUNILGFBWkQsQ0FZRSxPQUFPVSxDQUFQLEVBQVU7QUFDUkYsd0JBQVFDLEdBQVIsQ0FBWSxvREFBWjtBQUNBRCx3QkFBUUMsR0FBUixDQUFZQyxFQUFFQyxPQUFkO0FBQ0EsdUJBQU8sS0FBUDtBQUNIOztBQUNELG1CQUFPLElBQVA7QUFDSDtBQXJCVSxLQUFmO0FBdUJIOztBQUVELElBQUlmLE9BQU8yQyxRQUFYLEVBQW9CO0FBQ2hCM0MsV0FBTzRDLFNBQVAsQ0FBaUIsU0FBakI7QUFDSCxDOzs7Ozs7Ozs7OztBQ2hERHZELE9BQU9DLE1BQVAsQ0FBYztBQUFDUSxrQkFBYSxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlOLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixVQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0JBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUssTUFBSjtBQUFXWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNNLFdBQU9MLENBQVAsRUFBUztBQUFDSyxpQkFBT0wsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUd6SCxNQUFNRyxlQUFlLElBQUlOLE1BQU1PLFVBQVYsQ0FBcUIsS0FBckIsQ0FBckI7O0FBRVA7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPOEMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQWhELHFCQUFhMkMsTUFBYixDQUFvQixFQUFwQjtBQUVILEtBSkQ7QUFNQXpDLFdBQU8wQyxPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLGVBQU81QyxhQUFhSyxJQUFiLEVBQVA7QUFDSCxLQUZEO0FBSUFILFdBQU9FLE9BQVAsQ0FBZTtBQUNYLGtCQUFVLFVBQVM2QyxLQUFULEVBQWU7QUFDckJqRCx5QkFBYTJDLE1BQWIsQ0FBb0IsRUFBcEI7O0FBRUEsZ0JBQUk7QUFDQSxzQkFBTVcsU0FBUzNDLE9BQU9DLE9BQVAsQ0FBZSxrQkFBZixDQUFmO0FBRUEsc0JBQU1GLFFBQVEwQyxLQUFLMUMsS0FBTCxDQUFXNEMsTUFBWCxFQUFtQjtBQUFDRCw0QkFBUTtBQUFULGlCQUFuQixDQUFkO0FBQ0Esb0JBQUkvQyxRQUFRLENBQVo7O0FBQ0EscUJBQUssSUFBSW1DLENBQVQsSUFBYy9CLE1BQU02QixJQUFwQixFQUEwQjtBQUN0Qix3QkFBSTdCLE1BQU02QixJQUFOLENBQVdFLENBQVgsRUFBY1EsS0FBZCxLQUF3QkEsS0FBNUIsRUFBbUM7QUFDL0JqRCxxQ0FBYTBDLE1BQWIsQ0FBb0JoQyxNQUFNNkIsSUFBTixDQUFXRSxDQUFYLENBQXBCO0FBQ0FuQyxpQ0FBUyxDQUFUO0FBQ0g7QUFDSixpQkFWRCxDQVdBO0FBQ0E7OztBQUNBLG9CQUFJaUQsTUFBTXZELGFBQWFLLElBQWIsR0FBb0JtRCxLQUFwQixFQUFWOztBQUNBLHFCQUFLLElBQUlmLENBQVQsSUFBY2MsR0FBZCxFQUFrQjtBQUNkLHdCQUFJRSxNQUFNRixJQUFJZCxDQUFKLEVBQU9nQixHQUFqQjtBQUNBLHdCQUFJQyxPQUFPLElBQUlDLElBQUosQ0FBU0osSUFBSWQsQ0FBSixFQUFPaUIsSUFBaEIsQ0FBWCxDQUZjLENBR2Q7O0FBQ0ExRCxpQ0FBYTRELE1BQWIsQ0FBb0I7QUFBQ0gsNkJBQUtBO0FBQU4scUJBQXBCLEVBQStCO0FBQUNJLDhCQUFNO0FBQUNILGtDQUFNQTtBQUFQO0FBQVAscUJBQS9CO0FBQ0g7O0FBRUQ1Qyx3QkFBUUMsR0FBUixDQUFZVCxRQUFRLHVCQUFwQjtBQUNILGFBdEJELENBc0JFLE9BQU9VLENBQVAsRUFBVTtBQUNSRix3QkFBUUMsR0FBUixDQUFZLHlEQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlDLEVBQUVDLE9BQWQ7QUFDQSx1QkFBTyxLQUFQO0FBQ0g7O0FBQ0QsbUJBQU8sSUFBUDtBQUNIO0FBaENVLEtBQWY7QUFrQ0g7O0FBRUQsSUFBSWYsT0FBTzJDLFFBQVgsRUFBb0I7QUFDaEIzQyxXQUFPNEMsU0FBUCxDQUFpQixLQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDMUREdkQsT0FBT0MsTUFBUCxDQUFjO0FBQUNPLGlCQUFJLE1BQUlBO0FBQVQsQ0FBZDtBQUE2QixJQUFJTCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0Ysa0JBQU1HLENBQU4sRUFBUTtBQUFDSCxnQ0FBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJSyxNQUFKO0FBQVdYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sbUJBQU9MLENBQVAsRUFBUztBQUFDSyxpQ0FBT0wsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJaUUsUUFBSjtBQUFhdkUsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDa0UscUJBQVNqRSxDQUFULEVBQVc7QUFBQ2lFLG1DQUFTakUsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJSixJQUFKO0FBQVNGLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0gsaUJBQUtJLENBQUwsRUFBTztBQUFDSiwrQkFBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUEvQixFQUFpRCxDQUFqRDtBQUs1UCxNQUFNRSxNQUFNLElBQUlMLE1BQU1PLFVBQVYsQ0FBcUIsS0FBckIsQ0FBWjs7QUFFUDtBQUNBO0FBR0EsSUFBSUMsT0FBT0MsUUFBWCxFQUFxQjtBQUVqQkQsbUJBQU84QyxPQUFQLENBQWUsTUFBTTtBQUNqQjtBQUNBakQsNEJBQUk0QyxNQUFKLENBQVcsRUFBWDtBQUVILGFBSkQ7QUFNQXpDLG1CQUFPRSxPQUFQLENBQWU7QUFDWCxxQ0FBYSxVQUFTNkMsS0FBVCxFQUFnQjtBQUN6Qm5DLDRDQUFRQyxHQUFSLENBQVksbUJBQVosRUFEeUIsQ0FJekI7QUFDQTtBQUVBOztBQUNBaEIsd0NBQUk0QyxNQUFKLENBQVcsRUFBWDtBQUNBbEQseUNBQUtrRCxNQUFMLENBQVksRUFBWixFQVR5QixDQVd6Qjs7QUFDQTVDLHdDQUFJMkMsTUFBSixDQUFXO0FBQUNlLHFEQUFLUjtBQUFOLHFDQUFYLEVBWnlCLENBZXpCO0FBRUE7O0FBQ0EsNkNBQVNjLFNBQVQsQ0FBbUJDLE1BQW5CLEVBQTJCO0FBQ3ZCO0FBQ0FqRSxvREFBSWtFLE1BQUosQ0FBVztBQUFDUixpRUFBS1I7QUFBTixpREFBWCxFQUF5QjtBQUFDWSxrRUFBT0c7QUFBUixpREFBekI7QUFDSCxxQ0FyQndCLENBdUJ6Qjs7O0FBQ0FELDhDQUFVO0FBQ05yQyxzREFBTW9DLFNBQVMzQyxPQUFULENBQWlCO0FBQUM4QixtRUFBT0E7QUFBUixpREFBakIsRUFBaUNpQixLQUFqQyxHQUF5QyxHQUF6QyxHQUErQ0osU0FBUzNDLE9BQVQsQ0FBaUI7QUFBQzhCLG1FQUFPQTtBQUFSLGlEQUFqQixFQUFpQ2tCLEtBRGhGO0FBRU45QyxxREFBS0MsT0FBT3dDLFNBQVMzQyxPQUFULENBQWlCO0FBQUM4QixtRUFBT0E7QUFBUixpREFBakIsRUFBaUMxQixHQUF4QztBQUZDLHFDQUFWLEVBeEJ5QixDQTZCekI7O0FBQ0F3Qyw4Q0FBVTtBQUNOM0MscURBQUswQyxTQUFTM0MsT0FBVCxDQUFpQjtBQUFDOEIsbUVBQU9BO0FBQVIsaURBQWpCO0FBREMscUNBQVYsRUE5QnlCLENBa0NyQztBQUNZO0FBQ0E7QUFDQTs7QUFFQS9DLDJDQUFPK0IsSUFBUCxDQUFZLFFBQVosRUFBc0JnQixLQUF0QixFQXZDeUIsQ0F5Q3JDO0FBQ1k7O0FBRUEvQywyQ0FBTytCLElBQVAsQ0FBWSxZQUFaLEVBQTBCZ0IsS0FBMUI7QUFFSCx5QkEvQ1U7QUFpRFgsb0NBQVksWUFBVztBQUNuQmxELHdDQUFJNEMsTUFBSixDQUFXLEVBQVg7QUFDSDtBQW5EVSxhQUFmO0FBdURJekMsbUJBQU8wQyxPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLCtCQUFPN0MsSUFBSU0sSUFBSixFQUFQO0FBQ0gsYUFGRDtBQUdQOztBQUVELElBQUlILE9BQU8yQyxRQUFYLEVBQW9CO0FBQ2hCM0MsbUJBQU80QyxTQUFQLENBQWlCLEtBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNqRkR2RCxPQUFPQyxNQUFQLENBQWM7QUFBQ3NFLGNBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlwRSxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlLLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFakgsTUFBTWlFLFdBQVcsSUFBSXBFLE1BQU1PLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBR1A7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRXJCRCxXQUFPOEMsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFFQTtBQUNBLFlBQUljLFNBQVN6RCxJQUFULEdBQWdCQyxLQUFoQixPQUE0QixDQUFoQyxFQUFrQztBQUM5QlEsb0JBQVFDLEdBQVIsQ0FBWSxvQ0FBWjtBQUNBYixtQkFBTytCLElBQVAsQ0FBWSxlQUFaO0FBRUgsU0FKRCxNQUlNO0FBQ0ZuQixvQkFBUUMsR0FBUixDQUFZLG9DQUFaO0FBQ0g7QUFFSixLQVpEO0FBY0liLFdBQU9FLE9BQVAsQ0FBZTtBQUNYLHlCQUFpQixZQUFXO0FBQ3hCMEQscUJBQVNuQixNQUFULENBQWdCLEVBQWhCO0FBQ0gsU0FIVTtBQUtYLHlCQUFpQixZQUFXO0FBQ3hCN0Isb0JBQVFDLEdBQVIsQ0FBWSxzQkFBWjtBQUNBK0MscUJBQVNuQixNQUFULENBQWdCLEVBQWhCLEVBRndCLENBSXhCO0FBQ0E7QUFDQTtBQUVBOztBQUVBLGdCQUFJO0FBQ0Esc0JBQU15QixnQkFBZ0J6RCxPQUFPQyxPQUFQLENBQWUsY0FBZixDQUF0QixDQURBLENBRUE7QUFDQTtBQUNBOztBQUVBLHNCQUFNeUQsY0FBY2pCLEtBQUsxQyxLQUFMLENBQVcwRCxhQUFYLEVBQTBCO0FBQUNmLDRCQUFRO0FBQVQsaUJBQTFCLENBQXBCLENBTkEsQ0FRQTtBQUNBOztBQUNBLG9CQUFJL0MsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUltQyxDQUFULElBQWM0QixZQUFZOUIsSUFBMUIsRUFBZ0M7QUFDNUIsd0JBQUc4QixZQUFZOUIsSUFBWixDQUFpQkUsQ0FBakIsRUFBb0JRLEtBQXBCLEtBQTZCLEVBQWhDLEVBQW1DO0FBQUU7QUFDakNhLGlDQUFTcEIsTUFBVCxDQUFnQjJCLFlBQVk5QixJQUFaLENBQWlCRSxDQUFqQixDQUFoQjtBQUNBbkMsaUNBQVMsQ0FBVDtBQUNIO0FBQ0o7O0FBQ0RRLHdCQUFRQyxHQUFSLENBQVlULFFBQVEsbUJBQXBCO0FBRUgsYUFuQkQsQ0FtQkUsT0FBT1UsQ0FBUCxFQUFVO0FBQ1JGLHdCQUFRQyxHQUFSLENBQVksb0RBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUMsRUFBRUMsT0FBZDtBQUNIO0FBQ0o7QUF0Q1UsS0FBZjtBQTBDSWYsV0FBTzBDLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFlBQVU7QUFDakMsZUFBT2tCLFNBQVN6RCxJQUFULEVBQVA7QUFDSCxLQUZEO0FBR1A7O0FBRUQsSUFBSUgsT0FBTzJDLFFBQVgsRUFBb0I7QUFDaEIzQyxXQUFPNEMsU0FBUCxDQUFpQixVQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDekVEO0FBRUE7QUFDQXhCLFNBQVMsVUFBU2dELFNBQVQsRUFBbUI7QUFDeEIsUUFBSS9DLE1BQU0sSUFBSW9DLElBQUosQ0FBVVcsU0FBVixDQUFWO0FBQ0EsUUFBSUMsV0FBV1osS0FBS2EsR0FBTCxLQUFhakQsSUFBSWtELE9BQUosRUFBNUI7QUFDQSxRQUFJQyxVQUFVLElBQUlmLElBQUosQ0FBU1ksUUFBVCxDQUFkO0FBQ0EsV0FBT0ksS0FBS0MsR0FBTCxDQUFTRixRQUFRRyxjQUFSLEtBQTBCLElBQW5DLENBQVA7QUFDSCxDQUxELEM7Ozs7Ozs7Ozs7O0FDSEEsSUFBSTNFLE1BQUo7QUFBV1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDTSxXQUFPTCxDQUFQLEVBQVM7QUFBQ0ssaUJBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0ROLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiO0FBRzFFTSxPQUFPOEMsT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZEO0FBSUE5QyxPQUFPRSxPQUFQLENBQWU7QUFDWCxnQkFBWSxZQUFVO0FBQ2xCVSxnQkFBUUMsR0FBUixDQUFZLHNCQUFaO0FBQ0FiLGVBQU8rQixJQUFQLENBQVksZUFBWjtBQUNBL0IsZUFBTytCLElBQVAsQ0FBWSxXQUFaO0FBQ0EvQixlQUFPK0IsSUFBUCxDQUFZLFVBQVo7QUFDSDtBQU5VLENBQWYsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5leHBvcnQgY29uc3QgRXBzcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdlcHNzJyk7XHJcbmltcG9ydCB7SFRUUCB9IGZyb20gJ21ldGVvci9odHRwJ1xyXG5pbXBvcnQge1BhdH0gZnJvbSBcIi4vcGF0XCI7XHJcbmltcG9ydCB7T2JzZXJ2YXRpb25zfSBmcm9tIFwiLi9vYnNlcnZhdGlvbnNcIjtcclxuXHJcblxyXG5cclxuLypcclxuVGhpcyBpcyB3aGVyZSB3ZSB3aWxsIGZldGNoIGFuZCBzdG9yZSB0aGUgQUhSUSBFUFNTIHJlY29tbWVuZGF0aW9uc1xyXG51c2Ugb2YgdGhpcyByZXF1aXJlcyBhbiBlUFNTIGtleSwgYW5kIHRoZXJlIGlzIHNvbWUgbG9naWMgdG8gZmV0Y2ggYW5kIHZhbGlkYXRlIHRoZSBrZXkgaGVyZVxyXG5UaGUga2V5IHNob3VsZCBiZSBwbGFjZWQgaW4gdGhlIFByaXZhdGUgZm9sZGVyLCBpbiBhIGZpbGUgY2FsbGVkICdlUFNTX0tleS5qc29uJ1xyXG5USGUgZmlsZSBzaG91bGQgYmUgYSBzaW1wbGUganNvbiBvYmplY3Q6XHJcblxyXG57XHJcbiAgXCJLZXlcIjpcIlBVVF9LRVlfSEVSRVwiXHJcbn1cclxuXHJcblBsZWFzZSByZXZpZXcgdGhlIEFIUlEgQ29weXJpZ2h0IGFuZCBEaXNjbGFpbWVyIG5vdGljZSBiZWZvcmUgdXNpbmcgdGhlIEFQSTogaHR0cHM6Ly93d3cudXNwcmV2ZW50aXZlc2VydmljZXN0YXNrZm9yY2Uub3JnL1BhZ2UvTmFtZS9jb3B5cmlnaHQtbm90aWNlLlxyXG5JbnN0cnVjdGlvbnMgZm9yIHVzZSBhbmQgYWNjZXNzIGluZm9ybWF0aW9uIGNhbiBiZSBmb3VuZCBhdDpcclxu4oCiXHRJbnN0cnVjdGlvbiBmb3IgVXNlOiAgaHR0cDovL2Vwc3MuYWhycS5nb3YvUERBL2RvY3MvZVBTU19EYXRhX0FQSV9XSV93TGluay5wZGZcclxu4oCiXHRVUkw6ICBodHRwOi8vZXBzc2RhdGEuYWhycS5nb3YvXHJcbiAqL1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgICAgICAgJ2dldEVwc3MnOiBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgICAgICAvLyBvbmx5IHVwZGF0ZSBpZiBlbXB0eS0gdXBkYXRlUGF0IHNob3VsZCBlbXB0eSB0aGlzIGNvbGxlY3Rpb24uLi5cclxuICAgICAgICAgICAgaWYgKEVwc3MuZmluZCgpLmNvdW50KCkgPiAwICkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIEZpcnN0LCB3ZSBuZWVkIHRvIGtub3cgdGhlIGVwc3MgYXBpIHVybFxyXG4gICAgICAgICAgICBjb25zdCB1cmwgPSAnaHR0cDovL2Vwc3NkYXRhLmFocnEuZ292Lyc7XHJcbiAgICAgICAgICAgIGxldCBlUFNTX0tleSA9ICcnO1xyXG4gICAgICAgICAgICAvLyBOZXh0LCBnZXQgdGhlIGVQU1Mga2V5IGZyb20gdGhlIHRleHQgZmlsZSBpbiB0aGUgUHJpdmF0ZSBmb2xkZXIuXHJcbiAgICAgICAgICAgIC8vIHRoaXMgZmlsZSB3aWxsIG5vdCBzeW5jIHdpdGggZ2l0IGlmIGl0IGlzIGluIHRoZSAuZ2l0aWdub3JlXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgZVBTU19LZXkgPSBKU09OLnBhcnNlKEFzc2V0cy5nZXRUZXh0KCdlUFNTX0tleS5qc29uJykpO1xyXG4gICAgICAgICAgICAgICAgLy8gSWYgdGhlIGtleSBpcyBibGFuayBvciBub3QgdXBkYXRlZCwgd2UgY2Fubm90IGNvbnRpbnVlLi5cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoZVBTU19LZXkua2V5ID09PSAnUFVUX0tFWV9IRVJFJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdlUFNTIEtleSBub3QgZm91bmQgb3IgaW52YWxpZC0gcGxlYXNlIGlucHV0IHlvdXIgZVBTUyBrZXkgaW50byBlUFNTX0tleS5qc29uIGZpbGUgaW4gcHJpdmF0ZSBmb2xkZXInKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2goZSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcgZVBTUyBrZXkgZmFpbGVkLiBQbGVhc2UgbWFrZSBzdXJlIGVQU1NfS2V5Lmpzb24gZXhpc3RzIGluIHRoZSBwcml2YXRlIGZvbGRlci4nKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUubWVzc2FnZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGdldCBpbmZvIGZyb20gUGF0LCBPYnNlcnZhdGlvbnMgY29sbGVjdGlvbnNcclxuXHJcbiAgICAgICAgICAgIGxldCBzZXggPSBQYXQuZmluZE9uZSgpLmdlbi5zZXg7XHJcbiAgICAgICAgICAgIGxldCBhZ2UgPSBnZXRBZ2UoUGF0LmZpbmRPbmUoKS5nZW4uZG9iKTtcclxuICAgICAgICAgICAgbGV0IHRvYmFjY28gPSAnJztcclxuICAgICAgICAgICAgaWYgKE9ic2VydmF0aW9ucy5maW5kT25lKHtjYXRlZ29yeTogJ3NvY2lhbEhpc3RvcnknLCBuYW1lOiAnU21va2luZyBTdGF0dXMnfSkpIHtcclxuICAgICAgICAgICAgICAgIHRvYmFjY28gPSBPYnNlcnZhdGlvbnMuZmluZE9uZSh7Y2F0ZWdvcnk6ICdzb2NpYWxIaXN0b3J5JywgbmFtZTogJ1Ntb2tpbmcgU3RhdHVzJ30pLnZhbHVlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgc2V4dWFsbHlBY3RpdmUgPSAnJztcclxuICAgICAgICAgICAgaWYgKE9ic2VydmF0aW9ucy5maW5kT25lKHtjYXRlZ29yeTogJ3NvY2lhbEhpc3RvcnknLCBuYW1lOiAnU2V4dWFsbHkgQWN0aXZlJ30pKVxyXG4gICAgICAgICAgICAgICAgc2V4dWFsbHlBY3RpdmUgPSBPYnNlcnZhdGlvbnMuZmluZE9uZSh7Y2F0ZWdvcnk6ICdzb2NpYWxIaXN0b3J5JywgbmFtZTogJ1NleHVhbGx5IEFjdGl2ZSd9KS52YWx1ZTtcclxuICAgICAgICAgICAgbGV0IHByZWduYW50ID0gbnVsbDtcclxuICAgICAgICAgICAgaWYoc2V4ID09PSdGJyl7XHJcbiAgICAgICAgICAgICAgICBwcmVnbmFudCA9ICdOJyAvLyBwbGFjZWhvbGRlciBmb3IgcmVhbCBsb2dpY1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL2J1aWxkIHRoZSBwYXJhbXMgb2JqZWN0XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBhZ2U6IGFnZSxcclxuICAgICAgICAgICAgICAgIHNleDogc2V4LFxyXG4gICAgICAgICAgICAgICAgcHJlZ25hbnQ6IHByZWduYW50LCAvLyAnTicgLS0gKFksTikgLSByZXF1aXJlcyBGZW1hbGUgc2V4IHRvIGJlIHByZXNlbnRcclxuICAgICAgICAgICAgICAgIHRvYmFjY286IHRvYmFjY28sXHJcbiAgICAgICAgICAgICAgICBzZXh1YWxseUFjdGl2ZTogc2V4dWFsbHlBY3RpdmUsXHJcbiAgICAgICAgICAgICAgICAvL2dyYWRlOiBbJ0EnLCAnQiddXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAvLyBsYXN0bHksIGluc2VydCBrZXkgaW50byBwYXJhbXNcclxuICAgICAgICAgICAgcGFyYW1zLmtleSA9IGVQU1NfS2V5LmtleTtcclxuXHJcbiAgICAgICAgICAgIC8vIFRyeSB0byBmZXRjaCB0aGUgZVBTUyByZWNvbW1lbmRhdGlvbnMgYmFzZWQgb24gdGhlIHBhcmFtcy5cclxuICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyB0byBzcGVlZCB0aGlzIHVwLCBhbmQgdG8gYmUgYWJsZSB0byBncmFiIG11bHRpcGxlIGdyYWRlcywgd2Ugd2lsbCBkbyB0aGlzIHR3aWNlXHJcbiAgICAgICAgICAgICAgICAvLyB0aGUgZmlyc3QgdGltZSwgd2Ugd2lsbCB1c2UgZ3JhZGU6ICdBJyxcclxuICAgICAgICAgICAgICAgIC8vIHRoZSBzZWNvbmQgdGltZSwgd2Ugd2lsbCB1c2UgZ3JhZGU6ICdCXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gdG8gc2ltcGxpZnkgY29kZSwgd2Ugd2lsbCBkZWZpbmUgdGhlIGh0dHAgY2FsbCBhcyBhIGZ1bmN0aW9uIHdpdGggYSBncmFkZSBhcmd1bWVudFxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IGdldEVwc3MgPSBmdW5jdGlvbihncmFkZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gcGx1ZyBncmFkZSBpbnRvIHRoZSBwYXJhbXNcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMuZ3JhZGUgPSBncmFkZTtcclxuICAgICAgICAgICAgICAgICAgICBIVFRQLmNhbGwoJ2dldCcsIHVybCx7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiAnQWNjZXB0OiBhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gcGFyYW1zIGdvIGhlcmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhc3luYyBjYWxsYmFja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbihlcnIsIHJlc3VsdCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKGVycil7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcmVzdWx0cyBlbmQgdXAgaGVyZTogd2Ugb25seSB3YW50IHRvIHN0b3JlIHRoZSBzcGVjaWZpYyByZWNvbW1lbmRhdGlvbnMgYXJyYXkgb2JqZWN0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gc28sIHdlIHdpbGwganVzdCBpbnNlcnQgdGhlc2UgaW50byBvdXIgRXBzcyBjb2xsZWN0aW9uIGluZGl2aWR1YWxseS5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMgd2lsbCBtYWtlIHRoZW0gZWFzeSB0byBzZWFyY2guXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZXBzc0NvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZWNzID0gcmVzdWx0LmRhdGEuc3BlY2lmaWNSZWNvbW1lbmRhdGlvbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHJlY3MpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFcHNzLmluc2VydChyZWNzW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcHNzQ291bnQgKz0xO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXBzc0NvdW50ICsgJyBHcmFkZSAnK2dyYWRlKycgZVBTUyByZWNzIGluc2VydGVkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICBnZXRFcHNzKCdBJyk7XHJcbiAgICAgICAgICAgICAgICBnZXRFcHNzKCdCJyk7XHJcblxyXG5cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgICdjbGVhckVwc3MnOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICAgICAgRXBzcy5yZW1vdmUoe30pXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICAgICAvLyBQdWJsaWNhdGlvbiBmdW5jdGlvbiBmcm9tIHRoZSBzZXJ2ZXItIHRoaXMgbGV0J3MgdXMgZGVmaW5lIHdoYXQgdGhlIGNsaWVudC1zaWRlIGRiIGdldHNcclxuICAgICAgICBNZXRlb3IucHVibGlzaCgnZXBzcycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIC8vIHdlIHdpbGwgcmV0dXJuIHRoZSBlbnRpcmUgY29sbGVjdGlvbi5cclxuICAgICAgICAgICAgcmV0dXJuIEVwc3MuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG4gICAgICAgIC8vIGFzIHRoZSBjbGllbnQsIHN1YnNjcmliZXMgdG8gdGhlIGFib3ZlIHB1YmxpY2F0aW9uXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnZXBzcycpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IE1ldHJpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWV0cmljcycpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBwYXQgY29sbGVjdGlvbi5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFudCBQYXQgZGF0YSBhdCBzdGFydHVwIGFzIHRoZXJlIHNob3VsZCBub3QgYmUgYW55IHBhdGllbnQgaW4gY29udGV4dC5cclxuICAgICAgICBNZXRyaWNzLnJlbW92ZSh7fSlcclxuXHJcbiAgICB9KTtcclxuXHJcblxyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ21ldHJpY3MnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgIHJldHVybiBNZXRyaWNzLmZpbmQoKVxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgICAgICdnZXRNZXRyaWNzJzogZnVuY3Rpb24ocGF0SWQpe1xyXG4gICAgICAgICAgICBNZXRyaWNzLnJlbW92ZSh7fSk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtZXRyaWNzU3RyaW5nID0gQXNzZXRzLmdldFRleHQoJ21ldHJpY3MuY3N2Jyk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29uc3QgbWV0cmljcyA9IFBhcGEucGFyc2UobWV0cmljc1N0cmluZywge2hlYWRlcjogdHJ1ZX0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gbWV0cmljcy5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1ldHJpY3MuZGF0YVt4XS5wYXRJZCA9PT0gcGF0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgTWV0cmljcy5pbnNlcnQobWV0cmljcy5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBtZXRyaWNzIGVudGVyZWQnKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNvbWV0aGluZyB3ZW50IHdyb25nIHdpdGggcGFyc2luZyB0aGUgbWV0cmljcyBkYXRhXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdtZXRyaWNzJylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcblxyXG5leHBvcnQgY29uc3QgT2JzZXJ2YXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ29icycpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBwYXQgY29sbGVjdGlvbi5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFueSBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIE9ic2VydmF0aW9ucy5yZW1vdmUoe30pXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ29icycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIE9ic2VydmF0aW9ucy5maW5kKClcclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnZ2V0T2JzJzogZnVuY3Rpb24ocGF0SWQpe1xyXG4gICAgICAgICAgICBPYnNlcnZhdGlvbnMucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgnb2JzZXJ2YXRpb25zLmNzdicpO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlID0gUGFwYS5wYXJzZShTdHJpbmcsIHtoZWFkZXI6IHRydWV9KTtcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHBhcnNlLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2UuZGF0YVt4XS5wYXRJZCA9PT0gcGF0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgT2JzZXJ2YXRpb25zLmluc2VydChwYXJzZS5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIE9ic2VydmF0aW9ucyBhcmUgaW4gdGhlcmUsIGJ1dCB0aGUgZGF0ZSBmaWVsZCBpcyBqdXN0IGEgc3RyaW5nLlxyXG4gICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHRyYW5zZm9ybSB0aGUgc3RyaW5nIGluIHRoZSBcImRhdGVcIiBmaWVsZCBpbnRvIGEgamF2YXNjcmlwdCBkYXRlLlxyXG4gICAgICAgICAgICAgICAgbGV0IGFsbCA9IE9ic2VydmF0aW9ucy5maW5kKCkuZmV0Y2goKTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gYWxsKXtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgX2lkID0gYWxsW3hdLl9pZFxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoYWxsW3hdLmRhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coZGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICBPYnNlcnZhdGlvbnMudXBzZXJ0KHtfaWQ6IF9pZH0seyRzZXQ6IHtkYXRlOiBkYXRlfX0pXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY291bnQgKyAnIG9ic2VydmF0aW9ucyBlbnRlcmVkJylcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzb21ldGhpbmcgd2VudCB3cm9uZyB3aXRoIHBhcnNpbmcgdGhlIG9ic2VydmF0aW9ucyBkYXRhXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdvYnMnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuaW1wb3J0IHtQYXRpZW50c30gZnJvbSBcIi4vcGF0aWVudHNcIjtcclxuaW1wb3J0IHtFcHNzfSBmcm9tIFwiLi9lcHNzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgUGF0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3BhdCcpO1xyXG5cclxuLy8gT25jZSBvdXIgcGF0aWVudCBpcyBzZWxlY3RlZCB3ZSBuZWVkIHRvIHBvcHVsYXRlIG91ciBjb2xsZWN0aW9ucy4gVGhlIG1haW4gZnVuY3Rpb25zIGZvciB0aGlzIGFyZSBoYW5kbGVkIGhlcmVcclxuLy8gV2l0aCByZWZlcmVuY2VzIHRvIHRoZSBvdGhlciBjb2xsZWN0aW9ucyB3aGVuIG5lZWRlZC5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgICAgIC8vIGNsZWFyIGFudCBQYXQgZGF0YSBhdCBzdGFydHVwIGFzIHRoZXJlIHNob3VsZCBub3QgYmUgYW55IHBhdGllbnQgaW4gY29udGV4dC5cclxuICAgICAgICBQYXQucmVtb3ZlKHt9KVxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAndXBkYXRlUGF0JzogZnVuY3Rpb24ocGF0SWQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVQYXQgd2FzIHJ1blwiKTtcclxuXHJcblxyXG4gICAgICAgICAgICAvLyBPaywgRmlyc3QsIGxldCdzIGZldGNoIHRoZSBvdGhlciBkYXRhIGFib3V0IHRoZSBwYXRpZW50XHJcbiAgICAgICAgICAgIC8vIFdlJ2xsIHN0b3JlIHRoaXMgc2luZ2xlIHBhdGllbnQncyBkYXRhIGluIGEgbmV3IENvbGxlY3Rpb24sIHBhdFxyXG5cclxuICAgICAgICAgICAgLy8gSWYgYW55IG9sZCBkYXRhIGlzIGluIFBhdCBvciBFcHNzIG5lZWQgdG8gY2xlYXIgaXRcclxuICAgICAgICAgICAgUGF0LnJlbW92ZSh7fSk7XHJcbiAgICAgICAgICAgIEVwc3MucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIE5vdywgbGV0J3Mgc3RhcnQgZnJlc2ggd2l0aCBvdXIgY3VycmVudGx5IHNlbGVjdGVkIHBhdGllbnRcclxuICAgICAgICAgICAgUGF0Lmluc2VydCh7X2lkOiBwYXRJZH0pO1xyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIHRoZXNlIGhlbHBlciBmdW5jdGlvbnMgd2lsbCBtYWtlIGluc2VydGluZyBhbmQgcmVhZGluZyBkYXRhIGVhc2llclxyXG5cclxuICAgICAgICAgICAgLy8gVGhpcyBvbmUgYWRkcyBhIG5ldyBvYmplY3QgdG8gdGhlIGRhdGFiYXNlIGNvbGxlY3Rpb24gdW5kZXIgdGhpcyBwYXRJZFxyXG4gICAgICAgICAgICBmdW5jdGlvbiB1cGRhdGVQYXQob2JqZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKG9iamVjdClcclxuICAgICAgICAgICAgICAgIFBhdC51cGRhdGUoe19pZDogcGF0SWR9LCB7JHNldDogIG9iamVjdH0pXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vZS5nLiAtIGZpcnN0IGxldCdzIHVzZSBvdXIgXCJQYXRpZW50c1wiIGxpc3QgYW5kIGdldCB0aGUgZnVsbCBuYW1lIGFuZCBhbHNvIHRoZSBhZ2VcclxuICAgICAgICAgICAgdXBkYXRlUGF0KHtcclxuICAgICAgICAgICAgICAgIG5hbWU6IFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pLmZuYW1lICsgJyAnICsgUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSkubG5hbWUsXHJcbiAgICAgICAgICAgICAgICBhZ2U6IGdldEFnZShQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KS5kb2IpXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgLy8gTGV0J3MgdGhyb3cgZXZlcnl0aGluZyBlbHNlIHRoYXQgaXMgaW4gdGhlIFwiUGF0aWVudHNcIiBjb2xsZWN0aW9uIGFib3V0IG91ciBwYXRpZW50IGluIGEgZ2VuIChmb3IgXCJnZW5lcmFsXCIpIG9iamVjdFxyXG4gICAgICAgICAgICB1cGRhdGVQYXQoe1xyXG4gICAgICAgICAgICAgICAgZ2VuOiBQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbi8vIFNpbXVsYXRlIGEgY2FsbCB0byBhIHRhYmxlIHRoYXQgaG9sZHMgcGF0aWVudCBPYnNlcnZhdGlvbnNcclxuICAgICAgICAgICAgLy8gVGhlIG1ldGVvci5jYWxsIGFjdHVhbGx5IGp1c3QgcmVhZHMgZnJvbSB0aGUgQ1NWLCBidXQgaXQgZG9lcyB0aGVuIGZpbHRlciBieSB0aGUgcGF0SWRcclxuICAgICAgICAgICAgLy8gc29ydCBvZiBsaWtlIGhvdyBhIHJlYWwgU1FMIGNhbGwgd291bGQgd29yay5cclxuICAgICAgICAgICAgLy8gV2Ugd2lsbCBzdG9yZSB0aGlzIGluIG91ciBQYXQgY29sbGVjdGlvbiB1bmRlciB0aGUgZ3JvdXAgJ29icydcclxuXHJcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKCdnZXRPYnMnLCBwYXRJZCk7XHJcblxyXG4vLyBOb3cgc2ltdWxhdGUgYSBjYWxsIGZvciBwYXRpZW50IE1ldHJpY3NcclxuICAgICAgICAgICAgLy8gdGhpcyB3aWxsIGdvIGluIGEgc2VwYXJhdGUgY29sbGVjdGlvbiBmb3Igc2VhcmNoaW5nLCBzbyBqdXN0IGlzIGEgbWV0ZW9yLmNhbGxcclxuXHJcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKCdnZXRNZXRyaWNzJywgcGF0SWQpXHJcblxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgICdjbGVhclBhdCc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBQYXQucmVtb3ZlKHt9KVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdwYXQnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICByZXR1cm4gUGF0LmZpbmQoKVxyXG4gICAgICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgncGF0JylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcbmV4cG9ydCBjb25zdCBQYXRpZW50cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwYXRpZW50cycpO1xyXG5cclxuXHJcbi8vIFBvcHVsYXRlIG91ciBsb2NhbCBwYXRpZW50IGRhdGFiYXNlIHdpdGggc29tZSBwcmUtYnVpbHQgcGF0aWVudCBkYXRhLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAgIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXHJcblxyXG4gICAgLy8gT25seSBkbyB0aGlzIG9uIHN0YXJ0dXAgaWYgdGhlIGRiIGlzIGVtcHR5XHJcbiAgICBpZiAoUGF0aWVudHMuZmluZCgpLmNvdW50KCkgPT09IDApe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZm91bmQgbm8gcGF0aWVudHMtIGdldHRpbmcgZGF0YS4uLlwiKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgncmVzZXRQYXRpZW50cycpXHJcblxyXG4gICAgfSBlbHNle1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdmb3VuZCBwYXRpZW50cyBhbHJlYWR5IGluIGRhdGFiYXNlJylcclxuICAgIH1cclxuXHJcbn0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnY2xlYXJQYXRpZW50cyc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBQYXRpZW50cy5yZW1vdmUoe30pXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgJ3Jlc2V0UGF0aWVudHMnOiBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3Jlc2V0dGluZyBwYXRpZW50IERCJyk7XHJcbiAgICAgICAgICAgIFBhdGllbnRzLnJlbW92ZSh7fSk7XHJcblxyXG4gICAgICAgICAgICAvLyBUaGUgcGF0aWVudCBkYXRhIGlzIHN0b3JlZCBhcyBhIENTViBmaWxlIGluIG91ciBcInByaXZhdGVcIiBmb2xkZXJcclxuICAgICAgICAgICAgLy8gVGhpcyBhbGxvd3MgdXMgdG8gcXVpY2sgYW5kIGRpcnR5IHJlcGxpY2F0ZSB3aGF0IG1pZ2h0IGJlIGEgdmlldyBvbiBBY3VlcmVcclxuICAgICAgICAgICAgLy8gSXQgd291bGQgcHJvYmFibHkgYmUgZWFzaWVyIGlmIHRoaXMgd291bGQganVzdCBwdWxsIGZyb20gQWN1ZXJlLi4uXHJcblxyXG4gICAgICAgICAgICAvL0ZpcnN0LCBpbXBvcnQgdGhlIGNzdiBhcyBhIHN0cmluZzogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMTc0NTM4NDgvaXMtdGhlcmUtYS13YXktdG8taW1wb3J0LXN0cmluZ3MtZnJvbS1hLXRleHQtZmlsZS1pbi1qYXZhc2NyaXB0LW1ldGVvclxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhdGllbnRTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgncGF0aWVudHMuY3N2Jyk7XHJcbiAgICAgICAgICAgICAgICAvLyBwYXRpZW50U3RyaW5nIHdpbGwgY29udGFpbiB0aGUgZGF0YSBhcyBvbmUgbG9uZyBDU1Ygc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAvLyBXZSBuZWVkIHRvIHBhcnNlIGl0IHRvIGEgSlNPTiBvYmplY3QuXHJcbiAgICAgICAgICAgICAgICAvLyB3aWxsIHVzZSB0aGUgUGFwYSBwYXJzZSBwYWNrYWdlIHRvIGRvIHRoaXMuLi5cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXRpZW50RGF0YSA9IFBhcGEucGFyc2UocGF0aWVudFN0cmluZywge2hlYWRlcjogdHJ1ZX0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIFdlIHdpbGwgc3RvcmUgdGhlIGRhdGEgaW4gb3VyIG93biBNb25nbyBjb2xsZWN0aW9uIHRoYXQgd2UgZGVmaW5lZCBhYm92ZS0gUGF0aWVudHNcclxuICAgICAgICAgICAgICAgIC8vIFByZWZlciB0byBzdG9yZSBlYWNoIHBhdGllbnQgYXMgdGhlaXIgb3duIFwiZG9jdW1lbnRcIiB0byBtYWtlIHNlYXJjaGVzIGFuZCBzdHVmZiBlYXNpZXIsIHNvIGxvb3AgdGhyb3VnaCB0aGUgQ1NWIGRhdGEgYW5kIGluc2VydCBvbmUgYXQgYSB0aW1lXHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBwYXRpZW50RGF0YS5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYocGF0aWVudERhdGEuZGF0YVt4XS5wYXRJZCAhPT0nJyl7IC8vIGlnbm9yZXMgYW55IGJsYW5rIHJvd3MgKGkuZS4gbGFzdCByb3cgdGhhdCBhbHdheXMgY29tZXMgYmFjaylcclxuICAgICAgICAgICAgICAgICAgICAgICAgUGF0aWVudHMuaW5zZXJ0KHBhdGllbnREYXRhLmRhdGFbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCArPSAxXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY291bnQgKyAnIHBhdGllbnRzIGVudGVyZWQnKVxyXG5cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzb21ldGhpbmcgd2VudCB3cm9uZyB3aXRoIGdldHRpbmcgdGhlIHBhdGllbnQgbGlzdFwiKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUubWVzc2FnZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9KTtcclxuXHJcbiAgICAgICAgTWV0ZW9yLnB1Ymxpc2goJ3BhdGllbnRzJywgZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgcmV0dXJuIFBhdGllbnRzLmZpbmQoKVxyXG4gICAgICAgIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgncGF0aWVudHMnKVxyXG59IiwiLy8gZ2xvYmFsIGZ1bmN0aW9ucyBnbyBoZXJlXHJcblxyXG4vLyB0aGlzIGp1c3QgY2FsY3VsYXRlcyB0aGUgYWdlIGluIHllYXJzIGJhc2VkIG9uIGJpcnRoZGF0ZVxyXG5nZXRBZ2UgPSBmdW5jdGlvbihkb2JTdHJpbmcpe1xyXG4gICAgbGV0IGRvYiA9IG5ldyBEYXRlIChkb2JTdHJpbmcpO1xyXG4gICAgbGV0IGFnZURpZk1zID0gRGF0ZS5ub3coKSAtIGRvYi5nZXRUaW1lKCk7XHJcbiAgICBsZXQgYWdlRGF0ZSA9IG5ldyBEYXRlKGFnZURpZk1zKTtcclxuICAgIHJldHVybiBNYXRoLmFicyhhZ2VEYXRlLmdldFVUQ0Z1bGxZZWFyKCktIDE5NzApXHJcbn07XHJcblxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0ICcuLi9pbXBvcnRzL2dsb2JhbCc7XHJcblxyXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcclxufSk7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcbiAgICAncmVzZXRBbGwnOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdGdWxsIHJlc2V0IGNhbGxlZC4uLicpO1xyXG4gICAgICAgIE1ldGVvci5jYWxsKCdyZXNldFBhdGllbnRzJyk7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ2NsZWFyRXBzcycpO1xyXG4gICAgICAgIE1ldGVvci5jYWxsKCdjbGVhclBhdCcpO1xyXG4gICAgfVxyXG59KTsiXX0=
