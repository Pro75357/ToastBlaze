var require = meteorInstall({"collections":{"epss.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/epss.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Epss: () => Epss
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let HTTP;
module.watch(require("meteor/http"), {
    HTTP(v) {
        HTTP = v;
    }

}, 1);
const Epss = new Mongo.Collection('epss');

/*
Please review the AHRQ Copyright and Disclaimer notice before using the API: https://www.uspreventiveservicestaskforce.org/Page/Name/copyright-notice.
Instructions for use and access information can be found at:
•	Instruction for Use:  http://epss.ahrq.gov/PDA/docs/ePSS_Data_API_WI_wLink.pdf
•	URL:  http://epssdata.ahrq.gov/
 */if (Meteor.isServer) {
    Meteor.methods({
        'getEpss': function (params) {
            //Very first, clean out old ePSS data (if any)
            Epss.remove({}); // First, we need to know the epss api url

            const url = 'http://epssdata.ahrq.gov/'; // Next, get the ePSS key from the text file in the Private folder.
            // this folder will not sync with git as it is in the .gitignore

            try {
                var ePSS_Key = JSON.parse(Assets.getText('ePSS_Key.json'));
            } catch (e) {
                console.log('Fetching ePSS key failed. Please make sure ePSS_Key.json exists in the private folder.');
                console.log(e.message);
            } // If the key is blank or not updated, we cannot continue..
            //let blankKeys = ['','PUT_KEY_HERE']


            if (ePSS_Key.key === 'PUT_KEY_HERE') {
                console.log('ePSS Key not found or invalid- please input your ePSS key into ePSS_Key.json file in private folder');
                return false;
            } else {
                // If no params are passed, error and return false
                if (!params) {
                    console.log("No ePSS parameters found. Not fetching.");
                    return false; /*
                                  params = {
                                      age: '18',
                                      sex: 'Male',
                                      tobacco: 'N',
                                      sexuallyActive: 'N',
                                      grade: 'A'
                                  }
                                  */
                } // lastly, insert key into params


                params.key = ePSS_Key.key; // Try to fetch the ePSS recommendations based on the params.

                try {
                    HTTP.call('get', url, {
                        headers: 'accept: json',
                        params
                    }, function (err, result) {
                        if (err) {
                            throw err;
                        } else {
                            //only want to store the specific recommendations array objects
                            let epssCount = 0;
                            let recs = result.data.specificRecommendations;

                            for (var x in recs) {
                                Epss.insert(recs[x]);
                                epssCount += 1;
                            }

                            console.log(epssCount + ' ePSS recs inserted');
                            return true;
                        }
                    });
                } catch (e) {
                    console.log(e);
                }
            }
        },
        'clearEpss': function () {
            Epss.remove({});
        }
    });
    Meteor.publish('epss', function () {
        return Epss.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('epss');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metrics.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/metrics.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Metrics: () => Metrics
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Metrics = new Mongo.Collection('metrics');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Metrics.remove({});
    });
    Meteor.publish('metrics', function () {
        return Metrics.find();
    });
    Meteor.methods({
        'getMetrics': function (patId) {
            Metrics.remove({});

            try {
                const metricsString = Assets.getText('metrics.csv');
                const metrics = Papa.parse(metricsString, {
                    header: true
                });
                let count = 0;

                for (let x in metrics.data) {
                    if (metrics.data[x].patId === patId) {
                        Metrics.insert(metrics.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' metrics entered');
            } catch (e) {
                console.log("something went wrong with parsing the metrics data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('metrics');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Observations: () => Observations
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Observations = new Mongo.Collection('obs');

// Once our patient is selected we need to populate our pat collection.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear any data at startup as there should not be any patient in context.
        Observations.remove({});
    });
    Meteor.publish('obs', function () {
        return Observations.find();
    });
    Meteor.methods({
        'getObs': function (patId) {
            Observations.remove({});

            try {
                const String = Assets.getText('observations.csv');
                const parse = Papa.parse(String, {
                    header: true
                });
                let count = 0;

                for (let x in parse.data) {
                    if (parse.data[x].patId === patId) {
                        Observations.insert(parse.data[x]);
                        count += 1;
                    }
                } // Observations are in there, but the date field is just a string.
                // This will transform the string in the "date" field into a javascript date.


                let all = Observations.find().fetch();

                for (let x in all) {
                    let _id = all[x]._id;
                    let date = new Date(all[x].date); //console.log(date)

                    Observations.upsert({
                        _id: _id
                    }, {
                        $set: {
                            date: date
                        }
                    });
                }

                console.log(count + ' observations entered');
            } catch (e) {
                console.log("something went wrong with parsing the observations data");
                console.log(e.message);
                return false;
            }

            return true;
        }
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('obs');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pat.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/pat.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Pat: () => Pat
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
let Patients;
module.watch(require("./patients"), {
    Patients(v) {
        Patients = v;
    }

}, 2);
const Pat = new Mongo.Collection('pat');

// Once our patient is selected we need to populate our collections. The main functions for this are handled here
// With references to the other collections when needed.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // clear ant Pat data at startup as there should not be any patient in context.
        Pat.remove({});
    });
    Meteor.methods({
        'updatePat': function (patId) {
            console.log("updatePat was run"); // Ok, First, let's fetch the other data about the patient
            // We'll store this single patient's data in a new Collection, pat
            // If any old data is in Pat, need to clear it

            Pat.remove({}); // Now, let's start fresh with our currently selected patient

            Pat.insert({
                _id: patId
            }); // these helper functions will make inserting and reading data easier
            // This one adds a new object to the database collection under this patId

            function updatePat(object) {
                //console.log(object)
                Pat.update({
                    _id: patId
                }, {
                    $set: object
                });
            } //e.g. - first let's use our "Patients" list and get the full name and also the age


            updatePat({
                name: Patients.findOne({
                    patId: patId
                }).fname + ' ' + Patients.findOne({
                    patId: patId
                }).lname,
                age: getAge(Patients.findOne({
                    patId: patId
                }).dob)
            }); // Let's throw everything else that is in the "Patients" collection about our patient in a gen (for "general") object

            updatePat({
                gen: Patients.findOne({
                    patId: patId
                })
            }); // Simulate a call to a table that holds patient Observations
            // The meteor.call actually just reads from the CSV, but it does then filter by the patId
            // sort of like how a real SQL call would work.
            // We will store this in our Pat collection under the group 'obs'

            Meteor.call('getObs', patId); // Now simulate a call for patient Metrics
            // this will go in a separate collection for searching, so just is a meteor.call

            Meteor.call('getMetrics', patId);
        },
        'clearPat': function () {
            Pat.remove({});
        }
    });
    Meteor.publish('pat', function () {
        return Pat.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('pat');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"patients.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/patients.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Patients: () => Patients
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 1);
const Patients = new Mongo.Collection('patients');

// Populate our local patient database with some pre-built patient data.
if (Meteor.isServer) {
    Meteor.startup(() => {
        // code to run on server at startup
        // Only do this on startup if the db is empty
        if (Patients.find().count() === 0) {
            console.log("found no patients- getting data...");
            Meteor.call('resetPatients');
        } else {
            console.log('found patients already in database');
        }
    });
    Meteor.methods({
        'clearPatients': function () {
            Patients.remove({});
        },
        'resetPatients': function () {
            console.log('resetting patient DB');
            Patients.remove({}); // The patient data is stored as a CSV file in our "private" folder
            // This allows us to quick and dirty replicate what might be a view on Acuere
            // It would probably be easier if this would just pull from Acuere...
            //First, import the csv as a string: https://stackoverflow.com/questions/17453848/is-there-a-way-to-import-strings-from-a-text-file-in-javascript-meteor

            try {
                const patientString = Assets.getText('patients.csv'); // patientString will contain the data as one long CSV string
                // We need to parse it to a JSON object.
                // will use the Papa parse package to do this...

                const patientData = Papa.parse(patientString, {
                    header: true
                }); // We will store the data in our own Mongo collection that we defined above- Patients
                // Prefer to store each patient as their own "document" to make searches and stuff easier, so loop through the CSV data and insert one at a time

                let count = 0;

                for (let x in patientData.data) {
                    if (patientData.data[x].patId !== '') {
                        // ignores any blank rows (i.e. last row that always comes back)
                        Patients.insert(patientData.data[x]);
                        count += 1;
                    }
                }

                console.log(count + ' patients entered');
            } catch (e) {
                console.log("something went wrong with getting the patient list");
                console.log(e.message);
            }
        }
    });
    Meteor.publish('patients', function () {
        return Patients.find();
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('patients');
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/global.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// global functions go here
getAge = function (dobString) {
    let dob = new Date(dobString);
    let ageDifMs = Date.now() - dob.getTime();
    let ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
module.watch(require("../imports/global"));
Meteor.startup(() => {// code to run on server at startup
});
Meteor.methods({
    'resetAll': function () {
        console.log('Full reset called...');
        Meteor.call('resetPatients');
        Meteor.call('clearEpss');
        Meteor.call('clearPat');
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/epss.js");
require("./collections/metrics.js");
require("./collections/observations.js");
require("./collections/pat.js");
require("./collections/patients.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvZXBzcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvbWV0cmljcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvb2JzZXJ2YXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9wYXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3BhdGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2dsb2JhbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRXBzcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkhUVFAiLCJDb2xsZWN0aW9uIiwiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJtZXRob2RzIiwicGFyYW1zIiwicmVtb3ZlIiwidXJsIiwiZVBTU19LZXkiLCJKU09OIiwicGFyc2UiLCJBc3NldHMiLCJnZXRUZXh0IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXNzYWdlIiwia2V5IiwiY2FsbCIsImhlYWRlcnMiLCJlcnIiLCJyZXN1bHQiLCJlcHNzQ291bnQiLCJyZWNzIiwiZGF0YSIsInNwZWNpZmljUmVjb21tZW5kYXRpb25zIiwieCIsImluc2VydCIsInB1Ymxpc2giLCJmaW5kIiwiaXNDbGllbnQiLCJzdWJzY3JpYmUiLCJNZXRyaWNzIiwic3RhcnR1cCIsInBhdElkIiwibWV0cmljc1N0cmluZyIsIm1ldHJpY3MiLCJQYXBhIiwiaGVhZGVyIiwiY291bnQiLCJPYnNlcnZhdGlvbnMiLCJTdHJpbmciLCJhbGwiLCJmZXRjaCIsIl9pZCIsImRhdGUiLCJEYXRlIiwidXBzZXJ0IiwiJHNldCIsIlBhdCIsIlBhdGllbnRzIiwidXBkYXRlUGF0Iiwib2JqZWN0IiwidXBkYXRlIiwibmFtZSIsImZpbmRPbmUiLCJmbmFtZSIsImxuYW1lIiwiYWdlIiwiZ2V0QWdlIiwiZG9iIiwiZ2VuIiwicGF0aWVudFN0cmluZyIsInBhdGllbnREYXRhIiwiZG9iU3RyaW5nIiwiYWdlRGlmTXMiLCJub3ciLCJnZXRUaW1lIiwiYWdlRGF0ZSIsIk1hdGgiLCJhYnMiLCJnZXRVVENGdWxsWWVhciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFVBQUssTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUlDLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixVQUFNRyxDQUFOLEVBQVE7QUFBQ0gsZ0JBQU1HLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsSUFBSjtBQUFTUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNFLFNBQUtELENBQUwsRUFBTztBQUFDQyxlQUFLRCxDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQ3ZHLE1BQU1KLE9BQU8sSUFBSUMsTUFBTUssVUFBVixDQUFxQixNQUFyQixDQUFiOztBQUlQOzs7OztHQU9BLElBQUlDLE9BQU9DLFFBQVgsRUFBcUI7QUFFakJELFdBQU9FLE9BQVAsQ0FBZTtBQUVYLG1CQUFXLFVBQVVDLE1BQVYsRUFBa0I7QUFDekI7QUFDQVYsaUJBQUtXLE1BQUwsQ0FBWSxFQUFaLEVBRnlCLENBSXpCOztBQUNBLGtCQUFNQyxNQUFNLDJCQUFaLENBTHlCLENBT3pCO0FBQ0E7O0FBQ0EsZ0JBQUk7QUFDQSxvQkFBSUMsV0FBV0MsS0FBS0MsS0FBTCxDQUFXQyxPQUFPQyxPQUFQLENBQWUsZUFBZixDQUFYLENBQWY7QUFDSCxhQUZELENBRUUsT0FBTUMsQ0FBTixFQUFRO0FBQ05DLHdCQUFRQyxHQUFSLENBQVksd0ZBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUYsRUFBRUcsT0FBZDtBQUNILGFBZHdCLENBZ0J6QjtBQUNBOzs7QUFDQSxnQkFBSVIsU0FBU1MsR0FBVCxLQUFpQixjQUFyQixFQUFvQztBQUNoQ0gsd0JBQVFDLEdBQVIsQ0FBWSxxR0FBWjtBQUNBLHVCQUFPLEtBQVA7QUFDSCxhQUhELE1BR087QUFDSDtBQUNBLG9CQUFJLENBQUNWLE1BQUwsRUFBWTtBQUNSUyw0QkFBUUMsR0FBUixDQUFZLHlDQUFaO0FBQ0EsMkJBQU8sS0FBUCxDQUZRLENBR1I7Ozs7Ozs7OztBQVNILGlCQWRFLENBZUg7OztBQUNBVix1QkFBT1ksR0FBUCxHQUFhVCxTQUFTUyxHQUF0QixDQWhCRyxDQWtCSDs7QUFDQSxvQkFBSTtBQUNBakIseUJBQUtrQixJQUFMLENBQVUsS0FBVixFQUNJWCxHQURKLEVBRUk7QUFDSVksaUNBQVMsY0FEYjtBQUVJZDtBQUZKLHFCQUZKLEVBS08sVUFBU2UsR0FBVCxFQUFjQyxNQUFkLEVBQXFCO0FBQ3hCLDRCQUFHRCxHQUFILEVBQU87QUFDSCxrQ0FBTUEsR0FBTjtBQUNILHlCQUZELE1BRU87QUFDSDtBQUNBLGdDQUFJRSxZQUFZLENBQWhCO0FBQ0EsZ0NBQUlDLE9BQU9GLE9BQU9HLElBQVAsQ0FBWUMsdUJBQXZCOztBQUNBLGlDQUFLLElBQUlDLENBQVQsSUFBY0gsSUFBZCxFQUFvQjtBQUNoQjVCLHFDQUFLZ0MsTUFBTCxDQUFZSixLQUFLRyxDQUFMLENBQVo7QUFDQUosNkNBQVksQ0FBWjtBQUNIOztBQUNEUixvQ0FBUUMsR0FBUixDQUFZTyxZQUFZLHFCQUF4QjtBQUNBLG1DQUFPLElBQVA7QUFDSDtBQUVBLHFCQXBCTDtBQXVCSCxpQkF4QkQsQ0F3QkUsT0FBT1QsQ0FBUCxFQUFVO0FBQ1JDLDRCQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNSO0FBQ0osU0F0RWM7QUF3RVgscUJBQWEsWUFBVztBQUNwQmxCLGlCQUFLVyxNQUFMLENBQVksRUFBWjtBQUNIO0FBMUVVLEtBQWY7QUE4RUlKLFdBQU8wQixPQUFQLENBQWUsTUFBZixFQUF1QixZQUFVO0FBQzdCLGVBQU9qQyxLQUFLa0MsSUFBTCxFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUkzQixPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLE1BQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUNuR0R0QyxPQUFPQyxNQUFQLENBQWM7QUFBQ3NDLGFBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlwQyxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLE1BQUo7QUFBV1QsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSSxXQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUJBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHL0csTUFBTWlDLFVBQVUsSUFBSXBDLE1BQU1LLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7O0FBRVA7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPK0IsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQUQsZ0JBQVExQixNQUFSLENBQWUsRUFBZjtBQUVILEtBSkQ7QUFPQUosV0FBTzBCLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVU7QUFDaEMsZUFBT0ksUUFBUUgsSUFBUixFQUFQO0FBQ0gsS0FGRDtBQUlBM0IsV0FBT0UsT0FBUCxDQUFlO0FBQ1gsc0JBQWMsVUFBUzhCLEtBQVQsRUFBZTtBQUN6QkYsb0JBQVExQixNQUFSLENBQWUsRUFBZjs7QUFDQSxnQkFBSTtBQUNBLHNCQUFNNkIsZ0JBQWdCeEIsT0FBT0MsT0FBUCxDQUFlLGFBQWYsQ0FBdEI7QUFFQSxzQkFBTXdCLFVBQVVDLEtBQUszQixLQUFMLENBQVd5QixhQUFYLEVBQTBCO0FBQUNHLDRCQUFRO0FBQVQsaUJBQTFCLENBQWhCO0FBQ0Esb0JBQUlDLFFBQVEsQ0FBWjs7QUFDQSxxQkFBSyxJQUFJYixDQUFULElBQWNVLFFBQVFaLElBQXRCLEVBQTRCO0FBQ3hCLHdCQUFJWSxRQUFRWixJQUFSLENBQWFFLENBQWIsRUFBZ0JRLEtBQWhCLEtBQTBCQSxLQUE5QixFQUFxQztBQUNqQ0YsZ0NBQVFMLE1BQVIsQ0FBZVMsUUFBUVosSUFBUixDQUFhRSxDQUFiLENBQWY7QUFDQWEsaUNBQVMsQ0FBVDtBQUNIO0FBQ0o7O0FBQ0R6Qix3QkFBUUMsR0FBUixDQUFZd0IsUUFBUSxrQkFBcEI7QUFDSCxhQVpELENBWUUsT0FBTzFCLENBQVAsRUFBVTtBQUNSQyx3QkFBUUMsR0FBUixDQUFZLG9EQUFaO0FBQ0FELHdCQUFRQyxHQUFSLENBQVlGLEVBQUVHLE9BQWQ7QUFDQSx1QkFBTyxLQUFQO0FBQ0g7O0FBQ0QsbUJBQU8sSUFBUDtBQUNIO0FBckJVLEtBQWY7QUF1Qkg7O0FBRUQsSUFBSWQsT0FBTzRCLFFBQVgsRUFBb0I7QUFDaEI1QixXQUFPNkIsU0FBUCxDQUFpQixTQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDaEREdEMsT0FBT0MsTUFBUCxDQUFjO0FBQUM4QyxrQkFBYSxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUk1QyxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLE1BQUo7QUFBV1QsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSSxXQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUJBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHekgsTUFBTXlDLGVBQWUsSUFBSTVDLE1BQU1LLFVBQVYsQ0FBcUIsS0FBckIsQ0FBckI7O0FBRVA7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPK0IsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQU8scUJBQWFsQyxNQUFiLENBQW9CLEVBQXBCO0FBRUgsS0FKRDtBQU9BSixXQUFPMEIsT0FBUCxDQUFlLEtBQWYsRUFBc0IsWUFBVTtBQUM1QixlQUFPWSxhQUFhWCxJQUFiLEVBQVA7QUFDSCxLQUZEO0FBSUEzQixXQUFPRSxPQUFQLENBQWU7QUFDWCxrQkFBVSxVQUFTOEIsS0FBVCxFQUFlO0FBQ3JCTSx5QkFBYWxDLE1BQWIsQ0FBb0IsRUFBcEI7O0FBRUEsZ0JBQUk7QUFDQSxzQkFBTW1DLFNBQVM5QixPQUFPQyxPQUFQLENBQWUsa0JBQWYsQ0FBZjtBQUVBLHNCQUFNRixRQUFRMkIsS0FBSzNCLEtBQUwsQ0FBVytCLE1BQVgsRUFBbUI7QUFBQ0gsNEJBQVE7QUFBVCxpQkFBbkIsQ0FBZDtBQUNBLG9CQUFJQyxRQUFRLENBQVo7O0FBQ0EscUJBQUssSUFBSWIsQ0FBVCxJQUFjaEIsTUFBTWMsSUFBcEIsRUFBMEI7QUFDdEIsd0JBQUlkLE1BQU1jLElBQU4sQ0FBV0UsQ0FBWCxFQUFjUSxLQUFkLEtBQXdCQSxLQUE1QixFQUFtQztBQUMvQk0scUNBQWFiLE1BQWIsQ0FBb0JqQixNQUFNYyxJQUFOLENBQVdFLENBQVgsQ0FBcEI7QUFDQWEsaUNBQVMsQ0FBVDtBQUNIO0FBQ0osaUJBVkQsQ0FXQTtBQUNBOzs7QUFDQSxvQkFBSUcsTUFBTUYsYUFBYVgsSUFBYixHQUFvQmMsS0FBcEIsRUFBVjs7QUFDQSxxQkFBSyxJQUFJakIsQ0FBVCxJQUFjZ0IsR0FBZCxFQUFrQjtBQUNkLHdCQUFJRSxNQUFNRixJQUFJaEIsQ0FBSixFQUFPa0IsR0FBakI7QUFDQSx3QkFBSUMsT0FBTyxJQUFJQyxJQUFKLENBQVNKLElBQUloQixDQUFKLEVBQU9tQixJQUFoQixDQUFYLENBRmMsQ0FHZDs7QUFDQUwsaUNBQWFPLE1BQWIsQ0FBb0I7QUFBQ0gsNkJBQUtBO0FBQU4scUJBQXBCLEVBQStCO0FBQUNJLDhCQUFNO0FBQUNILGtDQUFNQTtBQUFQO0FBQVAscUJBQS9CO0FBQ0g7O0FBRUQvQix3QkFBUUMsR0FBUixDQUFZd0IsUUFBUSx1QkFBcEI7QUFDSCxhQXRCRCxDQXNCRSxPQUFPMUIsQ0FBUCxFQUFVO0FBQ1JDLHdCQUFRQyxHQUFSLENBQVkseURBQVo7QUFDQUQsd0JBQVFDLEdBQVIsQ0FBWUYsRUFBRUcsT0FBZDtBQUNBLHVCQUFPLEtBQVA7QUFDSDs7QUFDRCxtQkFBTyxJQUFQO0FBQ0g7QUFoQ1UsS0FBZjtBQWtDSDs7QUFFRCxJQUFJZCxPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLEtBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUMzRER0QyxPQUFPQyxNQUFQLENBQWM7QUFBQ3VELFNBQUksTUFBSUE7QUFBVCxDQUFkO0FBQTZCLElBQUlyRCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLE1BQUo7QUFBV1QsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSSxXQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUJBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSW1ELFFBQUo7QUFBYXpELE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ29ELGFBQVNuRCxDQUFULEVBQVc7QUFBQ21ELG1CQUFTbkQsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUluTCxNQUFNa0QsTUFBTSxJQUFJckQsTUFBTUssVUFBVixDQUFxQixLQUFyQixDQUFaOztBQUVQO0FBQ0E7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRWpCRCxXQUFPK0IsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQWdCLFlBQUkzQyxNQUFKLENBQVcsRUFBWDtBQUVILEtBSkQ7QUFNQUosV0FBT0UsT0FBUCxDQUFlO0FBQ1gscUJBQWEsVUFBUzhCLEtBQVQsRUFBZ0I7QUFDekJwQixvQkFBUUMsR0FBUixDQUFZLG1CQUFaLEVBRHlCLENBRXpCO0FBQ0E7QUFFQTs7QUFDQWtDLGdCQUFJM0MsTUFBSixDQUFXLEVBQVgsRUFOeUIsQ0FRekI7O0FBQ0EyQyxnQkFBSXRCLE1BQUosQ0FBVztBQUFDaUIscUJBQUtWO0FBQU4sYUFBWCxFQVR5QixDQVl6QjtBQUVBOztBQUNBLHFCQUFTaUIsU0FBVCxDQUFtQkMsTUFBbkIsRUFBMkI7QUFDdkI7QUFDQUgsb0JBQUlJLE1BQUosQ0FBVztBQUFDVCx5QkFBS1Y7QUFBTixpQkFBWCxFQUF5QjtBQUFDYywwQkFBT0k7QUFBUixpQkFBekI7QUFDSCxhQWxCd0IsQ0FvQnpCOzs7QUFDQUQsc0JBQVU7QUFDTkcsc0JBQU1KLFNBQVNLLE9BQVQsQ0FBaUI7QUFBQ3JCLDJCQUFPQTtBQUFSLGlCQUFqQixFQUFpQ3NCLEtBQWpDLEdBQXlDLEdBQXpDLEdBQStDTixTQUFTSyxPQUFULENBQWlCO0FBQUNyQiwyQkFBT0E7QUFBUixpQkFBakIsRUFBaUN1QixLQURoRjtBQUVOQyxxQkFBS0MsT0FBT1QsU0FBU0ssT0FBVCxDQUFpQjtBQUFDckIsMkJBQU9BO0FBQVIsaUJBQWpCLEVBQWlDMEIsR0FBeEM7QUFGQyxhQUFWLEVBckJ5QixDQTBCekI7O0FBQ0FULHNCQUFVO0FBQ05VLHFCQUFLWCxTQUFTSyxPQUFULENBQWlCO0FBQUNyQiwyQkFBT0E7QUFBUixpQkFBakI7QUFEQyxhQUFWLEVBM0J5QixDQStCckM7QUFDWTtBQUNBO0FBQ0E7O0FBRUFoQyxtQkFBT2dCLElBQVAsQ0FBWSxRQUFaLEVBQXNCZ0IsS0FBdEIsRUFwQ3lCLENBc0NyQztBQUNZOztBQUVBaEMsbUJBQU9nQixJQUFQLENBQVksWUFBWixFQUEwQmdCLEtBQTFCO0FBRUgsU0E1Q1U7QUE4Q1gsb0JBQVksWUFBVztBQUNuQmUsZ0JBQUkzQyxNQUFKLENBQVcsRUFBWDtBQUNIO0FBaERVLEtBQWY7QUFvRElKLFdBQU8wQixPQUFQLENBQWUsS0FBZixFQUFzQixZQUFVO0FBQzVCLGVBQU9xQixJQUFJcEIsSUFBSixFQUFQO0FBQ0gsS0FGRDtBQUdQOztBQUVELElBQUkzQixPQUFPNEIsUUFBWCxFQUFvQjtBQUNoQjVCLFdBQU82QixTQUFQLENBQWlCLEtBQWpCO0FBQ0gsQzs7Ozs7Ozs7Ozs7QUM3RUR0QyxPQUFPQyxNQUFQLENBQWM7QUFBQ3dELGNBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUl0RCxLQUFKO0FBQVVILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0YsVUFBTUcsQ0FBTixFQUFRO0FBQUNILGdCQUFNRyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLE1BQUo7QUFBV1QsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSSxXQUFPSCxDQUFQLEVBQVM7QUFBQ0csaUJBQU9ILENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFakgsTUFBTW1ELFdBQVcsSUFBSXRELE1BQU1LLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBR1A7QUFHQSxJQUFJQyxPQUFPQyxRQUFYLEVBQXFCO0FBRXJCRCxXQUFPK0IsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFFQTtBQUNBLFlBQUlpQixTQUFTckIsSUFBVCxHQUFnQlUsS0FBaEIsT0FBNEIsQ0FBaEMsRUFBa0M7QUFDOUJ6QixvQkFBUUMsR0FBUixDQUFZLG9DQUFaO0FBQ0FiLG1CQUFPZ0IsSUFBUCxDQUFZLGVBQVo7QUFFSCxTQUpELE1BSU07QUFDRkosb0JBQVFDLEdBQVIsQ0FBWSxvQ0FBWjtBQUNIO0FBRUosS0FaRDtBQWNJYixXQUFPRSxPQUFQLENBQWU7QUFDWCx5QkFBaUIsWUFBVztBQUN4QjhDLHFCQUFTNUMsTUFBVCxDQUFnQixFQUFoQjtBQUNILFNBSFU7QUFLWCx5QkFBaUIsWUFBVztBQUN4QlEsb0JBQVFDLEdBQVIsQ0FBWSxzQkFBWjtBQUNBbUMscUJBQVM1QyxNQUFULENBQWdCLEVBQWhCLEVBRndCLENBSXhCO0FBQ0E7QUFDQTtBQUVBOztBQUVBLGdCQUFJO0FBQ0Esc0JBQU13RCxnQkFBZ0JuRCxPQUFPQyxPQUFQLENBQWUsY0FBZixDQUF0QixDQURBLENBRUE7QUFDQTtBQUNBOztBQUVBLHNCQUFNbUQsY0FBYzFCLEtBQUszQixLQUFMLENBQVdvRCxhQUFYLEVBQTBCO0FBQUN4Qiw0QkFBUTtBQUFULGlCQUExQixDQUFwQixDQU5BLENBUUE7QUFDQTs7QUFDQSxvQkFBSUMsUUFBUSxDQUFaOztBQUNBLHFCQUFLLElBQUliLENBQVQsSUFBY3FDLFlBQVl2QyxJQUExQixFQUFnQztBQUM1Qix3QkFBR3VDLFlBQVl2QyxJQUFaLENBQWlCRSxDQUFqQixFQUFvQlEsS0FBcEIsS0FBNkIsRUFBaEMsRUFBbUM7QUFBRTtBQUNqQ2dCLGlDQUFTdkIsTUFBVCxDQUFnQm9DLFlBQVl2QyxJQUFaLENBQWlCRSxDQUFqQixDQUFoQjtBQUNBYSxpQ0FBUyxDQUFUO0FBQ0g7QUFDSjs7QUFDRHpCLHdCQUFRQyxHQUFSLENBQVl3QixRQUFRLG1CQUFwQjtBQUVILGFBbkJELENBbUJFLE9BQU8xQixDQUFQLEVBQVU7QUFDUkMsd0JBQVFDLEdBQVIsQ0FBWSxvREFBWjtBQUNBRCx3QkFBUUMsR0FBUixDQUFZRixFQUFFRyxPQUFkO0FBQ0g7QUFDSjtBQXRDVSxLQUFmO0FBMENJZCxXQUFPMEIsT0FBUCxDQUFlLFVBQWYsRUFBMkIsWUFBVTtBQUNqQyxlQUFPc0IsU0FBU3JCLElBQVQsRUFBUDtBQUNILEtBRkQ7QUFHUDs7QUFFRCxJQUFJM0IsT0FBTzRCLFFBQVgsRUFBb0I7QUFDaEI1QixXQUFPNkIsU0FBUCxDQUFpQixVQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDekVEO0FBRUE0QixTQUFTLFVBQVNLLFNBQVQsRUFBbUI7QUFDeEIsUUFBSUosTUFBTSxJQUFJZCxJQUFKLENBQVVrQixTQUFWLENBQVY7QUFDQSxRQUFJQyxXQUFXbkIsS0FBS29CLEdBQUwsS0FBYU4sSUFBSU8sT0FBSixFQUE1QjtBQUNBLFFBQUlDLFVBQVUsSUFBSXRCLElBQUosQ0FBU21CLFFBQVQsQ0FBZDtBQUNBLFdBQU9JLEtBQUtDLEdBQUwsQ0FBU0YsUUFBUUcsY0FBUixLQUEwQixJQUFuQyxDQUFQO0FBQ0gsQ0FMRCxDOzs7Ozs7Ozs7OztBQ0ZBLElBQUlyRSxNQUFKO0FBQVdULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ksV0FBT0gsQ0FBUCxFQUFTO0FBQUNHLGlCQUFPSCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStETixPQUFPSSxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUcxRUksT0FBTytCLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRDtBQUlBL0IsT0FBT0UsT0FBUCxDQUFlO0FBQ1gsZ0JBQVksWUFBVTtBQUNsQlUsZ0JBQVFDLEdBQVIsQ0FBWSxzQkFBWjtBQUNBYixlQUFPZ0IsSUFBUCxDQUFZLGVBQVo7QUFDQWhCLGVBQU9nQixJQUFQLENBQVksV0FBWjtBQUNBaEIsZUFBT2dCLElBQVAsQ0FBWSxVQUFaO0FBQ0g7QUFOVSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuZXhwb3J0IGNvbnN0IEVwc3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXBzcycpO1xyXG5pbXBvcnQge0hUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCdcclxuXHJcblxyXG4vKlxyXG5QbGVhc2UgcmV2aWV3IHRoZSBBSFJRIENvcHlyaWdodCBhbmQgRGlzY2xhaW1lciBub3RpY2UgYmVmb3JlIHVzaW5nIHRoZSBBUEk6IGh0dHBzOi8vd3d3LnVzcHJldmVudGl2ZXNlcnZpY2VzdGFza2ZvcmNlLm9yZy9QYWdlL05hbWUvY29weXJpZ2h0LW5vdGljZS5cclxuSW5zdHJ1Y3Rpb25zIGZvciB1c2UgYW5kIGFjY2VzcyBpbmZvcm1hdGlvbiBjYW4gYmUgZm91bmQgYXQ6XHJcbuKAolx0SW5zdHJ1Y3Rpb24gZm9yIFVzZTogIGh0dHA6Ly9lcHNzLmFocnEuZ292L1BEQS9kb2NzL2VQU1NfRGF0YV9BUElfV0lfd0xpbmsucGRmXHJcbuKAolx0VVJMOiAgaHR0cDovL2Vwc3NkYXRhLmFocnEuZ292L1xyXG4gKi9cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gICAgICAgICdnZXRFcHNzJzogZnVuY3Rpb24gKHBhcmFtcykge1xyXG4gICAgICAgICAgICAvL1ZlcnkgZmlyc3QsIGNsZWFuIG91dCBvbGQgZVBTUyBkYXRhIChpZiBhbnkpXHJcbiAgICAgICAgICAgIEVwc3MucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIEZpcnN0LCB3ZSBuZWVkIHRvIGtub3cgdGhlIGVwc3MgYXBpIHVybFxyXG4gICAgICAgICAgICBjb25zdCB1cmwgPSAnaHR0cDovL2Vwc3NkYXRhLmFocnEuZ292Lyc7XHJcblxyXG4gICAgICAgICAgICAvLyBOZXh0LCBnZXQgdGhlIGVQU1Mga2V5IGZyb20gdGhlIHRleHQgZmlsZSBpbiB0aGUgUHJpdmF0ZSBmb2xkZXIuXHJcbiAgICAgICAgICAgIC8vIHRoaXMgZm9sZGVyIHdpbGwgbm90IHN5bmMgd2l0aCBnaXQgYXMgaXQgaXMgaW4gdGhlIC5naXRpZ25vcmVcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHZhciBlUFNTX0tleSA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQoJ2VQU1NfS2V5Lmpzb24nKSlcclxuICAgICAgICAgICAgfSBjYXRjaChlKXtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdGZXRjaGluZyBlUFNTIGtleSBmYWlsZWQuIFBsZWFzZSBtYWtlIHN1cmUgZVBTU19LZXkuanNvbiBleGlzdHMgaW4gdGhlIHByaXZhdGUgZm9sZGVyLicpXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIElmIHRoZSBrZXkgaXMgYmxhbmsgb3Igbm90IHVwZGF0ZWQsIHdlIGNhbm5vdCBjb250aW51ZS4uXHJcbiAgICAgICAgICAgIC8vbGV0IGJsYW5rS2V5cyA9IFsnJywnUFVUX0tFWV9IRVJFJ11cclxuICAgICAgICAgICAgaWYgKGVQU1NfS2V5LmtleSA9PT0gJ1BVVF9LRVlfSEVSRScpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2VQU1MgS2V5IG5vdCBmb3VuZCBvciBpbnZhbGlkLSBwbGVhc2UgaW5wdXQgeW91ciBlUFNTIGtleSBpbnRvIGVQU1NfS2V5Lmpzb24gZmlsZSBpbiBwcml2YXRlIGZvbGRlcicpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIElmIG5vIHBhcmFtcyBhcmUgcGFzc2VkLCBlcnJvciBhbmQgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICBpZiAoIXBhcmFtcyl7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJObyBlUFNTIHBhcmFtZXRlcnMgZm91bmQuIE5vdCBmZXRjaGluZy5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZTogJzE4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V4OiAnTWFsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvYmFjY286ICdOJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V4dWFsbHlBY3RpdmU6ICdOJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhZGU6ICdBJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAqL1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gbGFzdGx5LCBpbnNlcnQga2V5IGludG8gcGFyYW1zXHJcbiAgICAgICAgICAgICAgICBwYXJhbXMua2V5ID0gZVBTU19LZXkua2V5O1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIFRyeSB0byBmZXRjaCB0aGUgZVBTUyByZWNvbW1lbmRhdGlvbnMgYmFzZWQgb24gdGhlIHBhcmFtcy5cclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgSFRUUC5jYWxsKCdnZXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6ICdhY2NlcHQ6IGpzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uKGVyciwgcmVzdWx0KXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoZXJyKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVyclxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9vbmx5IHdhbnQgdG8gc3RvcmUgdGhlIHNwZWNpZmljIHJlY29tbWVuZGF0aW9ucyBhcnJheSBvYmplY3RzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZXBzc0NvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZWNzID0gcmVzdWx0LmRhdGEuc3BlY2lmaWNSZWNvbW1lbmRhdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHggaW4gcmVjcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVwc3MuaW5zZXJ0KHJlY3NbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVwc3NDb3VudCArPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcHNzQ291bnQgKyAnIGVQU1MgcmVjcyBpbnNlcnRlZCcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAgICAgJ2NsZWFyRXBzcyc6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICAgICBFcHNzLnJlbW92ZSh7fSlcclxuICAgICAgICB9XHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdlcHNzJywgZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgcmV0dXJuIEVwc3MuZmluZCgpXHJcbiAgICAgICAgfSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCl7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdlcHNzJylcclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTWV0cmljcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtZXRyaWNzJyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIHBhdCBjb2xsZWN0aW9uLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW50IFBhdCBkYXRhIGF0IHN0YXJ0dXAgYXMgdGhlcmUgc2hvdWxkIG5vdCBiZSBhbnkgcGF0aWVudCBpbiBjb250ZXh0LlxyXG4gICAgICAgIE1ldHJpY3MucmVtb3ZlKHt9KVxyXG5cclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBNZXRlb3IucHVibGlzaCgnbWV0cmljcycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIE1ldHJpY3MuZmluZCgpXHJcbiAgICB9KTtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcbiAgICAgICAgJ2dldE1ldHJpY3MnOiBmdW5jdGlvbihwYXRJZCl7XHJcbiAgICAgICAgICAgIE1ldHJpY3MucmVtb3ZlKHt9KTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG1ldHJpY3NTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgnbWV0cmljcy5jc3YnKTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBtZXRyaWNzID0gUGFwYS5wYXJzZShtZXRyaWNzU3RyaW5nLCB7aGVhZGVyOiB0cnVlfSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBtZXRyaWNzLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobWV0cmljcy5kYXRhW3hdLnBhdElkID09PSBwYXRJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRyaWNzLmluc2VydChtZXRyaWNzLmRhdGFbeF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCArPSAxXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY291bnQgKyAnIG1ldHJpY3MgZW50ZXJlZCcpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBwYXJzaW5nIHRoZSBtZXRyaWNzIGRhdGFcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ21ldHJpY3MnKVxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBPYnNlcnZhdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignb2JzJyk7XHJcblxyXG4vLyBPbmNlIG91ciBwYXRpZW50IGlzIHNlbGVjdGVkIHdlIG5lZWQgdG8gcG9wdWxhdGUgb3VyIHBhdCBjb2xsZWN0aW9uLlxyXG5cclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuXHJcbiAgICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAgICAgLy8gY2xlYXIgYW55IGRhdGEgYXQgc3RhcnR1cCBhcyB0aGVyZSBzaG91bGQgbm90IGJlIGFueSBwYXRpZW50IGluIGNvbnRleHQuXHJcbiAgICAgICAgT2JzZXJ2YXRpb25zLnJlbW92ZSh7fSlcclxuXHJcbiAgICB9KTtcclxuXHJcblxyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ29icycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIE9ic2VydmF0aW9ucy5maW5kKClcclxuICAgIH0pO1xyXG5cclxuICAgIE1ldGVvci5tZXRob2RzKHtcclxuICAgICAgICAnZ2V0T2JzJzogZnVuY3Rpb24ocGF0SWQpe1xyXG4gICAgICAgICAgICBPYnNlcnZhdGlvbnMucmVtb3ZlKHt9KTtcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBTdHJpbmcgPSBBc3NldHMuZ2V0VGV4dCgnb2JzZXJ2YXRpb25zLmNzdicpO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlID0gUGFwYS5wYXJzZShTdHJpbmcsIHtoZWFkZXI6IHRydWV9KTtcclxuICAgICAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4IGluIHBhcnNlLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFyc2UuZGF0YVt4XS5wYXRJZCA9PT0gcGF0SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgT2JzZXJ2YXRpb25zLmluc2VydChwYXJzZS5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIE9ic2VydmF0aW9ucyBhcmUgaW4gdGhlcmUsIGJ1dCB0aGUgZGF0ZSBmaWVsZCBpcyBqdXN0IGEgc3RyaW5nLlxyXG4gICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHRyYW5zZm9ybSB0aGUgc3RyaW5nIGluIHRoZSBcImRhdGVcIiBmaWVsZCBpbnRvIGEgamF2YXNjcmlwdCBkYXRlLlxyXG4gICAgICAgICAgICAgICAgbGV0IGFsbCA9IE9ic2VydmF0aW9ucy5maW5kKCkuZmV0Y2goKVxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCBpbiBhbGwpe1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfaWQgPSBhbGxbeF0uX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGUgPSBuZXcgRGF0ZShhbGxbeF0uZGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgT2JzZXJ2YXRpb25zLnVwc2VydCh7X2lkOiBfaWR9LHskc2V0OiB7ZGF0ZTogZGF0ZX19KVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBvYnNlcnZhdGlvbnMgZW50ZXJlZCcpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBwYXJzaW5nIHRoZSBvYnNlcnZhdGlvbnMgZGF0YVwiKVxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuICAgICAgICB9XHJcbiAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ29icycpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5pbXBvcnQge1BhdGllbnRzfSBmcm9tIFwiLi9wYXRpZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFBhdCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwYXQnKTtcclxuXHJcbi8vIE9uY2Ugb3VyIHBhdGllbnQgaXMgc2VsZWN0ZWQgd2UgbmVlZCB0byBwb3B1bGF0ZSBvdXIgY29sbGVjdGlvbnMuIFRoZSBtYWluIGZ1bmN0aW9ucyBmb3IgdGhpcyBhcmUgaGFuZGxlZCBoZXJlXHJcbi8vIFdpdGggcmVmZXJlbmNlcyB0byB0aGUgb3RoZXIgY29sbGVjdGlvbnMgd2hlbiBuZWVkZWQuXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cclxuICAgIE1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAgICAgICAvLyBjbGVhciBhbnQgUGF0IGRhdGEgYXQgc3RhcnR1cCBhcyB0aGVyZSBzaG91bGQgbm90IGJlIGFueSBwYXRpZW50IGluIGNvbnRleHQuXHJcbiAgICAgICAgUGF0LnJlbW92ZSh7fSlcclxuXHJcbiAgICB9KTtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcbiAgICAgICAgJ3VwZGF0ZVBhdCc6IGZ1bmN0aW9uKHBhdElkKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlUGF0IHdhcyBydW5cIik7XHJcbiAgICAgICAgICAgIC8vIE9rLCBGaXJzdCwgbGV0J3MgZmV0Y2ggdGhlIG90aGVyIGRhdGEgYWJvdXQgdGhlIHBhdGllbnRcclxuICAgICAgICAgICAgLy8gV2UnbGwgc3RvcmUgdGhpcyBzaW5nbGUgcGF0aWVudCdzIGRhdGEgaW4gYSBuZXcgQ29sbGVjdGlvbiwgcGF0XHJcblxyXG4gICAgICAgICAgICAvLyBJZiBhbnkgb2xkIGRhdGEgaXMgaW4gUGF0LCBuZWVkIHRvIGNsZWFyIGl0XHJcbiAgICAgICAgICAgIFBhdC5yZW1vdmUoe30pXHJcblxyXG4gICAgICAgICAgICAvLyBOb3csIGxldCdzIHN0YXJ0IGZyZXNoIHdpdGggb3VyIGN1cnJlbnRseSBzZWxlY3RlZCBwYXRpZW50XHJcbiAgICAgICAgICAgIFBhdC5pbnNlcnQoe19pZDogcGF0SWR9KTtcclxuXHJcblxyXG4gICAgICAgICAgICAvLyB0aGVzZSBoZWxwZXIgZnVuY3Rpb25zIHdpbGwgbWFrZSBpbnNlcnRpbmcgYW5kIHJlYWRpbmcgZGF0YSBlYXNpZXJcclxuXHJcbiAgICAgICAgICAgIC8vIFRoaXMgb25lIGFkZHMgYSBuZXcgb2JqZWN0IHRvIHRoZSBkYXRhYmFzZSBjb2xsZWN0aW9uIHVuZGVyIHRoaXMgcGF0SWRcclxuICAgICAgICAgICAgZnVuY3Rpb24gdXBkYXRlUGF0KG9iamVjdCkge1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhvYmplY3QpXHJcbiAgICAgICAgICAgICAgICBQYXQudXBkYXRlKHtfaWQ6IHBhdElkfSwgeyRzZXQ6ICBvYmplY3R9KVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL2UuZy4gLSBmaXJzdCBsZXQncyB1c2Ugb3VyIFwiUGF0aWVudHNcIiBsaXN0IGFuZCBnZXQgdGhlIGZ1bGwgbmFtZSBhbmQgYWxzbyB0aGUgYWdlXHJcbiAgICAgICAgICAgIHVwZGF0ZVBhdCh7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiBQYXRpZW50cy5maW5kT25lKHtwYXRJZDogcGF0SWR9KS5mbmFtZSArICcgJyArIFBhdGllbnRzLmZpbmRPbmUoe3BhdElkOiBwYXRJZH0pLmxuYW1lLFxyXG4gICAgICAgICAgICAgICAgYWdlOiBnZXRBZ2UoUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSkuZG9iKVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIExldCdzIHRocm93IGV2ZXJ5dGhpbmcgZWxzZSB0aGF0IGlzIGluIHRoZSBcIlBhdGllbnRzXCIgY29sbGVjdGlvbiBhYm91dCBvdXIgcGF0aWVudCBpbiBhIGdlbiAoZm9yIFwiZ2VuZXJhbFwiKSBvYmplY3RcclxuICAgICAgICAgICAgdXBkYXRlUGF0KHtcclxuICAgICAgICAgICAgICAgIGdlbjogUGF0aWVudHMuZmluZE9uZSh7cGF0SWQ6IHBhdElkfSlcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4vLyBTaW11bGF0ZSBhIGNhbGwgdG8gYSB0YWJsZSB0aGF0IGhvbGRzIHBhdGllbnQgT2JzZXJ2YXRpb25zXHJcbiAgICAgICAgICAgIC8vIFRoZSBtZXRlb3IuY2FsbCBhY3R1YWxseSBqdXN0IHJlYWRzIGZyb20gdGhlIENTViwgYnV0IGl0IGRvZXMgdGhlbiBmaWx0ZXIgYnkgdGhlIHBhdElkXHJcbiAgICAgICAgICAgIC8vIHNvcnQgb2YgbGlrZSBob3cgYSByZWFsIFNRTCBjYWxsIHdvdWxkIHdvcmsuXHJcbiAgICAgICAgICAgIC8vIFdlIHdpbGwgc3RvcmUgdGhpcyBpbiBvdXIgUGF0IGNvbGxlY3Rpb24gdW5kZXIgdGhlIGdyb3VwICdvYnMnXHJcblxyXG4gICAgICAgICAgICBNZXRlb3IuY2FsbCgnZ2V0T2JzJywgcGF0SWQpO1xyXG5cclxuLy8gTm93IHNpbXVsYXRlIGEgY2FsbCBmb3IgcGF0aWVudCBNZXRyaWNzXHJcbiAgICAgICAgICAgIC8vIHRoaXMgd2lsbCBnbyBpbiBhIHNlcGFyYXRlIGNvbGxlY3Rpb24gZm9yIHNlYXJjaGluZywgc28ganVzdCBpcyBhIG1ldGVvci5jYWxsXHJcblxyXG4gICAgICAgICAgICBNZXRlb3IuY2FsbCgnZ2V0TWV0cmljcycsIHBhdElkKVxyXG5cclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICAnY2xlYXJQYXQnOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICAgICAgUGF0LnJlbW92ZSh7fSlcclxuICAgICAgICB9LFxyXG5cclxuICAgIH0pO1xyXG5cclxuICAgICAgICBNZXRlb3IucHVibGlzaCgncGF0JywgZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgcmV0dXJuIFBhdC5maW5kKClcclxuICAgICAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ3BhdCcpXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5leHBvcnQgY29uc3QgUGF0aWVudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncGF0aWVudHMnKTtcclxuXHJcblxyXG4vLyBQb3B1bGF0ZSBvdXIgbG9jYWwgcGF0aWVudCBkYXRhYmFzZSB3aXRoIHNvbWUgcHJlLWJ1aWx0IHBhdGllbnQgZGF0YS5cclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblxyXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxyXG5cclxuICAgIC8vIE9ubHkgZG8gdGhpcyBvbiBzdGFydHVwIGlmIHRoZSBkYiBpcyBlbXB0eVxyXG4gICAgaWYgKFBhdGllbnRzLmZpbmQoKS5jb3VudCgpID09PSAwKXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImZvdW5kIG5vIHBhdGllbnRzLSBnZXR0aW5nIGRhdGEuLi5cIik7XHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0UGF0aWVudHMnKVxyXG5cclxuICAgIH0gZWxzZXtcclxuICAgICAgICBjb25zb2xlLmxvZygnZm91bmQgcGF0aWVudHMgYWxyZWFkeSBpbiBkYXRhYmFzZScpXHJcbiAgICB9XHJcblxyXG59KTtcclxuXHJcbiAgICBNZXRlb3IubWV0aG9kcyh7XHJcbiAgICAgICAgJ2NsZWFyUGF0aWVudHMnOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICAgICAgUGF0aWVudHMucmVtb3ZlKHt9KVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgICdyZXNldFBhdGllbnRzJzogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdyZXNldHRpbmcgcGF0aWVudCBEQicpO1xyXG4gICAgICAgICAgICBQYXRpZW50cy5yZW1vdmUoe30pO1xyXG5cclxuICAgICAgICAgICAgLy8gVGhlIHBhdGllbnQgZGF0YSBpcyBzdG9yZWQgYXMgYSBDU1YgZmlsZSBpbiBvdXIgXCJwcml2YXRlXCIgZm9sZGVyXHJcbiAgICAgICAgICAgIC8vIFRoaXMgYWxsb3dzIHVzIHRvIHF1aWNrIGFuZCBkaXJ0eSByZXBsaWNhdGUgd2hhdCBtaWdodCBiZSBhIHZpZXcgb24gQWN1ZXJlXHJcbiAgICAgICAgICAgIC8vIEl0IHdvdWxkIHByb2JhYmx5IGJlIGVhc2llciBpZiB0aGlzIHdvdWxkIGp1c3QgcHVsbCBmcm9tIEFjdWVyZS4uLlxyXG5cclxuICAgICAgICAgICAgLy9GaXJzdCwgaW1wb3J0IHRoZSBjc3YgYXMgYSBzdHJpbmc6IGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzE3NDUzODQ4L2lzLXRoZXJlLWEtd2F5LXRvLWltcG9ydC1zdHJpbmdzLWZyb20tYS10ZXh0LWZpbGUtaW4tamF2YXNjcmlwdC1tZXRlb3JcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXRpZW50U3RyaW5nID0gQXNzZXRzLmdldFRleHQoJ3BhdGllbnRzLmNzdicpO1xyXG4gICAgICAgICAgICAgICAgLy8gcGF0aWVudFN0cmluZyB3aWxsIGNvbnRhaW4gdGhlIGRhdGEgYXMgb25lIGxvbmcgQ1NWIHN0cmluZ1xyXG4gICAgICAgICAgICAgICAgLy8gV2UgbmVlZCB0byBwYXJzZSBpdCB0byBhIEpTT04gb2JqZWN0LlxyXG4gICAgICAgICAgICAgICAgLy8gd2lsbCB1c2UgdGhlIFBhcGEgcGFyc2UgcGFja2FnZSB0byBkbyB0aGlzLi4uXHJcblxyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF0aWVudERhdGEgPSBQYXBhLnBhcnNlKHBhdGllbnRTdHJpbmcsIHtoZWFkZXI6IHRydWV9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBXZSB3aWxsIHN0b3JlIHRoZSBkYXRhIGluIG91ciBvd24gTW9uZ28gY29sbGVjdGlvbiB0aGF0IHdlIGRlZmluZWQgYWJvdmUtIFBhdGllbnRzXHJcbiAgICAgICAgICAgICAgICAvLyBQcmVmZXIgdG8gc3RvcmUgZWFjaCBwYXRpZW50IGFzIHRoZWlyIG93biBcImRvY3VtZW50XCIgdG8gbWFrZSBzZWFyY2hlcyBhbmQgc3R1ZmYgZWFzaWVyLCBzbyBsb29wIHRocm91Z2ggdGhlIENTViBkYXRhIGFuZCBpbnNlcnQgb25lIGF0IGEgdGltZVxyXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHggaW4gcGF0aWVudERhdGEuZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKHBhdGllbnREYXRhLmRhdGFbeF0ucGF0SWQgIT09JycpeyAvLyBpZ25vcmVzIGFueSBibGFuayByb3dzIChpLmUuIGxhc3Qgcm93IHRoYXQgYWx3YXlzIGNvbWVzIGJhY2spXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBhdGllbnRzLmluc2VydChwYXRpZW50RGF0YS5kYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgKz0gMVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNvdW50ICsgJyBwYXRpZW50cyBlbnRlcmVkJylcclxuXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic29tZXRoaW5nIHdlbnQgd3Jvbmcgd2l0aCBnZXR0aW5nIHRoZSBwYXRpZW50IGxpc3RcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgICAgIE1ldGVvci5wdWJsaXNoKCdwYXRpZW50cycsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHJldHVybiBQYXRpZW50cy5maW5kKClcclxuICAgICAgICB9KVxyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KXtcclxuICAgIE1ldGVvci5zdWJzY3JpYmUoJ3BhdGllbnRzJylcclxufSIsIi8vIGdsb2JhbCBmdW5jdGlvbnMgZ28gaGVyZVxyXG5cclxuZ2V0QWdlID0gZnVuY3Rpb24oZG9iU3RyaW5nKXtcclxuICAgIGxldCBkb2IgPSBuZXcgRGF0ZSAoZG9iU3RyaW5nKVxyXG4gICAgbGV0IGFnZURpZk1zID0gRGF0ZS5ub3coKSAtIGRvYi5nZXRUaW1lKClcclxuICAgIGxldCBhZ2VEYXRlID0gbmV3IERhdGUoYWdlRGlmTXMpXHJcbiAgICByZXR1cm4gTWF0aC5hYnMoYWdlRGF0ZS5nZXRVVENGdWxsWWVhcigpLSAxOTcwKVxyXG59O1xyXG5cclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCAnLi4vaW1wb3J0cy9nbG9iYWwnO1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXHJcbn0pO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgJ3Jlc2V0QWxsJzogZnVuY3Rpb24oKXtcclxuICAgICAgICBjb25zb2xlLmxvZygnRnVsbCByZXNldCBjYWxsZWQuLi4nKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgncmVzZXRQYXRpZW50cycpO1xyXG4gICAgICAgIE1ldGVvci5jYWxsKCdjbGVhckVwc3MnKTtcclxuICAgICAgICBNZXRlb3IuY2FsbCgnY2xlYXJQYXQnKTtcclxuICAgIH1cclxufSk7Il19
